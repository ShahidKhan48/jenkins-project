/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.helper;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.AssetStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.CollectionRequestStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class DigitalAssetHelperTest {

  @Test
  void collectionRequestStatusShouldBePendingOnMandatoryAssetsNotInSubmittedOrApprovedState() {
    Optional<CollectionRequestStatus> collectionRequestStatus = DigitalAssetHelper.getCollectionRequestStatus(
        getStatusWiseAssetsForPendingState(), CollectionRequest.builder().assets(Arrays.asList(
                CollectionRequestAsset.builder().digitalAssetId("1").isMandatory(true).build(),
                CollectionRequestAsset.builder().digitalAssetId("2").isMandatory(true).build(),
                CollectionRequestAsset.builder().digitalAssetId("3").isMandatory(true).build()))
            .build());

    Assertions.assertTrue(collectionRequestStatus.isPresent());
    collectionRequestStatus.ifPresent(
        status -> Assertions.assertEquals(CollectionRequestStatus.PENDING, status));
  }

  @Test
  void collectionRequestStatusShouldBeSubmittedOnMandatoryAssetsInSubmittedState() {
    Optional<CollectionRequestStatus> collectionRequestStatus = DigitalAssetHelper.getCollectionRequestStatus(
        getStatusWiseAssetsForSubmittedState(), CollectionRequest.builder().assets(Arrays.asList(
                CollectionRequestAsset.builder().digitalAssetId("1").isMandatory(true).build(),
                CollectionRequestAsset.builder().digitalAssetId("2").isMandatory(true).build(),
                CollectionRequestAsset.builder().digitalAssetId("3").isMandatory(true).build()))
            .build());

    Assertions.assertTrue(collectionRequestStatus.isPresent());
    collectionRequestStatus.ifPresent(
        status -> Assertions.assertEquals(CollectionRequestStatus.SUBMITTED, status));
  }

  @Test
  void collectionRequestStatusShouldBeSubmittedOnMandatoryAssetsInSubmittedStateOrApprovedState() {
    Optional<CollectionRequestStatus> collectionRequestStatus = DigitalAssetHelper.getCollectionRequestStatus(
        getStatusWiseAssetsForSubmittedOrApprovedState(), CollectionRequest.builder().assets(
                Arrays.asList(
                    CollectionRequestAsset.builder().digitalAssetId("1").isMandatory(true).build(),
                    CollectionRequestAsset.builder().digitalAssetId("2").isMandatory(true).build()))
            .build());

    Assertions.assertTrue(collectionRequestStatus.isPresent());
    collectionRequestStatus.ifPresent(
        status -> Assertions.assertEquals(CollectionRequestStatus.SUBMITTED, status));
  }

  @Test
  void collectionRequestStatusShouldBePendingOnAllMandatoryAssetsNotInSubmittedStateOrApprovedState() {
    Optional<CollectionRequestStatus> collectionRequestStatus = DigitalAssetHelper.getCollectionRequestStatus(
        getStatusWiseAssetsForSubmittedOrApprovedOrPendingState(), CollectionRequest.builder()
            .assets(Arrays.asList(
                CollectionRequestAsset.builder().digitalAssetId("1").isMandatory(true).build(),
                CollectionRequestAsset.builder().digitalAssetId("2").isMandatory(true).build(),
                CollectionRequestAsset.builder().digitalAssetId("3").isMandatory(true).build()))
            .build());

    Assertions.assertTrue(collectionRequestStatus.isPresent());
    collectionRequestStatus.ifPresent(
        status -> Assertions.assertEquals(CollectionRequestStatus.PENDING, status));
  }

  @Test
  void collectionRequestStatusShouldBeSubmittedOnAllMandatoryAssetsInSubmittedStateOrApprovedStateWithGroup() {
    Optional<CollectionRequestStatus> collectionRequestStatus = DigitalAssetHelper.getCollectionRequestStatus(
        getStatusWiseAssetsForSubmittedOrApprovedOrPendingState(), CollectionRequest.builder()
            .assets(Arrays.asList(
                CollectionRequestAsset.builder().digitalAssetId("1").isMandatory(true).build(),
                CollectionRequestAsset.builder().digitalAssetId("2").group("1").isMandatory(true)
                    .build(),
                CollectionRequestAsset.builder().digitalAssetId("3").group("1").isMandatory(true)
                    .build())).build());

    Assertions.assertTrue(collectionRequestStatus.isPresent());
    collectionRequestStatus.ifPresent(
        status -> Assertions.assertEquals(CollectionRequestStatus.SUBMITTED, status));
  }

  @Test
  void collectionRequestStatusShouldBeApprovedOnAllMandatoryAssetsApprovedStateWithPendingOrSubmittedInNonMandatoryGroup() {
    Optional<CollectionRequestStatus> collectionRequestStatus = DigitalAssetHelper.getCollectionRequestStatus(
        getStatusWiseAssetsForSubmittedOrApprovedOrPendingState(), CollectionRequest.builder()
            .assets(Arrays.asList(
                CollectionRequestAsset.builder().digitalAssetId("1").isMandatory(true).build(),
                CollectionRequestAsset.builder().digitalAssetId("2").group("1").isMandatory(false)
                    .build(),
                CollectionRequestAsset.builder().digitalAssetId("3").group("1").isMandatory(false)
                    .build())).build());

    Assertions.assertTrue(collectionRequestStatus.isPresent());
    collectionRequestStatus.ifPresent(
        status -> Assertions.assertEquals(CollectionRequestStatus.APPROVED, status));
  }

  @Test
  void collectionRequestStatusShouldBeApprovedOnAllAssetsInApprovedState() {
    Optional<CollectionRequestStatus> collectionRequestStatus = DigitalAssetHelper.getCollectionRequestStatus(
        getStatusWiseAssetsForApprovedState(), CollectionRequest.builder().assets(Arrays.asList(
                CollectionRequestAsset.builder().digitalAssetId("1").isMandatory(true).build(),
                CollectionRequestAsset.builder().digitalAssetId("2").isMandatory(true).build(),
                CollectionRequestAsset.builder().digitalAssetId("3").isMandatory(true).build()))
            .build());

    Assertions.assertTrue(collectionRequestStatus.isPresent());
    collectionRequestStatus.ifPresent(
        status -> Assertions.assertEquals(CollectionRequestStatus.APPROVED, status));
  }

  private List<DigitalAsset> getStatusWiseAssetsForSubmittedOrApprovedOrPendingState() {
    return Arrays.asList(DigitalAsset.builder().status(AssetStatus.APPROVED).id("1").build(),
        DigitalAsset.builder().status(AssetStatus.SUBMITTED).id("2").build(),
        DigitalAsset.builder().status(AssetStatus.PENDING).id("3").build());
  }

  private List<DigitalAsset> getStatusWiseAssetsForSubmittedOrApprovedState() {
    return Arrays.asList(DigitalAsset.builder().status(AssetStatus.APPROVED).id("1").build(),
        DigitalAsset.builder().status(AssetStatus.SUBMITTED).id("2").build());
  }

  private List<DigitalAsset> getStatusWiseAssetsForApprovedState() {
    return Arrays.asList(DigitalAsset.builder().status(AssetStatus.APPROVED).id("1").build(),
        DigitalAsset.builder().status(AssetStatus.APPROVED).id("2").build(),
        DigitalAsset.builder().status(AssetStatus.APPROVED).id("3").build());
  }

  private List<DigitalAsset> getStatusWiseAssetsForSubmittedState() {
    return Arrays.asList(DigitalAsset.builder().status(AssetStatus.SUBMITTED).id("1").build(),
        DigitalAsset.builder().status(AssetStatus.SUBMITTED).id("2").build(),
        DigitalAsset.builder().status(AssetStatus.SUBMITTED).id("3").build());
  }

  private List<DigitalAsset> getStatusWiseAssetsForPendingState() {
    return Arrays.asList(DigitalAsset.builder().status(AssetStatus.PENDING).id("1").build(),
        DigitalAsset.builder().status(AssetStatus.PENDING).id("2").build(),
        DigitalAsset.builder().status(AssetStatus.PENDING).id("3").build());
  }
}