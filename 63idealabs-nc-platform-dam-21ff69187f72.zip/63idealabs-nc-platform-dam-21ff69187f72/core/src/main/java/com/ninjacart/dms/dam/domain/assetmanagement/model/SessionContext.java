package com.ninjacart.dms.dam.domain.assetmanagement.model;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SessionContext {

  private String actionUserId;
  private String toolId;
}
