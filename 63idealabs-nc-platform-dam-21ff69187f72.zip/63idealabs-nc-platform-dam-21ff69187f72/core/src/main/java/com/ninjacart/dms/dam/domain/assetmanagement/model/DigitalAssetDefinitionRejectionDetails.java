/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Digital Asset Definition RejectionDetails.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DigitalAssetDefinitionRejectionDetails implements Serializable {

  private List<String> classification;
  private List<String> subClassification;
}
