/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.constants;

import lombok.experimental.UtilityClass;

/**
 * Core Constants.
 */
@UtilityClass
public final class CoreConstants {

  public static final String DAM_SCHEMA_GROUP = "dam";
  public static final String ID = "id";
  public static final String REALM_ID = "realmId";
  public static final String USER_ID = "userId";
  public static final String VERSION = "version";
  public static final String TITLE = "title";
  public static final String ES_DOC_TYPE = "_doc";
  public static final String EXPIRY_TS = "expiry_ts";
  public static final String VERIFIED_TS = "verified_ts";
  public static final int ZERO = 0;
  public static final int THOUSAND = 1000;
  public static final String DESC = "DESC";

  public static final String KEYWORD = "keyword";
  public static final String STATUS_KEY = "status";
  public static final String CREATED_FOR_COLLECTION_REQUEST = "Created for Collection Request: %s";
  public static final String DIGITAL_ASSET_DEFINITION_ID = "digitalAssetDefinitionId";

  public static final String AUTO_APPROVED_FOR_COLLECTION_REQUEST = "Auto Approved for Collection Request: %s";
  public static final String AUTO_SUBMITTED_FOR_COLLECTION_REQUEST = "Auto Submitted for Collection Request: %s";

  public static final String SIMPLE_DATE_FORMAT = "yyyy-MM-dd";
  public static final String CREATED_AT = "createdAt";

}
