/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;


/**
 * The Provider for storing the file.
 */
public enum StorageProvider {
  S3, ADLS, GCS
}
