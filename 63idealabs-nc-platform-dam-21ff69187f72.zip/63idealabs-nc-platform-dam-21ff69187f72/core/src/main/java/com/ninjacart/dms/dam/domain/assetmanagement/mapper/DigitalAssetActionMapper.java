/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.mapper;

import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestAction;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetAction;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * DigitalAssetAction Mapper.
 */
@Mapper
public interface DigitalAssetActionMapper {

  DigitalAssetActionMapper INSTANCE = Mappers.getMapper(DigitalAssetActionMapper.class);

  /**
   * Converts List of CollectionRequestAction into List of DigitalAssetAction.
   *
   * @param collectionRequestActions list of CollectionRequestActions to be converted.
   * @return list ofDigitalAssetActions.
   */
  List<DigitalAssetAction> toDigitalAssetAction(
      List<CollectionRequestAction> collectionRequestActions);

  /**
   * Converts CollectionRequestAction into DigitalAssetAction.
   *
   * @param collectionRequestAction CollectionRequestAction to be converted.
   * @return convertedDigitalAssetAction.
   */
  @Mapping(target = "status", ignore = true)
  DigitalAssetAction toDigitalAssetAction(CollectionRequestAction collectionRequestAction);
}
