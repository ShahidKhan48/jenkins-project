package com.ninjacart.dms.dam.domain.consentmanagement.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ninjacart.dms.dam.domain.consentmanagement.enums.ConsentAccessMode;
import com.ninjacart.dms.dam.domain.consentmanagement.enums.ConsentDataFrequency;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Consent Permission.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConsentPermission {

  private String fromDate;
  private String toDate;
  private String expiry;
  private String dataEraseAt;
  private ConsentDataFrequency dataFrequency;
  private BigDecimal dataFrequencyValue;
  private BigDecimal dataFrequencyRepeats;
  private ConsentAccessMode accessMode;
}
