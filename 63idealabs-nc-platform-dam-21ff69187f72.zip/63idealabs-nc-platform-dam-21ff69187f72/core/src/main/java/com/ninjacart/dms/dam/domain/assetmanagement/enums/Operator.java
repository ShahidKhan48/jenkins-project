/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * ES filter Operators.
 */
@Getter
@RequiredArgsConstructor
public enum Operator {

  gte(">="), lte("<="), contains("contains"),

  gt(">"), lt("<"), eq("="), neq("!="),

  between("range"), or("or"), nor("nor"),

  startsWith("startsWith"), endsWith("endsWith"),

  notContains("notContains"), notStartsWith("notStartsWith"),

  notEndsWith("notEndsWith"), queryString("queryString");

  private final String value;
}

