/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.ActionMode;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.CollectionRequestStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.DigitalAssetActionStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.EventOnStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.InitiatorType;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CallbackPayload;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetAction;
import com.ninjacart.dms.dam.domain.assetmanagement.model.EventData;
import com.ninjacart.dms.dam.domain.assetmanagement.model.OnUpdateContext;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.CallbackClient;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * DigitalAssetEventsOnUpdateExecutor - Handles initiating SYSTEM initiated Actions at Digital
 * Assets level.
 */
@Slf4j
@RequiredArgsConstructor
public class DigitalAssetEventsOnUpdateExecutor implements OnUpdateExecutor {

  private final CallbackClient callbackClient;

  @Override
  public void execute(SessionContext sessionContext, String realmId, String userId, OnUpdateContext onUpdateContext) {
    if (CollectionUtils.isNotEmpty(onUpdateContext.getDigitalAssetsToSave().values())
        || CollectionUtils.isNotEmpty(onUpdateContext.getCollectionRequestsToSave().values())) {
      return;
    }

    List<CollectionRequest> collectionRequests = onUpdateContext.getCollectionRequests().stream()
        .filter(cr -> !Objects.equals(CollectionRequestStatus.APPROVED, cr.getStatus())).toList();

    // process all non-approved collection requests of user
    for (CollectionRequest collectionRequest : collectionRequests) {
      List<String> digitalAssetIds = collectionRequest.getAssets().stream()
          .map(CollectionRequestAsset::getDigitalAssetId).toList();

      List<DigitalAsset> collectionRequestDigitalAssets = onUpdateContext.getDigitalAssets()
          .stream().filter(digitalAsset -> digitalAssetIds.contains(digitalAsset.getId())).toList();

      List<DigitalAsset> assetsWithSystemActions = collectionRequestDigitalAssets.stream().filter(
          digitalAsset -> CollectionUtils.isNotEmpty(
              Optional.ofNullable(digitalAsset.getActions()).orElse(Collections.emptyList())
                  .stream().filter(action -> InitiatorType.SYSTEM.equals(action.getInitiatorType()))
                  .filter(action -> Objects.isNull(action.getStatus())).toList())).toList();

      // process DigitalAsset Actions that has SYSTEM as InitiatorType
      for (DigitalAsset assetWithSystemActions : assetsWithSystemActions) {

        Optional.ofNullable(assetWithSystemActions.getActions()).orElse(Collections.emptyList())
            .stream().filter(
                action -> Objects.isNull(action.getStatus()))
            .filter(action -> InitiatorType.SYSTEM.equals(action.getInitiatorType()))
            .filter(action -> Objects.nonNull(action.getEvent()))
            .filter(action -> StringUtils.isNotBlank(action.getEvent().getCallbackUrl()))
            .findFirst().ifPresent(action -> {
              if (validateForCallback(action, collectionRequestDigitalAssets, assetWithSystemActions)) {
                try {
                  callbackClient.executeCallback(action.getEvent().getCallbackUrl(),
                      CallbackPayload.builder().realmId(realmId).userId(userId)
                          .digitalAssetId(assetWithSystemActions.getId())
                          .collectionRequestId(collectionRequest.getId()).build());
                } catch (Exception e) {
                  // Swallowing exception - callback failure shouldn't affect program execution
                  log.error("Error in events Callback. {}", e.getMessage(), e);
                }
              }
            });
      }
    }
  }

  private boolean validateForCallback(DigitalAssetAction processingDAAction,
      List<DigitalAsset> processingCRDigitalAssets, DigitalAsset processingDigitalAsset) {
    return Optional.ofNullable(processingDAAction.getEvent()).map(event -> {
      Map<String, EventOnStatus> digitalAssetDefinitionIdToOnStatusMap = Optional.ofNullable(
              processingDAAction.getEvent().getEventData()).orElse(Collections.emptyList()).stream()
          .collect(Collectors.toMap(EventData::getEntityId, EventData::getOnStatus));
      return isProcessActionsDone(processingDAAction, processingDigitalAsset)
          && processingCRDigitalAssets.stream().filter(
              da -> digitalAssetDefinitionIdToOnStatusMap.containsKey(da.getDigitalAssetDefinitionId()))
          .allMatch(
              da -> digitalAssetDefinitionIdToOnStatusMap.get(da.getDigitalAssetDefinitionId())
                  .getApplicableStatuses().contains(da.getStatus()));
    }).orElse(true);
  }

  private boolean isProcessActionsDone(DigitalAssetAction processingDAAction,
      DigitalAsset processingDigitalAsset) {
    // if processing DA Action is PROCESS return true, else check if all PROCESS actions of DA are done.
    return Objects.equals(processingDAAction.getMode(), ActionMode.PROCESS) || Optional.ofNullable(
            processingDigitalAsset.getActions()).orElse(Collections.emptyList()).stream()
        .filter(action -> Objects.equals(action.getMode(), ActionMode.PROCESS))
        .allMatch(action -> Objects.equals(action.getStatus(), DigitalAssetActionStatus.SUBMITTED));
  }
}