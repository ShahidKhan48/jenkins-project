/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl;

import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDefinition;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.DigitalAssetDefinitionsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.EntityStore;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

/**
 * Digital Asset Definitions Service implementation.
 */
@Slf4j
public class DigitalAssetDefinitionsServiceImpl extends
    PlatformManagedObjectService<DigitalAssetDefinition> implements DigitalAssetDefinitionsService {

  public DigitalAssetDefinitionsServiceImpl(EntityStore entityStore) {
    super(entityStore);
  }

  @Override
  public DigitalAssetDefinition create(SessionContext sessionContext, String realmId, String userId,
      DigitalAssetDefinition digitalAssetDefinition) {
    return super.create(sessionContext, realmId, userId, digitalAssetDefinition);
  }

  @Override
  public DigitalAssetDefinition read(String realmId, String userId, String id) {
    return super.read(realmId, userId, id);
  }

  @Override
  public DigitalAssetDefinition update(SessionContext sessionContext, String realmId, String userId, String id,
      DigitalAssetDefinition digitalAssetDefinition, boolean sendEvent) {
    return super.update(sessionContext, realmId, userId, id, digitalAssetDefinition, sendEvent);
  }

  @Override
  public List<DigitalAssetDefinition> search(String realmId, String userId, SearchQuery searchQuery,
      Boolean advanced) {
    return super.search(realmId, userId, searchQuery, advanced);
  }

  @Override
  public List<DigitalAssetDefinition> deleteBySearch(SessionContext sessionContext, String realmId, String userId,
      SearchQuery searchQuery, Boolean advanced) {
    return super.deleteBySearch(sessionContext, realmId, userId, searchQuery, advanced);
  }

  @Override
  public DigitalAssetDefinition delete(SessionContext sessionContext, String realmId, String userId, String id) {
    return super.delete(sessionContext, realmId, userId, id);
  }

  @Override
  protected Class<DigitalAssetDefinition> type() {
    return DigitalAssetDefinition.class;
  }
}
