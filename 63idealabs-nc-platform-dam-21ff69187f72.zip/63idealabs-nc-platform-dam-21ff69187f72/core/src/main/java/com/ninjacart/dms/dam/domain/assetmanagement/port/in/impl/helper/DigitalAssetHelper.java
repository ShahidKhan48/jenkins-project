/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.helper;

import com.ninjacart.dms.dam.constants.CoreConstants;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.AssetStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.CollectionRequestStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.Operator;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDetailsResponse;
import com.ninjacart.dms.dam.domain.assetmanagement.model.Filter;
import com.ninjacart.dms.dam.domain.assetmanagement.model.OnUpdateContext;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.CollectionRequestsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.DigitalAssetsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors.OnUpdateExecutor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Digital Asset Helper.
 */
@Slf4j
@RequiredArgsConstructor
public class DigitalAssetHelper {

  private final List<OnUpdateExecutor> onUpdateExecutors;
  private final DigitalAssetsService digitalAssetsService;
  private final CollectionRequestsService collectionRequestsService;

  public static SearchQuery searchQueryForExistingAssets(List<String> digitalAssetDefinitionIds) {
    return SearchQuery.builder()
        .entityTypes(Collections.singletonList(DigitalAsset.class.getSimpleName()))
        .limit(CoreConstants.THOUSAND).offset(CoreConstants.ZERO).filters(Collections.singletonList(
            Filter.builder().operator(Operator.or).path(DigitalAsset.class.getSimpleName())
                .property(CoreConstants.DIGITAL_ASSET_DEFINITION_ID + "." + CoreConstants.KEYWORD)
                .value(digitalAssetDefinitionIds).build())).build();
  }

  /**
   * SearchQuery to get digitalAssets by IDs.
   *
   * @param digitalAssetIds
   * @return {@link SearchQuery}
   */
  public static SearchQuery searchQueryForIds(List<String> digitalAssetIds) {
    return SearchQuery.builder()
        .entityTypes(Collections.singletonList(DigitalAsset.class.getSimpleName()))
        .limit(digitalAssetIds.size()).offset(CoreConstants.ZERO).filters(Collections.singletonList(
            Filter.builder().operator(Operator.or).path(DigitalAsset.class.getSimpleName())
                .property(CoreConstants.ID + "." + CoreConstants.KEYWORD).value(digitalAssetIds)
                .build())).build();
  }

  public static Optional<CollectionRequestStatus> getCollectionRequestStatus(
      List<DigitalAsset> digitalAssets, CollectionRequest collectionRequest) {
    Optional<CollectionRequestStatus> statusToBeUpdated = Optional.empty();
    boolean allMandatoryAssetsInSameState = false;

    Result result = processGroupedAssets(digitalAssets, collectionRequest);

    int mandatoryAssets = result.nonGroupedMandatoryAssets().size();
    Map<AssetStatus, List<DigitalAsset>> assetStatusWiseAssets = result.nonGroupedMandatoryAssets()
        .stream().collect(Collectors.groupingBy(DigitalAsset::getStatus));

    for (AssetStatus assetStatus : assetStatusWiseAssets.keySet()) {
      allMandatoryAssetsInSameState = Objects.equals(
          assetStatusWiseAssets.getOrDefault(assetStatus, new ArrayList<>()).size(),
          mandatoryAssets);
      if (allMandatoryAssetsInSameState) {
        if (assetStatus.equals(AssetStatus.PENDING)) {
          statusToBeUpdated = Optional.of(CollectionRequestStatus.PENDING);
        } else if (assetStatus.equals(AssetStatus.SUBMITTED) && !autoSubmitDisabled(
            collectionRequest)) {
          statusToBeUpdated = Optional.of(CollectionRequestStatus.SUBMITTED);
        } else if (assetStatus.equals(AssetStatus.APPROVED)) {
          statusToBeUpdated = Optional.of(CollectionRequestStatus.APPROVED);
        } else if (assetStatus.equals(AssetStatus.REJECTED)) {
          statusToBeUpdated = Optional.of(CollectionRequestStatus.USER_INPUT_REQUIRED);
        }
        break;
      }
    }
    if (!allMandatoryAssetsInSameState) {
      CollectionRequestStatus collectionRequestStatus = AssetStatus.digitalAssetStatusesToCollectionRequestStatus(
          assetStatusWiseAssets.keySet());
      long submittedDocumentsCount = assetStatusWiseAssets.keySet().stream()
          .map(assetStatus -> assetStatusWiseAssets.get(assetStatus).size())
          .mapToLong(value -> value).sum();
      if (Objects.equals(submittedDocumentsCount, (long) mandatoryAssets)) {
        statusToBeUpdated = Optional.of(collectionRequestStatus);
      }
    }
    return statusToBeUpdated;
  }

  private static Result processGroupedAssets(List<DigitalAsset> digitalAssets,
      CollectionRequest collectionRequest) {
    Set<String> nonGroupedMandatoryAssetIds = collectionRequest.getAssets().stream()
        .filter(each -> Objects.isNull(each.getGroup()))
        .filter(CollectionRequestAsset::getIsMandatory)
        .map(CollectionRequestAsset::getDigitalAssetId).collect(Collectors.toSet());

    List<DigitalAsset> nonGroupedMandatoryAssets = digitalAssets.stream()
        .filter(da -> nonGroupedMandatoryAssetIds.contains(da.getId()))
        .collect(Collectors.toList());

    Map<String, Set<String>> groupedMandatoryAssetIds = collectionRequest.getAssets().stream()
        .filter(each -> Objects.nonNull(each.getGroup()))
        .filter(CollectionRequestAsset::getIsMandatory)
        .collect(Collectors.groupingBy(CollectionRequestAsset::getGroup)).entrySet().stream()
        .collect(Collectors.toMap(Entry::getKey,
            e -> e.getValue().stream().map(CollectionRequestAsset::getDigitalAssetId)
                .collect(Collectors.toSet())));

    Map<String, List<DigitalAsset>> groupedMandatoryAssets = digitalAssets.stream().filter(
        da -> groupedMandatoryAssetIds.values().stream().flatMap(Collection::stream)
            .collect(Collectors.toSet()).contains(da.getId())).collect(Collectors.groupingBy(
        da -> groupedMandatoryAssetIds.entrySet().stream()
            .filter(e -> e.getValue().contains(da.getId())).findFirst().get().getKey()));

    for (String group : groupedMandatoryAssets.keySet()) {
      List<DigitalAsset> groupMandatoryAssets = groupedMandatoryAssets.get(group);

      Set<AssetStatus> groupMandatoryAssetsStatus = groupMandatoryAssets.stream()
          .map(DigitalAsset::getStatus).collect(Collectors.toSet());

      AssetStatus assetStatus = getGroupStatus(groupMandatoryAssetsStatus);

      // Adding to Non Grouped assets because this is the one asset which has been in a higher status
      groupMandatoryAssets.stream().filter(each -> each.getStatus().equals(assetStatus)).findFirst()
          .ifPresent(nonGroupedMandatoryAssets::add);
    }
    return new Result(nonGroupedMandatoryAssetIds, nonGroupedMandatoryAssets,
        groupedMandatoryAssetIds);
  }

  private record Result(Set<String> nonGroupedMandatoryAssetIds,
                        List<DigitalAsset> nonGroupedMandatoryAssets,
                        Map<String, Set<String>> groupedMandatoryAssetIds) {

  }

  private static AssetStatus getGroupStatus(Set<AssetStatus> assetStatuses) {
    if (assetStatuses.contains(AssetStatus.APPROVED)) {
      return AssetStatus.APPROVED;
    } else if (assetStatuses.contains(AssetStatus.SUBMITTED)) {
      return AssetStatus.SUBMITTED;
    } else if (assetStatuses.contains(AssetStatus.USER_INPUT_REQUIRED)) {
      return AssetStatus.USER_INPUT_REQUIRED;
    } else if (assetStatuses.contains(AssetStatus.REJECTED)) {
      return AssetStatus.REJECTED;
    }
    return AssetStatus.PENDING;
  }

  private static boolean autoSubmitDisabled(CollectionRequest collectionRequest) {
    return Boolean.TRUE.equals(collectionRequest.getDisableAutoSubmit());
  }

  /**
   * Process digital asset by status
   *
   * @param sessionContext
   * @param realmId        realm Id
   * @param userId         user Id
   * @param digitalAsset   digital asset
   * @return processed asset
   */
  public DigitalAssetDetailsResponse processAssetStatuses(SessionContext sessionContext,
      String realmId, String userId, DigitalAsset digitalAsset,
      boolean skipCollectionRequestCallbacks) {
    log.debug("Initiating OnUpdate for DA: {}", digitalAsset.getId());
    OnUpdateContext onUpdateContext = constructOnUpdateContext(realmId, userId, digitalAsset,
        skipCollectionRequestCallbacks);
    onUpdateExecutors.forEach(onUpdateExecutor -> {
      log.debug("Running onUpdateExecutor: {}. Context: {}",
          onUpdateExecutor.getClass().getSimpleName(), onUpdateExecutor);
      onUpdateExecutor.execute(sessionContext, realmId, userId, onUpdateContext);
    });
    return DigitalAssetDetailsResponse.builder().digitalAsset(digitalAsset).build();
  }

  private OnUpdateContext constructOnUpdateContext(String realmId, String userId,
      DigitalAsset digitalAsset, boolean skipCollectionRequestCallbacks) {
    String entityType = CollectionRequest.class.getSimpleName();
    List<CollectionRequest> collectionRequests = collectionRequestsService.search(realmId, userId,
            SearchQuery.builder().entityTypes(Collections.singletonList(entityType))
                .rootLabel(entityType).offset(CoreConstants.ZERO).limit(CoreConstants.THOUSAND)
                .filters(Collections.emptyList()).build(), false).stream().filter(Objects::nonNull)
        .toList();

    List<String> digitalAssetDefinitionIds = Objects.requireNonNull(collectionRequests.stream())
        .filter(Objects::nonNull).flatMap(cr -> cr.getAssets().stream()).filter(Objects::nonNull)
        .map(CollectionRequestAsset::getId).filter(Objects::nonNull).distinct().toList();
    List<DigitalAsset> digitalAssets = digitalAssetsService.search(realmId, userId,
        DigitalAssetHelper.searchQueryForExistingAssets(digitalAssetDefinitionIds), false);
    return OnUpdateContext.builder().digitalAsset(digitalAsset)
        .digitalAssets(new ArrayList<>(digitalAssets)).collectionRequest(collectionRequests.stream()
            .filter(cr -> Objects.equals(digitalAsset.getCollectionRequestId(), cr.getId()))
            .findFirst().orElse(null)).collectionRequests(collectionRequests)
        .digitalAssetsToSave(new HashMap<>()).collectionRequestsToSave(new HashMap<>())
        .skipCollectionRequestCallbacks(skipCollectionRequestCallbacks).build();
  }
}
