/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.FileCreationType;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.StorageProvider;
import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * MediaDetail.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class MediaDetail implements Serializable {

  private String mediaUrl;
  private StorageProvider storageProvider;
  private FileCreationType fileCreationType;
  private String presignedUrl;
  private String createdAt;
  private List<Tag> tags;
}
