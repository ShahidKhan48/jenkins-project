/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.exception;

import com.ninjacart.platform.commons.error.enums.Severity;
import com.ninjacart.platform.commons.error.iface.MetricName;
import com.ninjacart.platform.commons.error.iface.ServiceErrorCode;
import java.util.Collections;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.apache.hc.core5.http.HttpStatus;

/**
 * DAM Service Error codes.
 */
@AllArgsConstructor
@RequiredArgsConstructor
@Getter
public enum DAMServiceErrorCode implements ServiceErrorCode {

  DAM_SERVICE_ERROR_001("{} not found for schema, {}", Severity.MODERATE,
      HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_002("Unable to read file", Severity.MODERATE, HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_003("Schema Validation failed for {}", Severity.MODERATE,
      HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_004("Read failed for {}: {}", Severity.MODERATE, HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_005("Save failed for {}", Severity.MODERATE, HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_006("Can't validate, Schema has a problem: {}", Severity.CRITICAL,
      HttpStatus.SC_INTERNAL_SERVER_ERROR),

  DAM_SERVICE_ERROR_007("No documents available for Id(s): {}", Severity.MODERATE,
      HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_008("Event failed for {}: {}", Severity.MODERATE, HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_009("Cluster not defined for event", Severity.MODERATE,
      HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_010("Error during async event send", Severity.MODERATE,
      HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_011("Error during elastic index creation: {}", Severity.CRITICAL,
      HttpStatus.SC_INTERNAL_SERVER_ERROR),

  DAM_SERVICE_ERROR_012("Error during elastic indexing: {}", Severity.MODERATE,
      HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_013("Error during parsing bulk request: {}", Severity.MODERATE,
      HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_014("Invalid query: {}", Severity.MODERATE, HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_015("Error during elastic fetch all docs: {}", Severity.MODERATE,
      HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_016("Digital Asset Id not found in request", Severity.MODERATE,
      HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_017("Digital Asset not found", Severity.MODERATE, HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_018("Digital Asset action not found", Severity.MODERATE,
      HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_019("DaProxy call failed", Severity.MODERATE,
      HttpStatus.SC_INTERNAL_SERVER_ERROR),

  DAM_SERVICE_ERROR_020("Action not supported", Severity.LOW,
      HttpStatus.SC_BAD_REQUEST),

  DAM_SERVICE_ERROR_021("Cannot delete media: {}", Severity.LOW,
      HttpStatus.SC_BAD_REQUEST);

  private final String message;
  private Severity severity;
  private boolean retryRequired;
  private int retryCount;
  private int retryInterval;
  private MetricName metricName;
  private int status;

  DAMServiceErrorCode(String msg, Severity type) {
    this.message = msg;
    this.severity = type;
  }

  DAMServiceErrorCode(String msg, Severity type, boolean retryRequired) {
    this(msg, type);
    this.retryRequired = retryRequired;
  }

  DAMServiceErrorCode(String msg, Severity type, boolean retryRequired, int retryCount,
      int retryInterval) {
    this(msg, type);
    this.retryRequired = retryRequired;
    this.retryCount = retryCount;
    this.retryInterval = retryInterval;
  }

  DAMServiceErrorCode(String message, Severity severity, boolean retryRequired, int retryCount,
      int retryInterval, int status) {
    this(message, severity, retryRequired, retryCount, retryInterval);
    this.status = status;
  }

  DAMServiceErrorCode(String message, Severity severity, int status) {
    this(message, severity);
    this.status = status;
  }

  DAMServiceErrorCode(String message, Severity severity, int status, MetricName metricName) {
    this(message, severity);
    this.status = status;
    this.metricName = metricName;
  }

  @Override
  public String getCode() {
    return name();
  }

  @Override
  public List<MetricName> getMetricNameList() {
    //TODO - Implement Metric
    return Collections.emptyList();
  }
}
