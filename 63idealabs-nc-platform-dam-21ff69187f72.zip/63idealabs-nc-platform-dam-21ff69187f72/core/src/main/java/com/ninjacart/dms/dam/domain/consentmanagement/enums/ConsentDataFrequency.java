package com.ninjacart.dms.dam.domain.consentmanagement.enums;

/**
 * Consent Data Frequency.
 */
public enum ConsentDataFrequency {
  HOUR, DAY, WEEK, MONTH, YEAR
}
