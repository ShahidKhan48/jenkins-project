/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in;

import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import java.util.List;

public interface DigitalAssetsService {

  /**
   * Create {@link DigitalAsset} with event sourcing.
   *
   * @param sessionContext session context
   * @param realmId        realm of the user.
   * @param userId         id of the user.
   * @param digitalAsset   entity to be created.
   * @return created {@link DigitalAsset}.
   */
  DigitalAsset create(SessionContext sessionContext, String realmId, String userId,
      DigitalAsset digitalAsset);

  /**
   * Fetch latest version of {@link DigitalAsset} based on give id.
   *
   * @param id      id of the {@link DigitalAsset}
   * @param realmId realm of the user
   * @param userId  id of the user
   * @return fetched {@link DigitalAsset}
   */
  DigitalAsset read(String realmId, String userId, String id);

  /**
   * Update {@link DigitalAsset} with event sourcing.
   *
   * @param sessionContext session context
   * @param realmId        realm of the user.
   * @param userId         id of the user.
   * @param id             id of the {@link DigitalAsset}.
   * @param digitalAsset   update entity.
   * @param sendEvent      send event
   * @return updated {@link DigitalAsset}
   */
  DigitalAsset update(SessionContext sessionContext, String realmId, String userId, String id,
      DigitalAsset digitalAsset, boolean sendEvent);

  /**
   * Search {@link DigitalAsset} based on search query.
   *
   * @param realmId     realm of the user.
   * @param userId      id of the user.
   * @param searchQuery search query.
   * @param advanced    advanced search flag.
   * @return fetched {@link DigitalAsset}(s).
   */
  List<DigitalAsset> search(String realmId, String userId, SearchQuery searchQuery,
      Boolean advanced);

  /**
   * Create Digital Asset in bulk.
   *
   * @param sessionContext session context
   * @param realmId        realm Id
   * @param userId         user Id
   * @param digitalAssets  digital assets
   * @return digital assets created
   */
  List<DigitalAsset> createAll(SessionContext sessionContext, String realmId, String userId, List<DigitalAsset> digitalAssets);

  /**
   * Update Digital Asset in bulk.
   *
   * @param sessionContext session context
   * @param realmId        realm Id
   * @param userId         user Id
   * @param digitalAssets  digital assets
   * @return digital assets created
   */
  List<DigitalAsset> updateAll(SessionContext sessionContext, String realmId, String userId, List<DigitalAsset> digitalAssets);

  /**
   * Delete {@link DigitalAsset} based on given id.
   *
   * @param sessionContext session context
   * @param realmId        realm of the user
   * @param userId         id of the user
   * @param id             id of the {@link DigitalAsset}
   * @param deleteMedia    whether media is to be deleted
   * @return deleted {@link DigitalAsset}
   */
  DigitalAsset delete(SessionContext sessionContext, String realmId, String userId, String id,
      Boolean deleteMedia);

  /**
   * Delete {@link DigitalAsset} based on search query.
   *
   * @param sessionContext session context
   * @param realmId        realm of the user.
   * @param userId         id of the user.
   * @param searchQuery    search query.
   * @param advanced       advanced search flag.
   * @return deleted {@link DigitalAsset}(s).
   */
  List<DigitalAsset> deleteBySearch(SessionContext sessionContext, String realmId, String userId,
      SearchQuery searchQuery, Boolean advanced, Boolean deleteMedia);
}
