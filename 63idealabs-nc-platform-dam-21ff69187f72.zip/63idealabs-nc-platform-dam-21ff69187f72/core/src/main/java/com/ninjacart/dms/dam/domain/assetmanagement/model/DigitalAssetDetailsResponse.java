package com.ninjacart.dms.dam.domain.assetmanagement.model;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Represents the response structure for digital asset details. This class encapsulates the details
 * specific to a digital asset.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalAssetDetailsResponse {

  private DigitalAssetDetails data;
  private DigitalAsset digitalAsset;
  private String providerReferenceId;
  private String redirectUrl;
}
