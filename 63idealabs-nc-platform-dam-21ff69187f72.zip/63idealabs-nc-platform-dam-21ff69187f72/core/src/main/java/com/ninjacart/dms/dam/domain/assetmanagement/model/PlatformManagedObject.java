package com.ninjacart.dms.dam.domain.assetmanagement.model;

/**
 * Interface for platform managed core entities.
 */
public interface PlatformManagedObject {

  /**
   * Get id of platform managed object.
   *
   * @return id
   */
  String getId();

  /**
   * Get Created At.
   *
   * @return created at
   */
  String getCreatedAt();

  /**
   * Get Updated At.
   *
   * @return updated at
   */
  String getUpdatedAt();

  /**
   * Get Created By Tool.
   *
   * @return created by tool
   */
  String getCreatedByTool();

  /**
   * Get Updated By Tool.
   *
   * @return updated By Tool
   */
  String getUpdatedByTool();

  /**
   * Get Created By.
   *
   * @return created by
   */
  String getCreatedBy();

  /**
   * Get Updated By.
   *
   * @return updated By
   */
  String getUpdatedBy();
}
