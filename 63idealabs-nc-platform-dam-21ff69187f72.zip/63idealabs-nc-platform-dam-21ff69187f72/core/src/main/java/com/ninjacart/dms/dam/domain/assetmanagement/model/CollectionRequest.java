/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.CollectionRequestStatus;
import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CollectionRequest.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CollectionRequest implements PlatformManagedObject, Serializable {

  private String id;
  private String realmId;
  private String userId;
  private String name;
  private List<CollectionRequestAsset> assets;
  private String referenceId;
  private String collectionRequestTemplateId;
  private List<Tag> tags;
  private List<CollectionRequestAction> actions;
  //  private String externalReferenceId;
  private CollectionRequestStatus status;
  private String callbackUrl;
  private Boolean allowEditAfterTerminalStatus;
  private Boolean disableAutoSubmit;
  private Boolean disableAutoApproval;

  private String createdAt;
  private String updatedAt;
  private String createdByTool;
  private String updatedByTool;
  private String createdBy;
  private String updatedBy;
}
