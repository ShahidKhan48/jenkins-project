/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

/**
 * Event Entity enum.
 */
public enum EventEntity {
  DigitalAssetDefinition
}
