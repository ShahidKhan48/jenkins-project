/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in;

import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import java.util.List;

/**
 * Collect Request Service.
 */
public interface CollectionRequestsService {

  /**
   * Create {@link CollectionRequest} with event sourcing.
   *
   * @param sessionContext    session context
   * @param realmId           realm Id.
   * @param userId            user Id.
   * @param collectionRequest Collection Request Entity.
   * @return created Collection Request.
   */
  CollectionRequest create(SessionContext sessionContext, String realmId, String userId,
      CollectionRequest collectionRequest);

  /**
   * Fetch latest version of {@link CollectionRequest} based on give id.
   *
   * @param id      id of the {@link CollectionRequest}.
   * @param realmId realm of the user.
   * @param userId  id of the user.
   * @return fetched {@link CollectionRequest}.
   */
  CollectionRequest read(String realmId, String userId, String id);

  /**
   * Update {@link CollectionRequest} with event sourcing.
   *
   * @param sessionContext    session context
   * @param realmId           realm of the user.
   * @param userId            id of the user.
   * @param id                id of the {@link CollectionRequest}.
   * @param collectionRequest update entity.
   * @param sendEvent         send event
   * @return updated {@link CollectionRequest}.
   */
  CollectionRequest update(SessionContext sessionContext, String realmId, String userId, String id,
      CollectionRequest collectionRequest, boolean sendEvent);

  /**
   * Search {@link CollectionRequest} based on search query.
   *
   * @param realmId     realm of the user.
   * @param userId      id of the user.
   * @param searchQuery search query.
   * @param advanced    advanced search flag.
   * @return fetched {@link CollectionRequest}(s).
   */
  List<CollectionRequest> search(String realmId, String userId, SearchQuery searchQuery,
      Boolean advanced);

  /**
   * Update Collection Request in bulk.
   *
   * @param sessionContext     session context
   * @param realmId            realm Id
   * @param userId             user Id
   * @param collectionRequests collection requests
   * @return collection requests created
   */
  List<CollectionRequest> updateAll(SessionContext sessionContext, String realmId, String userId,
      List<CollectionRequest> collectionRequests);

  /**
   * Delete {@link CollectionRequest} based on give id.
   *
   * @param sessionContext session context
   * @param realmId        realm of the user.
   * @param userId         id of the user.
   * @param id             id of the {@link CollectionRequest}.
   * @return deleted {@link CollectionRequest}.
   */
  CollectionRequest delete(SessionContext sessionContext, String realmId, String userId, String id);

  /**
   * Delete {@link CollectionRequest} based on search query.
   *
   * @param sessionContext session context
   * @param realmId        realm of the user.
   * @param userId         id of the user.
   * @param searchQuery    search query.
   * @param advanced       advanced search flag.
   * @return fetched {@link CollectionRequest}(s).
   */
  List<CollectionRequest> deleteBySearch(SessionContext sessionContext, String realmId,
      String userId, SearchQuery searchQuery, Boolean advanced);
}
