/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

/**
 * File Creation Types for Asset/Media.
 */
public enum FileCreationType {
  USER_UPLOAD, PROVIDER_DOWNLOAD, PROVIDER_RESPONSE
}
