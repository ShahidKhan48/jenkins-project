/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

import lombok.Getter;

/**
 * DigitalAssetDefinitionMetadataFieldType - Used to identify the type of the metadata field type
 */
@Getter
public enum DigitalAssetDefinitionMetadataFieldType {
  text, textArea, dropdown, multiSelectDropdown, radio, checkbox, date, pincode, number;
}
