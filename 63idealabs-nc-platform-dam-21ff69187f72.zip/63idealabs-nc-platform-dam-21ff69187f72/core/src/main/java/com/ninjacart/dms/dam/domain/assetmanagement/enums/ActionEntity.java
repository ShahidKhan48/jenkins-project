package com.ninjacart.dms.dam.domain.assetmanagement.enums;

/**
 * Entity on which Actions are possible.
 */
public enum ActionEntity {
  DigitalAsset, CollectionRequest
}
