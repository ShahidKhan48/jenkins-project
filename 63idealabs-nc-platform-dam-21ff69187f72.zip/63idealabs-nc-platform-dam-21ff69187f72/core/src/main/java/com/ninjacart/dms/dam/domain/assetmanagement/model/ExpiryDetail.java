/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ExpiryDetail.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ExpiryDetail {

  private String label;
  private Integer days;
}
