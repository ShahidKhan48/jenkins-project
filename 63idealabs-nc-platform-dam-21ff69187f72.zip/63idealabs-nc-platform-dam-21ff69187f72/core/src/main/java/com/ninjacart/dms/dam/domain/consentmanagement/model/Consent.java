package com.ninjacart.dms.dam.domain.consentmanagement.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ninjacart.dms.dam.domain.assetmanagement.model.PlatformManagedObject;
import com.ninjacart.dms.dam.domain.assetmanagement.model.Tag;
import com.ninjacart.dms.dam.domain.consentmanagement.enums.ConsentStatus;
import com.ninjacart.dms.dam.domain.consentmanagement.enums.ConsentType;
import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Consent.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Consent implements PlatformManagedObject {

  private String id;
  private String uniqueReference;
  private UserDetails originatorDetails;
  private BigDecimal version;
  private String name;
  private String description;
  private String purpose;
  private ConsentStatus status;
  private ConsentType type;
  private ConsentDetails details;
  private UserDetails requestor;
  private UserDetails requestee;
  private ArtifactDetails artifactDetails;
  private List<Tag> tags;

  private String createdAt;
  private String updatedAt;
  private String createdByTool;
  private String updatedByTool;
  private String createdBy;
  private String updatedBy;
}
