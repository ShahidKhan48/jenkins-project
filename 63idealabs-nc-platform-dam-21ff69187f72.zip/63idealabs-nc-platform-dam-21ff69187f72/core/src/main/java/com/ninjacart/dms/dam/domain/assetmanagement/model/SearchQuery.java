/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.ninjacart.dms.dam.constants.CoreConstants;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Model class for firing elastic search query.
 */
@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class SearchQuery {

  private List<Filter> filters;
  private int limit;
  private int offset;
  private List<String> fields;
  private String rootLabel;
  private List<String> entityTypes;
  private String sort;
  private String rawQuery;
  @Default
  private String sortOrder = CoreConstants.DESC;
  private Boolean globalSearch;
}

