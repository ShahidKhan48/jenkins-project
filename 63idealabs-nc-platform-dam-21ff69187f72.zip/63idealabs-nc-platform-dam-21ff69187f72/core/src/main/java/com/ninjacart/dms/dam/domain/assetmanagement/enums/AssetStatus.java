/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;


import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * AssetStatus.
 */
public enum AssetStatus {
  APPROVED, REJECTED, PENDING, SUBMITTED, USER_INPUT_REQUIRED;

  private final static Map<Set<AssetStatus>, CollectionRequestStatus> statusMap;

  static {
    statusMap = new HashMap<>();
    statusMap.put(Set.of(APPROVED, PENDING), CollectionRequestStatus.PENDING);
    statusMap.put(Set.of(APPROVED, USER_INPUT_REQUIRED), CollectionRequestStatus.PENDING);
    statusMap.put(Set.of(PENDING, SUBMITTED), CollectionRequestStatus.PENDING);
    statusMap.put(Set.of(SUBMITTED, USER_INPUT_REQUIRED), CollectionRequestStatus.PENDING);
    statusMap.put(Set.of(PENDING, USER_INPUT_REQUIRED), CollectionRequestStatus.PENDING);
    statusMap.put(Set.of(SUBMITTED, APPROVED, PENDING), CollectionRequestStatus.PENDING);
    statusMap.put(Set.of(SUBMITTED, APPROVED, USER_INPUT_REQUIRED),
        CollectionRequestStatus.PENDING);
    statusMap.put(Set.of(SUBMITTED, USER_INPUT_REQUIRED, PENDING), CollectionRequestStatus.PENDING);
    statusMap.put(Set.of(APPROVED, USER_INPUT_REQUIRED, PENDING), CollectionRequestStatus.PENDING);
    statusMap.put(Set.of(SUBMITTED, APPROVED, USER_INPUT_REQUIRED, PENDING),
        CollectionRequestStatus.PENDING);
    statusMap.put(Set.of(APPROVED, SUBMITTED), CollectionRequestStatus.SUBMITTED);
    statusMap.put(Set.of(APPROVED, REJECTED), CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(PENDING, REJECTED), CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(REJECTED, SUBMITTED), CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(REJECTED, USER_INPUT_REQUIRED),
        CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(SUBMITTED, APPROVED, REJECTED),
        CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(SUBMITTED, REJECTED, USER_INPUT_REQUIRED),
        CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(SUBMITTED, REJECTED, PENDING),
        CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(APPROVED, REJECTED, USER_INPUT_REQUIRED),
        CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(APPROVED, REJECTED, PENDING), CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(REJECTED, USER_INPUT_REQUIRED, PENDING),
        CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(SUBMITTED, APPROVED, REJECTED, USER_INPUT_REQUIRED),
        CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(SUBMITTED, APPROVED, REJECTED, PENDING),
        CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(SUBMITTED, REJECTED, USER_INPUT_REQUIRED, PENDING),
        CollectionRequestStatus.USER_INPUT_REQUIRED);
    statusMap.put(Set.of(APPROVED, REJECTED, USER_INPUT_REQUIRED, PENDING, SUBMITTED),
        CollectionRequestStatus.USER_INPUT_REQUIRED);
  }

  public static List<AssetStatus> digitalAssetTerminalStatuses() {
    return Arrays.asList(APPROVED);
  }

  public static CollectionRequestStatus digitalAssetStatusesToCollectionRequestStatus(
      Set<AssetStatus> digitalAssetStatuses) {
    return statusMap.getOrDefault(digitalAssetStatuses, CollectionRequestStatus.PENDING);
  }

}

