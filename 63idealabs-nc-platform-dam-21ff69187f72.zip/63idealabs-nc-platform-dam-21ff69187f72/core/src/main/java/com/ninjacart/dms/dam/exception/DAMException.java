/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.exception;

import com.ninjacart.platform.commons.error.exceptions.NinjaException;
import com.ninjacart.platform.commons.error.iface.ServiceErrorCode;
import lombok.NonNull;

/**
 * DAM Exception.
 */
public class DAMException extends NinjaException {

  public DAMException(@NonNull ServiceErrorCode errorCode, Object... params) {
    super(errorCode, params);
  }

  public DAMException(@NonNull ServiceErrorCode errorCode, @NonNull NinjaException ninjaException,
      Object... params) {
    super(errorCode, ninjaException, params);
  }
}
