package com.ninjacart.dms.dam.domain.consentmanagement.enums;

/**
 * Consent Details Type.
 */
public enum ConsentDetailsType {
  TEXT, URL, HTML
}
