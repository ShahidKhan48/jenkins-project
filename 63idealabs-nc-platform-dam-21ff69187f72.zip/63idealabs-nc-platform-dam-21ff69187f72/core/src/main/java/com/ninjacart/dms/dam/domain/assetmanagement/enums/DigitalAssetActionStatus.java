/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

import java.util.Arrays;
import lombok.Getter;

/**
 * DigitalAssetActionStatus.
 */
@Getter
public enum DigitalAssetActionStatus {
  USER_INPUT_REQUIRED, SUBMITTED, REJECTED;

  public static DigitalAssetActionStatus findBy(String status) {
    return Arrays.stream(DigitalAssetActionStatus.values())
        .filter(each -> status.equals(each.name())).findFirst().orElse(null);
  }
}
