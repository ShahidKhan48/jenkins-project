/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors;

import com.ninjacart.dms.dam.constants.CoreConstants;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.AssetStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.DigitalAssetActionStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetAction;
import com.ninjacart.dms.dam.domain.assetmanagement.model.OnUpdateContext;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.SerializationUtils;

/**
 * DigitalAssetOnUpdateExecutor - Handles Digital Assets status updates on on-update events.
 */
@Slf4j
public class DigitalAssetOnUpdateExecutor implements OnUpdateExecutor {

  private static boolean autoApprovalDisabled(CollectionRequest collectionRequest) {
    return Boolean.TRUE.equals(collectionRequest.getDisableAutoApproval());
  }

  @Override
  public void execute(SessionContext sessionContext, String realmId, String userId,
      OnUpdateContext onUpdateContext) {
    DigitalAsset digitalAsset = onUpdateContext.getDigitalAsset();
    log.debug("Processing DA Status Update: {}", digitalAsset.getId());
    DigitalAsset digitalAssetBeforeUpdate = SerializationUtils.clone(digitalAsset);
    updateDigitalAssetStatus(onUpdateContext.getCollectionRequest(), digitalAsset);
    onUpdateContext.getDigitalAssets()
        .replaceAll(da -> Objects.equals(da.getId(), digitalAsset.getId()) ? digitalAsset : da);
    if (!Objects.equals(digitalAsset, digitalAssetBeforeUpdate)) {
      onUpdateContext.getDigitalAssetsToSave().put(digitalAsset.getId(), digitalAsset);
    }
  }

  private DigitalAsset updateDigitalAssetStatus(CollectionRequest collectionRequest,
      DigitalAsset digitalAsset) {
    if (Objects.nonNull(collectionRequest) && Objects.nonNull(digitalAsset)
        && !AssetStatus.digitalAssetTerminalStatuses().contains(digitalAsset.getStatus())) {
      log.debug("DA Status: {}, DA Action Statuses: {}", digitalAsset.getStatus(),
          Optional.ofNullable(digitalAsset.getActions()).orElse(Collections.emptyList()).stream()
              .map(DigitalAssetAction::getStatus).filter(Objects::nonNull).toList());

      Set<DigitalAssetActionStatus> digitalAssetActionStatuses = Optional.ofNullable(
              digitalAsset.getActions()).orElse(Collections.emptyList()).stream()
          .map(DigitalAssetAction::getStatus).collect(Collectors.toSet());

      if (digitalAssetActionStatuses.contains(DigitalAssetActionStatus.USER_INPUT_REQUIRED)) {
        digitalAsset.setStatus(AssetStatus.USER_INPUT_REQUIRED);
        if (!Objects.isNull(digitalAsset.getSubmittedAt())) {
          digitalAsset.setSubmittedAt(null);
        }
      } else if (Set.of(DigitalAssetActionStatus.SUBMITTED).equals(digitalAssetActionStatuses)
          && !AssetStatus.REJECTED.equals(digitalAsset.getStatus())) {
        log.debug(
            "DA: {} status is PENDING, DA Actions are in SUBMITTED. Auto Updating DA Status to SUBMITTED",
            digitalAsset.getId());
        digitalAsset.setStatus(AssetStatus.SUBMITTED);
        if (Objects.isNull(digitalAsset.getSubmittedAt())) {
          digitalAsset.setSubmittedAt(LocalDateTime.now());
        }
      } else if (digitalAssetActionStatuses.contains(DigitalAssetActionStatus.REJECTED)) {
        log.debug(
            "DA: {} status is PENDING, some DA Actions are in REJECTED. So updating DA Status to REJECTED",
            digitalAsset.getId());
        digitalAsset.setStatus(AssetStatus.REJECTED);
        if (!Objects.isNull(digitalAsset.getSubmittedAt())) {
          digitalAsset.setSubmittedAt(null);
        }
      }

      if (AssetStatus.REJECTED.equals(digitalAsset.getStatus()) && !CollectionUtils.isEmpty(
          digitalAsset.getActions())) {
        log.debug(
            "DA: {} status is REJECTED, some DA Actions are not in REJECTED. So updating DA action Status to null for user retry",
            digitalAsset.getId());
        digitalAsset.setStatus(AssetStatus.REJECTED);
        digitalAsset.getActions().forEach(digitalAssetAction -> digitalAssetAction.setStatus(null));
      }

      if (AssetStatus.SUBMITTED.equals(digitalAsset.getStatus()) && CollectionUtils.isEmpty(
          collectionRequest.getActions()) && !autoApprovalDisabled(collectionRequest)) {
        log.debug(
            "DA: {} status is SUBMITTED, CR Actions are empty. Auto Updating DA Status to APPROVED",
            digitalAsset.getId());
        digitalAsset.setStatus(AssetStatus.APPROVED);
        digitalAsset.setComment(String.format(CoreConstants.AUTO_APPROVED_FOR_COLLECTION_REQUEST,
            digitalAsset.getCollectionRequestId()));
      }
    }
    return digitalAsset;
  }
}
