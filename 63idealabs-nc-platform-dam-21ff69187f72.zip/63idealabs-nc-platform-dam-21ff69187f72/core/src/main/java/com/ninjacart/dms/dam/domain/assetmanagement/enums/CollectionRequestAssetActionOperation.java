/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

/**
 * CollectionRequestAssetActionOperation.
 */
public enum CollectionRequestAssetActionOperation {
  fetch, validate, ocr, upload
}
