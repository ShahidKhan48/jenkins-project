/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.Operator;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ES Filter.
 */
@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class Filter {

  // Denotes the absolute path of the subject
  private String path;
  // The specific attribute being searched for
  private String property;
  // The operator
  private Operator operator;
  // The value that needs to be searched
  private Object value;
}

