/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

/**
 * Asset Operations.
 */
public enum AssetOperation {
  fetch, validate, ocr, onupdate, upload, processdigitalassets, appendassets
}
