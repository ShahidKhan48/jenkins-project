/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

/**
 * Action Modes.
 */
public enum ActionMode {
  PRE_PROCESS, PROCESS, POST_PROCESS
}
