/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors;

import com.ninjacart.dms.dam.domain.assetmanagement.model.OnUpdateContext;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.CollectionRequestsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.DigitalAssetsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

/**
 * PersistenceOnUpdateExecutor - Persists DAs and CRs with status updates.
 */
@Slf4j
@RequiredArgsConstructor
public class PersistenceOnUpdateExecutor implements OnUpdateExecutor {

  private final DigitalAssetsService digitalAssetsService;
  private final CollectionRequestsService collectionRequestsService;

  @Override
  public void execute(SessionContext sessionContext, String realmId, String userId, OnUpdateContext onUpdateContext) {
    if (CollectionUtils.isNotEmpty(onUpdateContext.getDigitalAssetsToSave().values())) {
      digitalAssetsService.updateAll(sessionContext, realmId, userId,
          onUpdateContext.getDigitalAssetsToSave().values().stream().toList());
    }

    if (CollectionUtils.isNotEmpty(onUpdateContext.getCollectionRequestsToSave().values())) {
      collectionRequestsService.updateAll(sessionContext, realmId, userId,
          onUpdateContext.getCollectionRequestsToSave().values().stream().toList());
    }
  }
}
