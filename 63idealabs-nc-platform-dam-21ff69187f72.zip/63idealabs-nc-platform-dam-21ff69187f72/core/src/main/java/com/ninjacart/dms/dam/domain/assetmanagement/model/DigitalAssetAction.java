/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.ActionMode;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.CollectionRequestAssetActionOperation;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.DigitalAssetActionStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.InitiatorType;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.InputType;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DigitalAssetAction
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DigitalAssetAction implements Serializable {

  private String name;
  private InitiatorType initiatorType;
  private CollectionRequestAssetActionOperation operation;
  private ActionMode mode;
  private InputType inputType;
  private String provider;
  private Event event;
  private DigitalAssetActionStatus status;
}

