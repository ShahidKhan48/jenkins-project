package com.ninjacart.dms.dam.domain.assetmanagement.enums;

/**
 * Append Mode for Assets in CR.
 */
public enum AppendMode {
  REPLACE
}
