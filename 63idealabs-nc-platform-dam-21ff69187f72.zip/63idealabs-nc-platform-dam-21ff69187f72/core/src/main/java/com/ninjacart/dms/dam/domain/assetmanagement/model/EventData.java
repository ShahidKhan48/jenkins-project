/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.EventEntity;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.EventOnStatus;
import java.io.Serializable;
import lombok.Data;

/**
 * EventData.
 */
@Data
public class EventData implements Serializable {

  private EventOnStatus onStatus;
  private EventEntity entity;
  private String entityId;
}

