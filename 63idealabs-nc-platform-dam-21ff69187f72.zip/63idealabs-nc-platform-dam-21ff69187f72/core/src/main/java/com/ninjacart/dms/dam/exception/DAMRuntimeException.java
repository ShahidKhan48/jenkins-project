/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.exception;

import com.ninjacart.platform.commons.error.exceptions.NinjaException;
import com.ninjacart.platform.commons.error.exceptions.NinjaRuntimeException;
import com.ninjacart.platform.commons.error.iface.ServiceErrorCode;

/**
 * DAM Runtime Exception.
 */
public class DAMRuntimeException extends NinjaRuntimeException {

  public DAMRuntimeException(ServiceErrorCode errorCode) {
    super(errorCode);
  }

  public DAMRuntimeException(ServiceErrorCode errorCode, Object... params) {
    super(errorCode, params);
  }

  public DAMRuntimeException(ServiceErrorCode errorCode, Exception exception, Object... params) {
    super(errorCode, exception, params);
  }

  public DAMRuntimeException(ServiceErrorCode errorCode, NinjaException ninjaException,
      Object... params) {
    super(errorCode, ninjaException, params);
  }
}
