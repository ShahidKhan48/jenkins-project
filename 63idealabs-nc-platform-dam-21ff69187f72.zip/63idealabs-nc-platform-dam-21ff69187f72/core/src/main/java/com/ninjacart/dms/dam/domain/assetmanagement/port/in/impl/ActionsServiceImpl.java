/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl;

import com.ninjacart.dms.dam.domain.assetmanagement.command.CollectionRequestCommand;
import com.ninjacart.dms.dam.domain.assetmanagement.command.DigitalAssetCommand;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.ActionEntity;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.AppendMode;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.AssetOperation;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.AssetStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.CollectionRequestStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.DigitalAssetActionStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestResponse;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDetails;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDetailsResponse;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetMetadata;
import com.ninjacart.dms.dam.domain.assetmanagement.model.MediaDetail;
import com.ninjacart.dms.dam.domain.assetmanagement.model.RejectionDetails;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.model.Tag;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.ActionsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.CollectionRequestsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.DigitalAssetsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.helper.CollectionRequestCreationHelper;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.helper.DigitalAssetHelper;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.DaProxyClient;
import com.ninjacart.dms.dam.exception.DAMRuntimeException;
import com.ninjacart.dms.dam.exception.DAMServiceErrorCode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * Actions Service Implementation.
 */
@Slf4j
@RequiredArgsConstructor
public class ActionsServiceImpl implements ActionsService {

  private final DigitalAssetsService digitalAssetsService;
  private final CollectionRequestsService collectionRequestsService;
  private final DaProxyClient daProxyClient;
  private final DigitalAssetHelper digitalAssetHelper;
  private final CollectionRequestCreationHelper collectionRequestCreationHelper;

  private void prepareDigitalAsset(DigitalAssetCommand digitalAssetCommand,
      DigitalAsset digitalAsset, AssetOperation digitalAssetOperation) {
    digitalAssetCommand.setStatus(
        Optional.ofNullable(digitalAssetCommand.getStatus()).orElse(digitalAsset.getStatus()));
    digitalAssetCommand.setActionEntity(ActionEntity.DigitalAsset);
    if (StringUtils.isBlank(digitalAssetCommand.getInitiatorReferenceId())) {
      digitalAssetCommand.setInitiatorReferenceId(digitalAsset.getId());
    }
    DigitalAsset existingAsset = digitalAssetsService.read(digitalAsset.getRealmId(),
        digitalAsset.getUserId(), digitalAsset.getId());
    digitalAsset.setRejectionDetails(existingAsset.getRejectionDetails());
    // if upload and existsing status == rejected && new status == submitted then mark it pending so that it recomputes again
    if (AssetOperation.upload.equals(digitalAssetOperation) && AssetStatus.REJECTED.equals(
        existingAsset.getStatus()) && AssetStatus.SUBMITTED.equals(
        digitalAssetCommand.getStatus())) {
      digitalAsset.setStatus(AssetStatus.PENDING);
    }
  }

  @Override
  public DigitalAssetDetailsResponse processDigitalAsset(SessionContext sessionContext,
      String realmId, String userId, String operation, DigitalAssetCommand digitalAssetCommand) {
    AssetOperation digitalAssetAction = AssetOperation.valueOf(operation);
    if (StringUtils.isBlank(digitalAssetCommand.getDigitalAssetId()) || (
        !Objects.equals(digitalAssetAction, AssetOperation.onupdate) && StringUtils.isBlank(
            digitalAssetCommand.getActionName()))) {
      log.error("Digital Asset Id/Action name not found in request");
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_016);
    }

    DigitalAsset digitalAsset = digitalAssetsService.read(realmId, userId,
        digitalAssetCommand.getDigitalAssetId());
    if (Objects.isNull(digitalAsset)) {
      log.error("Digital Asset not found for Id: {}", digitalAssetCommand.getDigitalAssetId());
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_017);
    }

    if (!Objects.equals(digitalAssetAction, AssetOperation.onupdate) && Optional.ofNullable(
            digitalAsset.getActions()).orElse(Collections.emptyList()).stream()
        .noneMatch(each -> Objects.equals(digitalAssetCommand.getActionName(), each.getName()))) {
      log.error("Action Name : {}, not found in Digital Asset: {}",
          digitalAssetCommand.getActionName(), digitalAsset.getId());
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_018);
    }

    return switch (digitalAssetAction) {
      case validate, fetch, ocr, upload ->
          processDigitalAssetAction(sessionContext, realmId, userId, digitalAssetCommand,
              digitalAssetAction, digitalAsset);
      case onupdate ->
          digitalAssetHelper.processAssetStatuses(sessionContext, realmId, userId, digitalAsset,
              false);
      default -> throw new UnsupportedOperationException("Action is not supported");
    };
  }

  private DigitalAssetDetailsResponse processDigitalAssetAction(SessionContext sessionContext,
      String realmId, String userId, DigitalAssetCommand digitalAssetCommand,
      AssetOperation digitalAssetAction, DigitalAsset digitalAsset) {
    // PREPARE DIGITAL ASSET
    prepareDigitalAsset(digitalAssetCommand, digitalAsset, digitalAssetAction);

    // PROCESS
    DigitalAssetDetailsResponse digitalAssetUpdateResponse = processDigitalAssetWithProvider(
        realmId, userId, digitalAssetAction, digitalAssetCommand);
    DigitalAssetDetails digitalAssetUpdate = digitalAssetUpdateResponse.getData();

    // POST PROCESS RESPONSE
    // UPDATE MEDIA DETAILS
    List<MediaDetail> mediaDetails = Optional.ofNullable(digitalAsset.getMediaDetails())
        .orElse(new ArrayList<>());
    processMediaDetails(digitalAssetUpdate.getMediaDetails());
    mediaDetails.addAll(
        Optional.ofNullable(digitalAssetUpdate.getMediaDetails()).orElse(Collections.emptyList()));
    digitalAsset.setMediaDetails(mediaDetails);

    // UPDATE Rejection DETAILS
    List<RejectionDetails> rejectionDetails = Optional.ofNullable(
        digitalAsset.getRejectionDetails()).orElse(new ArrayList<>());
    rejectionDetails.addAll(
        Optional.ofNullable(prepareRejectionDetails(digitalAssetUpdate.getRejectionDetails()))
            .orElse(Collections.emptyList()));
    //If rejectionDetails is not empty then set
    if (CollectionUtils.isNotEmpty(rejectionDetails)) {
      digitalAsset.setRejectionDetails(rejectionDetails);
    }
    // UPDATE DIGITAL ASSET ACTION
    Optional.ofNullable(digitalAsset.getActions()).orElse(Collections.emptyList()).stream()
        .filter(each -> Objects.equals(digitalAssetCommand.getActionName(), each.getName()))
        .findFirst().ifPresent(action -> Optional.ofNullable(digitalAssetUpdate.getStatus())
            .map(status -> DigitalAssetActionStatus.findBy(status.name()))
            .ifPresent(action::setStatus));

    // UPDATE EXTERNAL REFERENCE ID
    digitalAsset.setExternalReferenceId(
        Optional.ofNullable(digitalAssetUpdate.getExternalReferenceId())
            .orElse(digitalAsset.getExternalReferenceId()));

    // UPDATE DOCUMENT DATA
    Optional.ofNullable(digitalAssetUpdate.getDocumentData())
        .ifPresent(digitalAsset::setDocumentData);

    //UPDATE PayLoad
//    Optional.ofNullable(digitalAssetUpdate.getPayload()).ifPresent(digitalAsset::setPayload);

    //UPDATE VERIFICATION DETAIL
    Optional.ofNullable(digitalAssetUpdate.getVerificationDetail())
        .ifPresent(digitalAsset::setVerificationDetail);

    //UPDATE TAGS
    List<Tag> tags = Optional.ofNullable(digitalAsset.getTags()).orElse(new ArrayList<>());
    Optional.ofNullable(digitalAssetUpdate.getTags()).ifPresent(tags::addAll);
    digitalAsset.setTags(tags);

    //UPDATE expiry_ts
    Optional.ofNullable(digitalAssetUpdate.getExpiryTs()).ifPresent(digitalAsset::setExpiryTs);

    //UPDATE metadata
    List<DigitalAssetMetadata> metadata = Optional.ofNullable(digitalAsset.getMetadata())
        .orElse(new ArrayList<>());
    metadata.addAll(
        Optional.ofNullable(digitalAssetUpdate.getMetadata()).orElse(Collections.emptyList()));
    digitalAsset.setMetadata(metadata);

    DigitalAsset updatedDigitalAsset = digitalAssetsService.update(sessionContext, realmId, userId,
        digitalAsset.getId(), digitalAsset, false);
    DigitalAsset updatedDA = digitalAssetHelper.processAssetStatuses(sessionContext, realmId,
        userId, updatedDigitalAsset, false).getDigitalAsset();
    return DigitalAssetDetailsResponse.builder().digitalAsset(updatedDA).data(digitalAssetUpdate)
        .redirectUrl(digitalAssetUpdateResponse.getRedirectUrl())
        .providerReferenceId(digitalAssetUpdateResponse.getProviderReferenceId()).build();
  }

  private List<RejectionDetails> prepareRejectionDetails(List<RejectionDetails> rejectionDetails) {
    if (CollectionUtils.isEmpty(rejectionDetails)) {
      return null;
    }
    String timestamp = String.valueOf(Instant.now().getEpochSecond());
    return rejectionDetails.parallelStream().peek(rejection -> {
      if (StringUtils.isBlank(rejection.getTimestamp())) {
        rejection.setTimestamp(timestamp);
      }
    }).toList();
  }

  private List<MediaDetail> processMediaDetails(List<MediaDetail> mediaDetails) {
    if (CollectionUtils.isNotEmpty(mediaDetails)) {
      String epoch = String.valueOf(Instant.now().getEpochSecond());
      mediaDetails.parallelStream().forEach(mediaDetail -> {
        List<Tag> tags = Optional.ofNullable(mediaDetail.getTags()).orElse(new ArrayList<>());
        mediaDetail.setCreatedAt(Optional.ofNullable(mediaDetail.getCreatedAt()).orElse(epoch));
        mediaDetail.setTags(tags);
      });
    }
    return mediaDetails;
  }

  private DigitalAssetDetailsResponse processDigitalAssetWithProvider(String realmId, String userId,
      AssetOperation digitalAssetAction, DigitalAssetCommand digitalAssetCommand) {
    if (digitalAssetAction.equals(AssetOperation.upload)) {
      // This is simple upload and has no provider interaction
      DigitalAssetDetails digitalAsset = DigitalAssetDetails.builder()
          .mediaDetails(digitalAssetCommand.getMediaDetails()).tags(digitalAssetCommand.getTags())
          .metadata(digitalAssetCommand.getMetadata()).build();
      Optional.ofNullable(digitalAssetCommand.getStatus()).ifPresent(digitalAsset::setStatus);
      return DigitalAssetDetailsResponse.builder().data(digitalAsset).build();
    } else {
      return daProxyClient.processDigitalAssets(realmId, userId, digitalAssetAction,
          digitalAssetCommand);
    }
  }

  @Override
  public CollectionRequestResponse processCollectionRequest(SessionContext sessionContext,
      String realmId, String userId, String operation,
      CollectionRequestCommand collectionRequestCommand) {
    AssetOperation collectionRequestAction = AssetOperation.valueOf(operation);
    CollectionRequest collectionRequest = collectionRequestsService.read(realmId, userId,
        collectionRequestCommand.getCollectionRequestId());
    if (Objects.isNull(collectionRequest)) {
      log.error("Collection Request not found for Id: {}",
          collectionRequestCommand.getCollectionRequestId());
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_007,
          collectionRequestCommand.getCollectionRequestId());
    }

    return switch (collectionRequestAction) {
      case validate, fetch, ocr ->
          processCollectionRequestAction(sessionContext, realmId, userId, collectionRequestCommand,
              collectionRequestAction, collectionRequest);
      case processdigitalassets ->
          processDigitalAssetsAction(sessionContext, realmId, userId, collectionRequestCommand,
              collectionRequest);
      case appendassets ->
          appendAssetsToCollectionRequest(sessionContext, realmId, userId, collectionRequestCommand,
              collectionRequest);
      default -> CollectionRequestResponse.builder().data(collectionRequest).build();
    };
  }

  private CollectionRequestResponse appendAssetsToCollectionRequest(SessionContext sessionContext,
      String realmId, String userId, CollectionRequestCommand collectionRequestCommand,
      CollectionRequest collectionRequest) {
    if (allowAppend(collectionRequest) && !CollectionUtils.isEmpty(
        collectionRequestCommand.getCollectionRequestAssets())) {
      handleExistingAssets(sessionContext, collectionRequestCommand, collectionRequest);

      collectionRequest.getAssets().addAll(collectionRequestCommand.getCollectionRequestAssets());
      collectionRequest = collectionRequestsService.update(sessionContext, realmId, userId,
          collectionRequest.getId(),
          collectionRequestCreationHelper.process(sessionContext, realmId, userId,
              collectionRequest), true);
    }
    return CollectionRequestResponse.builder().data(collectionRequest).build();
  }

  private void handleExistingAssets(SessionContext sessionContext,
      CollectionRequestCommand collectionRequestCommand, CollectionRequest collectionRequest) {
    Set<String> newAssets = collectionRequestCommand.getCollectionRequestAssets().stream()
        .map(CollectionRequestAsset::getId).collect(Collectors.toSet());

    Set<String> existingAssets = collectionRequest.getAssets().stream()
        .map(CollectionRequestAsset::getId).collect(Collectors.toSet());

    Set<String> newAssetsAlreadyPresentInExisting = newAssets.stream()
        .filter(existingAssets::contains).collect(Collectors.toSet());

    if (Objects.nonNull(collectionRequestCommand.getAppendMode())
        && collectionRequestCommand.getAppendMode().equals(AppendMode.REPLACE)) {
      List<String> toBeDeletedAssets = collectionRequest.getAssets().stream()
          .filter(cra -> newAssetsAlreadyPresentInExisting.contains(cra.getId()))
          .map(CollectionRequestAsset::getDigitalAssetId).toList();

      collectionRequest.setAssets(collectionRequest.getAssets().stream()
          .filter(cra -> !newAssetsAlreadyPresentInExisting.contains(cra.getId()))
          .collect(Collectors.toList()));

      toBeDeletedAssets.forEach(
          da -> digitalAssetsService.delete(sessionContext, collectionRequest.getRealmId(),
              collectionRequest.getUserId(), da, false));
    } else {
      collectionRequestCommand.setCollectionRequestAssets(
          collectionRequestCommand.getCollectionRequestAssets().stream()
              .filter(cra -> !newAssetsAlreadyPresentInExisting.contains(cra.getId()))
              .collect(Collectors.toList()));
    }
  }

  private static boolean allowAppend(CollectionRequest collectionRequest) {
    return (Objects.nonNull(collectionRequest.getAllowEditAfterTerminalStatus())
        && collectionRequest.getAllowEditAfterTerminalStatus())
        || !CollectionRequestStatus.collectionRequestTerminalStatuses()
        .contains(collectionRequest.getStatus());
  }

  private CollectionRequestResponse processCollectionRequestAction(SessionContext sessionContext,
      String realmId, String userId, CollectionRequestCommand collectionRequestCommand,
      AssetOperation collectionRequestAction, CollectionRequest collectionRequest) {
    collectionRequestCommand.setStatus(AssetStatus.valueOf(collectionRequest.getStatus().name()));
    collectionRequestCommand.setActionEntity(ActionEntity.CollectionRequest);
    if (StringUtils.isBlank(collectionRequestCommand.getInitiatorReferenceId())) {
      collectionRequestCommand.setInitiatorReferenceId(
          collectionRequestCommand.getCollectionRequestId());
    }
    CollectionRequestResponse collectionRequestResponse = daProxyClient.processCollectionRequest(
        realmId, userId, collectionRequestAction, collectionRequestCommand);
    CollectionRequest collectionRequestResponseData = collectionRequestResponse.getData();
    collectionRequest.setStatus(Optional.ofNullable(collectionRequestResponseData.getStatus())
        .map(status -> CollectionRequestStatus.valueOf(status.name()))
        .orElse(collectionRequest.getStatus()));
//    collectionRequest.setExternalReferenceId(
//        Optional.ofNullable(digitalAssetUpdate.getExternalReferenceId())
//            .orElse(collectionRequest.getExternalReferenceId()));
    CollectionRequest updatedCollectionRequest = collectionRequestsService.update(sessionContext,
        realmId, userId, collectionRequest.getId(), collectionRequest, true);

    return CollectionRequestResponse.builder().data(updatedCollectionRequest)
        .redirectUrl(collectionRequestResponse.getRedirectUrl())
        .providerReferenceId(collectionRequestResponse.getProviderReferenceId()).build();
  }

  private CollectionRequestResponse processDigitalAssetsAction(SessionContext sessionContext,
      String realmId, String userId, CollectionRequestCommand collectionRequestCommand,
      CollectionRequest collectionRequest) {

    int lastIndex = collectionRequestCommand.getDigitalAssets().size() - 1;
    for (int i = 0; i < collectionRequestCommand.getDigitalAssets().size(); i++) {
      DigitalAsset da = collectionRequestCommand.getDigitalAssets().get(i);
      digitalAssetsService.update(sessionContext, da.getRealmId(), da.getUserId(), da.getId(), da,
          false);
      // For the last asset, we need to process the CR callbacks. so we are passing skipCollectionRequestCallbacks as true for the last asset.
      digitalAssetHelper.processAssetStatuses(sessionContext, da.getRealmId(), da.getUserId(), da,
          i < lastIndex);
    }
    return CollectionRequestResponse.builder().data(collectionRequest).build();
  }
}
