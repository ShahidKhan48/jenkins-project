package com.ninjacart.dms.dam.domain.consentmanagement.port.in;

import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.consentmanagement.model.Consent;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import java.util.List;

/**
 * Consents Management Service.
 */
public interface ConsentsService {

  /**
   * Create {@link Consent} with event sourcing.
   *
   * @param sessionContext session context
   * @param realmId        realm of the user.
   * @param userId         id of the user.
   * @param consent        entity to be created.
   * @return created {@link Consent}.
   */
  Consent create(SessionContext sessionContext, String realmId, String userId, Consent consent);

  /**
   * Fetch latest version of {@link Consent} based on give id.
   *
   * @param id      id of the {@link Consent}
   * @param realmId realm of the user
   * @param userId  id of the user
   * @return fetched {@link Consent}
   */
  Consent read(String realmId, String userId, String id);

  /**
   * Update {@link Consent} with event sourcing.
   *
   * @param sessionContext session context
   * @param realmId        realm of the user.
   * @param userId         id of the user.
   * @param id             id of the {@link Consent}.
   * @param consent        update entity.
   * @param sendEvent      sendEvent
   * @return updated {@link Consent}
   */
  Consent update(SessionContext sessionContext, String realmId, String userId, String id,
      Consent consent, boolean sendEvent);

  /**
   * Search {@link Consent} based on search query.
   *
   * @param realmId     realm of the user.
   * @param userId      id of the user.
   * @param searchQuery search query.
   * @param advanced    advanced search flag.
   * @return fetched {@link Consent}(s).
   */
  List<Consent> search(String realmId, String userId, SearchQuery searchQuery, Boolean advanced);
}
