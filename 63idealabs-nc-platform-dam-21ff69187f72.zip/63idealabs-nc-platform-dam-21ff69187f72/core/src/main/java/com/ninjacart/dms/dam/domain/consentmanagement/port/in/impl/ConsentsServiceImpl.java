package com.ninjacart.dms.dam.domain.consentmanagement.port.in.impl;

import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.PlatformManagedObjectService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.EntityStore;
import com.ninjacart.dms.dam.domain.consentmanagement.model.Consent;
import com.ninjacart.dms.dam.domain.consentmanagement.port.in.ConsentsService;
import java.util.List;

/**
 * Consent Service Platform Managed Implementation.
 */
public class ConsentsServiceImpl extends
    PlatformManagedObjectService<Consent> implements ConsentsService {

  public ConsentsServiceImpl(EntityStore entityStore) {
    super(entityStore);
  }

  @Override
  protected Class<Consent> type() {
    return Consent.class;
  }

  @Override
  public Consent create(SessionContext sessionContext, String realmId, String userId, Consent consent) {
    return super.create(sessionContext, realmId, userId, consent);
  }

  @Override
  public Consent read(String realmId, String userId, String id) {
    return super.read(realmId, userId, id);
  }

  @Override
  public Consent update(SessionContext sessionContext, String realmId, String userId, String id, Consent consent,
      boolean sendEvent) {
    return super.update(sessionContext, realmId, userId, id, consent, sendEvent);
  }

  @Override
  public List<Consent> search(String realmId, String userId, SearchQuery searchQuery,
      Boolean advanced) {
    return super.search(realmId, userId, searchQuery, advanced);
  }
}
