/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.filemanagement.port.in.impl;

import com.ninjacart.dms.dam.constants.CoreConstants;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.StorageProvider;
import com.ninjacart.dms.dam.domain.assetmanagement.model.MediaDetail;
import com.ninjacart.dms.dam.domain.filemanagement.model.FileContent;
import com.ninjacart.dms.dam.domain.filemanagement.port.in.FileManagementService;
import com.ninjacart.dms.dam.domain.filemanagement.port.out.CloudStorageProviderFactory;
import com.ninjacart.dms.dam.domain.filemanagement.port.out.CloudStorageService;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;


/**
 * Implementation for File Management.
 */
@Slf4j
@RequiredArgsConstructor
public class FileManagementServiceImpl implements FileManagementService {

  private static final String PATH_SEPARATOR = "/";

  private final CloudStorageProviderFactory cloudStorageProviderFactory;

  @Override
  public MediaDetail uploadFile(String realmId, String userId, String path, List<FileContent> files,
      String storageProvider) {
    FileContent file = files.get(files.size() - 1);

    String extension = FilenameUtils.getExtension(file.getOriginalFilename());
    String fileUrl = uploadDocument(realmId, userId, file.getByteContent(), path,
        file.getContentType(), extension, true, storageProvider);

    return MediaDetail.builder().mediaUrl(fileUrl).build();

  }

  @Override
  public List<MediaDetail> presignUrls(String realmId, String userId,
      List<MediaDetail> mediaDetails, Integer expiryInMin) {
    Map<StorageProvider, List<MediaDetail>> mediaDetailsByStorageProvider = mediaDetails.stream()
        .peek(each -> {
          if (Objects.isNull(each.getStorageProvider())) {
            each.setStorageProvider(
                StorageProvider.valueOf(cloudStorageProviderFactory.getDefaultStorageProvider()));
          }
        }).collect(Collectors.groupingBy(MediaDetail::getStorageProvider));
    List<MediaDetail> response = new ArrayList<>();

    mediaDetailsByStorageProvider.forEach((provider, media) -> response.addAll(
        cloudStorageProviderFactory.getCloudStorageService(provider.name())
            .presignUrl(media, expiryInMin)));

    return response;
  }

  private String uploadDocument(String realmId, String userId, byte[] content, String path,
      String contentType, String fileExtension, boolean addExtensionPeriod,
      String storageProvider) {
    if (!StringUtils.isEmpty(path)) {
      path = path.trim().replaceAll("\\s+", StringUtils.EMPTY);
    } else {
      path = LocalDate.now().format(DateTimeFormatter.ofPattern(CoreConstants.SIMPLE_DATE_FORMAT));
    }
    String filePath = getDocumentUploadFilePath(realmId, userId, path, fileExtension,
        addExtensionPeriod);
    return getImageUrl(content, contentType, filePath, storageProvider);
  }

  private String getImageUrl(byte[] bytes, String contentType, String filePath,
      String storageProvider) {
    CloudStorageService cloudStorageService = cloudStorageProviderFactory.getCloudStorageService(
        storageProvider);
    return cloudStorageService.uploadPrivate(null, filePath, bytes, contentType, null);
  }

  private String getDocumentUploadFilePath(String realmId, String userId, String path,
      String fileExtension, boolean addExtensionPeriod) {
    String filePath = String.join(PATH_SEPARATOR,
        List.of(realmId, userId, path, String.valueOf(System.currentTimeMillis())));
    if (Objects.nonNull(fileExtension)) {
      filePath = filePath + (addExtensionPeriod ? "." : "") + fileExtension;
    }
    return filePath;
  }

  @Override
  public List<MediaDetail> deleteMedia(List<MediaDetail> mediaDetails) {
    if (CollectionUtils.isEmpty(mediaDetails)) {
      return mediaDetails;
    }
    Map<StorageProvider, List<MediaDetail>> mediaDetailsByStorageProvider = mediaDetails.stream()
        .peek(each -> {
          if (Objects.isNull(each.getStorageProvider())) {
            each.setStorageProvider(
                StorageProvider.valueOf(cloudStorageProviderFactory.getDefaultStorageProvider()));
          }
        }).collect(Collectors.groupingBy(MediaDetail::getStorageProvider));
    List<MediaDetail> response = new ArrayList<>();

    mediaDetailsByStorageProvider.forEach((provider, mediaForProvider) -> {
      mediaForProvider.forEach(
          media -> cloudStorageProviderFactory.getCloudStorageService(provider.name())
              .delete(null, media.getMediaUrl(), null));
      response.addAll(mediaForProvider);
    });

    return response;
  }
}
