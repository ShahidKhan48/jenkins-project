/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DigitalAssetDefinition.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class DigitalAssetDefinition implements PlatformManagedObject {

  private String id;
  private String name;
  private ExpiryDetail expiryDetail;
  private List<DigitalAssetDefinitionAction> actions;
  private List<Tag> tags;
  private List<DigitalAssetDefinitionMetadata> metadata;
  private DigitalAssetDefinitionRejectionDetails rejectionDetails;
  private List<MediaDetail> referenceDocs;

  private String createdAt;
  private String updatedAt;
  private String createdByTool;
  private String updatedByTool;
  private String createdBy;
  private String updatedBy;
}
