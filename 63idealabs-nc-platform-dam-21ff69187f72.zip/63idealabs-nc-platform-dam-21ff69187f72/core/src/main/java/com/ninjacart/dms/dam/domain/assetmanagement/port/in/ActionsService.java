package com.ninjacart.dms.dam.domain.assetmanagement.port.in;

import com.ninjacart.dms.dam.domain.assetmanagement.command.CollectionRequestCommand;
import com.ninjacart.dms.dam.domain.assetmanagement.command.DigitalAssetCommand;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestResponse;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDetailsResponse;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;

/**
 * Execute Action.
 */
public interface ActionsService {

  /**
   * Process {@link DigitalAssetCommand} based on the {@param operation}.
   *
   * @param sessionContext      session context
   * @param realmId             realm of the user.
   * @param userId              id of the user.
   * @param operation           operation to be performed Eg: fetch/validate
   * @param digitalAssetCommand request object
   * @return fetched/processed {@link DigitalAsset}(s).
   */
  DigitalAssetDetailsResponse processDigitalAsset(SessionContext sessionContext, String realmId,
      String userId, String operation, DigitalAssetCommand digitalAssetCommand);

  /**
   * Process {@link CollectionRequestCommand} based on the {@param operation}.
   *
   * @param sessionContext
   * @param realmId                  realm of the user.
   * @param userId                   id of the user.
   * @param operation                operation to be performed Eg: fetch/validate
   * @param collectionRequestCommand request object
   * @return fetched/processed {@link CollectionRequest}(s).
   */
  CollectionRequestResponse processCollectionRequest(SessionContext sessionContext, String realmId, String userId,
      String operation, CollectionRequestCommand collectionRequestCommand);
}
