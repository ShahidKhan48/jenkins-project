/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.filemanagement.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * FileContent.
 */
@AllArgsConstructor
@Builder
@NoArgsConstructor
@Data
public class FileContent {

  private byte[] byteContent;
  private String originalFilename;
  private String contentType;
}
