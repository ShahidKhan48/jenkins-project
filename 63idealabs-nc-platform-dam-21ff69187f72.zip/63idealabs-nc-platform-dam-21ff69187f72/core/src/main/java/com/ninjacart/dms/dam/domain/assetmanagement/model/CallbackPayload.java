/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CallbackPayload {

  private String realmId;
  private String userId;
  private String digitalAssetId;
  private String collectionRequestId;
}
