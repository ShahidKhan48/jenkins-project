/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import java.io.Serializable;
import java.util.List;
import lombok.Data;

/**
 * Event with callbackUrl and required constraints to perform callback
 */

@Data
public class Event implements Serializable {

  private String callbackUrl;
  private List<EventData> eventData;
}

