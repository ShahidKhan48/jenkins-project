/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CollectionRequestTemplate.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CollectionRequestTemplate implements PlatformManagedObject {

  private String id;
  private String name;
  private List<CollectionRequestAsset> assets;
  private List<Tag> tags;
  private List<CollectionRequestAction> actions;
  private Boolean allowEditAfterTerminalStatus;
  private Boolean disableAutoSubmit;
  private Boolean disableAutoApproval;

  private String createdAt;
  private String updatedAt;
  private String createdByTool;
  private String updatedByTool;
  private String createdBy;
  private String updatedBy;
}
