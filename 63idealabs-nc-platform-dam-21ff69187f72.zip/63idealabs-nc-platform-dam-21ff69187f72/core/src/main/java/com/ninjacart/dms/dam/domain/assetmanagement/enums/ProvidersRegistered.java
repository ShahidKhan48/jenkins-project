/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

/**
 * DAM Providers.
 */
public enum ProvidersRegistered {
  karza, equifax, digio, crif, scienaptic, scoreme, perfios, ninjacart, finbox, knap, cpv, shuftipro, ckyc, digilocker, srm, astute, monnai
}
