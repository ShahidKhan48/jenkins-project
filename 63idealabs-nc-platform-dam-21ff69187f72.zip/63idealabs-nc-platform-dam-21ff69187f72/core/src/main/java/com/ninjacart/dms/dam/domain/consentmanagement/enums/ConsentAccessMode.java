package com.ninjacart.dms.dam.domain.consentmanagement.enums;

/**
 * Consent Access Mode.
 */
public enum ConsentAccessMode {
  VIEW, STORE, STREAM, QUERY
}
