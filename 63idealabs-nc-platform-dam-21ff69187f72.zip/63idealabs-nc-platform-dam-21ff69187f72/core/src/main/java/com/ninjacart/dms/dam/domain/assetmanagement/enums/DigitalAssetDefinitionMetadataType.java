/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

import lombok.Getter;

/**
 * DigitalAssetDefinitionMetadataType - Used to identify the type of the metadata field data type.
 */
@Getter
public enum DigitalAssetDefinitionMetadataType {
  string, number, Boolean;
}
