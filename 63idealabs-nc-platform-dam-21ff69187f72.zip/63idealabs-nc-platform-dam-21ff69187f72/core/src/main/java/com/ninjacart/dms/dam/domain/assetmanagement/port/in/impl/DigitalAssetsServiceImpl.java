/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl;

import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.MediaDetail;
import com.ninjacart.dms.dam.domain.assetmanagement.model.RejectionDetails;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.DigitalAssetsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.EntityStore;
import com.ninjacart.dms.dam.domain.filemanagement.port.in.FileManagementService;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class DigitalAssetsServiceImpl extends PlatformManagedObjectService<DigitalAsset> implements
    DigitalAssetsService {

  private final FileManagementService fileManagementService;

  public DigitalAssetsServiceImpl(EntityStore entityStore,
      FileManagementService fileManagementService) {
    super(entityStore);
    this.fileManagementService = fileManagementService;
  }

  @Override
  protected Class<DigitalAsset> type() {
    return DigitalAsset.class;
  }

  @Override
  public DigitalAsset create(SessionContext sessionContext, String realmId, String userId, DigitalAsset digitalAsset) {
    digitalAsset.setRealmId(realmId);
    digitalAsset.setUserId(userId);
    return super.create(sessionContext, realmId, userId, digitalAsset);
  }

  @Override
  public DigitalAsset read(String realmId, String userId, String id) {
    return super.read(realmId, userId, id);
  }

  @Override
  public DigitalAsset update(SessionContext sessionContext, String realmId, String userId, String id, DigitalAsset digitalAsset,
      boolean sendEvent) {
    updateRejectionDetails(digitalAsset);

    return super.update(sessionContext, realmId, userId, id, digitalAsset, sendEvent);
  }

  private void updateRejectionDetails(DigitalAsset digitalAsset) {
    if (Optional.ofNullable(digitalAsset.getRejectionDetails()).isPresent()) {
      digitalAsset.setRejectionDetails(prepareRejectionDetails(digitalAsset.getRejectionDetails()));
    }
  }

  private List<RejectionDetails> prepareRejectionDetails(List<RejectionDetails> rejectionDetails) {
    if (CollectionUtils.isEmpty(rejectionDetails)) {
      return null;
    }
    String timestamp = String.valueOf(Instant.now().getEpochSecond());
    return rejectionDetails.parallelStream().peek(rejection -> {
      if (StringUtils.isBlank(rejection.getTimestamp())) {
        rejection.setTimestamp(timestamp);
      }
    }).toList();
  }

  @Override
  public List<DigitalAsset> search(String realmId, String userId, SearchQuery searchQuery,
      Boolean advanced) {
    return super.search(realmId, userId, searchQuery, advanced);
  }

  @Override
  public List<DigitalAsset> createAll(SessionContext sessionContext, String realmId, String userId,
      List<DigitalAsset> digitalAssets) {
    return super.createAll(sessionContext, realmId, userId, digitalAssets);
  }

  @Override
  public List<DigitalAsset> updateAll(SessionContext sessionContext, String realmId, String userId,
      List<DigitalAsset> digitalAssets) {
    return super.updateAll(sessionContext, realmId, userId, digitalAssets);
  }

  @Override
  public DigitalAsset delete(SessionContext sessionContext, String realmId, String userId, String id, Boolean deleteMedia) {
    DigitalAsset digitalAsset = super.delete(sessionContext, realmId, userId, id);

    if (Objects.nonNull(deleteMedia) && deleteMedia) {
      deleteMediaOfAsset(digitalAsset);
    }

    return digitalAsset;
  }

  @Override
  public List<DigitalAsset> deleteBySearch(SessionContext sessionContext, String realmId, String userId, SearchQuery searchQuery,
      Boolean advanced, Boolean deleteMedia) {
    List<DigitalAsset> digitalAssets = super.deleteBySearch(sessionContext, realmId, userId, searchQuery, advanced);
    if (Objects.nonNull(deleteMedia) && deleteMedia) {
      digitalAssets.forEach(this::deleteMediaOfAsset);
    }
    return digitalAssets;
  }

  private List<MediaDetail> deleteMediaOfAsset(DigitalAsset digitalAsset) {
    return fileManagementService.deleteMedia(digitalAsset.getMediaDetails());
  }
}
