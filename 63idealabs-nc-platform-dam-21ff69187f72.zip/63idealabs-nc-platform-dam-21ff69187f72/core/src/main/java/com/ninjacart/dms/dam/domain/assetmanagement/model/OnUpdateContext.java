/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import java.util.List;
import java.util.Map;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OnUpdateContext {

  private DigitalAsset digitalAsset;
  private List<DigitalAsset> digitalAssets;
  private Map<String, DigitalAsset> digitalAssetsToSave;
  private CollectionRequest collectionRequest;
  private List<CollectionRequest> collectionRequests;
  private Map<String, CollectionRequest> collectionRequestsToSave;
  private List<DigitalAssetDefinition> digitalAssetDefinitions;
  /**
   * Flag to indicate whether to skip the collection request callbacks or not. This will be useful
   * when we are processing DAs in bulk, and we want to trigger CR callbacks only once as a last
   * step after processing.
   */
  private boolean skipCollectionRequestCallbacks;
}
