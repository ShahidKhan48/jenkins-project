/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.ProvidersRegistered;
import java.io.Serializable;
import java.time.OffsetDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * VerificationDetail.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VerificationDetail implements Serializable {

  private ProvidersRegistered provider;
  private OffsetDateTime verifiedTs;
}
