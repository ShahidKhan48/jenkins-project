package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.ActionMode;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.AssetOperation;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.InitiatorType;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.InputType;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.ProvidersRegistered;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DigitalAssetDefinitionAction.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DigitalAssetDefinitionAction {

  private String name;
  private InitiatorType initiatorType;
  private AssetOperation operation;
  private ActionMode mode;
  private List<InputType> inputType;
  private List<ProvidersRegistered> provider;
}
