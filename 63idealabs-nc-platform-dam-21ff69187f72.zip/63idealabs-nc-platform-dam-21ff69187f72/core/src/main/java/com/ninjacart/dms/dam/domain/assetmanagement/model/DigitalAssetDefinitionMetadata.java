/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.DigitalAssetDefinitionMetadataFieldType;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.DigitalAssetDefinitionMetadataType;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DigitalAssetDefinitionMetadata
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DigitalAssetDefinitionMetadata {

  private DigitalAssetDefinitionMetadataType type;
  private DigitalAssetDefinitionMetadataFieldType fieldType;
  private String label;
  private String key;
  private List<String> options;
  private Boolean optional;
  private Integer minValue;
  private Integer maxValue;
}
