/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.filemanagement.port.in;

import com.ninjacart.dms.dam.domain.assetmanagement.model.MediaDetail;
import com.ninjacart.dms.dam.domain.filemanagement.model.FileContent;
import java.util.List;


/**
 * File Management Port.
 */
public interface FileManagementService {

  /**
   * Uploads file
   *
   * @param realmId         realm Id
   * @param userId          user Id
   * @param path            path provided
   * @param files           file contents
   * @param storageProvider provider
   * @return media details
   */
  MediaDetail uploadFile(String realmId, String userId, String path, List<FileContent> files,
      String storageProvider);

  /**
   * Presign url.
   *
   * @param realmId      realm Id
   * @param userId       user Id
   * @param mediaDetails media
   * @param expiryInSec
   * @return presigned media details
   */
  List<MediaDetail> presignUrls(String realmId, String userId, List<MediaDetail> mediaDetails,
      Integer expiryInSec);

  /**
   * Delete Media.
   *
   * @param media media
   * @return deleted media
   */
  List<MediaDetail> deleteMedia(List<MediaDetail> media);
}
