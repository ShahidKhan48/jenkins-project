package com.ninjacart.dms.dam.domain.consentmanagement.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ninjacart.dms.dam.domain.consentmanagement.enums.ConsentDetailsType;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Consent Details.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConsentDetails {

  private String data;
  private ConsentDetailsType consentType;
  private List<ConsentPermission> permission;
  private List<ConsentContextParameter> contextReference;
}
