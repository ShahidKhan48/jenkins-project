/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

/**
 * Action Initiator.
 */
public enum InitiatorType {
  USER, SYSTEM
}