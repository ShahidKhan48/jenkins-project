package com.ninjacart.dms.dam.domain.consentmanagement.enums;

/**
 * Consent Status.
 */
public enum ConsentStatus {
  REQUESTED, GRANTED, REVOKED, REJECTED, APPROVED, CANCELLED, EXPIRED
}
