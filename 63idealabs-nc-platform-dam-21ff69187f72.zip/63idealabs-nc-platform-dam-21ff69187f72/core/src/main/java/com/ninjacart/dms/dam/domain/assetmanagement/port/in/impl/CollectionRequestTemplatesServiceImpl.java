/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl;

import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestTemplate;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.CollectionRequestTemplatesService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.EntityStore;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

/**
 * Collection Request Template service implementation.
 */
@Slf4j
public class CollectionRequestTemplatesServiceImpl extends
    PlatformManagedObjectService<CollectionRequestTemplate> implements
    CollectionRequestTemplatesService {

  public CollectionRequestTemplatesServiceImpl(EntityStore entityStore) {
    super(entityStore);
  }

  @Override
  public CollectionRequestTemplate create(SessionContext sessionContext, String realmId, String userId,
      CollectionRequestTemplate collectionRequestTemplate) {
    return super.create(sessionContext, realmId, userId, collectionRequestTemplate);
  }

  @Override
  public CollectionRequestTemplate read(String realmId, String userId, String id) {
    return super.read(realmId, userId, id);
  }

  @Override
  public CollectionRequestTemplate update(SessionContext sessionContext, String realmId, String userId, String id,
      CollectionRequestTemplate collectionRequestTemplate, boolean sendEvent) {
    return super.update(sessionContext, realmId, userId, id, collectionRequestTemplate, sendEvent);
  }

  @Override
  public List<CollectionRequestTemplate> search(String realmId, String userId,
      SearchQuery searchQuery, Boolean advanced) {
    return super.search(realmId, userId, searchQuery, advanced);
  }

  @Override
  public CollectionRequestTemplate delete(SessionContext sessionContext, String realmId, String userId, String id) {
    return super.delete(sessionContext, realmId, userId, id);
  }

  @Override
  public List<CollectionRequestTemplate> deleteBySearch(SessionContext sessionContext, String realmId, String userId,
      SearchQuery searchQuery, Boolean advanced) {
    return super.deleteBySearch(sessionContext, realmId, userId, searchQuery, advanced);
  }

  @Override
  protected Class<CollectionRequestTemplate> type() {
    return CollectionRequestTemplate.class;
  }
}
