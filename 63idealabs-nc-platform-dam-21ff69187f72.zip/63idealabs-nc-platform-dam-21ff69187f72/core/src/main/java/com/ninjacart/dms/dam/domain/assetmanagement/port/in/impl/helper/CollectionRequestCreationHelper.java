/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.helper;

import com.ninjacart.dms.dam.constants.CoreConstants;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.AssetStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.CollectionRequestStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.DigitalAssetActionMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.model.Tag;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.DigitalAssetsService;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import java.util.stream.Stream;

/**
 * Collection Request Creation Helper.
 */
@RequiredArgsConstructor
@Slf4j
public class CollectionRequestCreationHelper {

  private final DigitalAssetsService digitalAssetsService;

  /**
   * Invoke on creation of Collection Request.
   *
   * @param sessionContext           session context
   * @param realmId                  realm Id
   * @param userId                   user Id
   * @param createdCollectionRequest collection request
   * @return updated collection request
   */
  public CollectionRequest process(SessionContext sessionContext, String realmId, String userId,
      CollectionRequest createdCollectionRequest) {
    List<DigitalAsset> digitalAssetsInCR = new ArrayList<>();

    // Update CR Assets with existing DA Ids and status
    updateWithExistingDigitalAssets(realmId, userId, createdCollectionRequest, digitalAssetsInCR);

    // Create remaining DAs and update CR Assets with DA Ids and status
    digitalAssetsInCR.addAll(createRemainingMandatoryDigitalAssets(sessionContext, realmId, userId,
        createdCollectionRequest));

    // Set CR status based on DA statuses.
    setStatus(createdCollectionRequest, digitalAssetsInCR);

    // Emptying tags from CR assets before saving to DB.
    createdCollectionRequest.getAssets().forEach(asset -> asset.setTags(null));
    return createdCollectionRequest;
  }

  private Optional<CollectionRequestStatus> setStatus(CollectionRequest createdCollectionRequest,
      List<DigitalAsset> digitalAssetsInCR) {
    Optional<CollectionRequestStatus> collectionRequestStatus = DigitalAssetHelper.getCollectionRequestStatus(
        digitalAssetsInCR, createdCollectionRequest);
    collectionRequestStatus.ifPresent(createdCollectionRequest::setStatus);
    return collectionRequestStatus;
  }

  private List<DigitalAsset> createRemainingMandatoryDigitalAssets(SessionContext sessionContext,
      String realmId, String userId, CollectionRequest createdCollectionRequest) {
    List<DigitalAsset> existingDigitalAssets = Objects.requireNonNull(
            createdCollectionRequest.getAssets()).stream().filter(
            each -> Objects.nonNull(each.getDigitalAssetId()) && Objects.equals(
                each.getIsTransactional(), Boolean.TRUE))
        .map(each -> digitalAssetsService.read(realmId, userId, each.getDigitalAssetId()))
        .collect(Collectors.toList());
    List<DigitalAsset> digitalAssetsToCreate = Objects.requireNonNull(
            createdCollectionRequest.getAssets()).stream()
        .filter(each -> Objects.isNull(each.getDigitalAssetId())).map(
//            temporarily creating all digital assets for a collection, ignoring mandatory flag
//            && Objects.nonNull(each.getIsMandatory()) && each.getIsMandatory()).map(
            each -> DigitalAsset.builder().realmId(realmId).userId(userId)
                .digitalAssetDefinitionId(each.getId()).name(each.getName()).tags(
                    Stream.concat(getTagsStream(createdCollectionRequest.getTags()),
                        getTagsStream(each.getTags())).toList()).status(AssetStatus.PENDING)
                .comment(String.format(CoreConstants.CREATED_FOR_COLLECTION_REQUEST,
                    createdCollectionRequest.getId()))
                .collectionRequestId(createdCollectionRequest.getId())
                .callbackUrl(each.getCallbackUrl())
                .actions(DigitalAssetActionMapper.INSTANCE.toDigitalAssetAction(each.getActions()))
                .build()).toList();

    if (CollectionUtils.isEmpty(digitalAssetsToCreate)) {
      return Collections.emptyList();
    } else {
      List<DigitalAsset> createdDigitalAssets = digitalAssetsService.createAll(sessionContext, realmId, userId,
          digitalAssetsToCreate);
      Map<String, DigitalAsset> digitalAssetMap = createdDigitalAssets.stream().collect(
          Collectors.toMap(DigitalAsset::getDigitalAssetDefinitionId, Function.identity()));
      createdCollectionRequest.getAssets().parallelStream().forEach(each -> {
        Optional.ofNullable(digitalAssetMap.get(each.getId())).ifPresent(digitalAsset -> {
          each.setDigitalAssetId(digitalAsset.getId());
          each.setStatus(digitalAsset.getStatus());
        });
      });

      if (CollectionUtils.isEmpty(existingDigitalAssets)) {
        return createdDigitalAssets;
      }
      existingDigitalAssets.addAll(createdDigitalAssets);
      return existingDigitalAssets;
    }
  }

  /**
   * Helper method to create a stream out of List of tags with null checks.
   *
   * @param tags List of Tag objects
   * @return Stream of Tags
   */
  private Stream<Tag> getTagsStream(List<Tag> tags) {
    return tags != null ? tags.stream().filter(Objects::nonNull) : Stream.empty();
  }

  /* while creating collectionRequest if digitalAsset is transactional and digitalAssetId is present
   then don't create new digitalAsset,read it from digitalAssetId and link it in collectionRequest.
   */
  private List<DigitalAsset> getTransactionalDigitalAssets(String realmId, String userId,
      CollectionRequest createdCollectionRequest) {
    List<String> transactionalIds = Objects.requireNonNull(createdCollectionRequest.getAssets())
        .stream().filter(each -> Objects.nonNull(each.getDigitalAssetId()) && Objects.equals(
            each.getIsTransactional(), Boolean.TRUE)).map(CollectionRequestAsset::getDigitalAssetId)
        .collect(Collectors.toList());

    if (CollectionUtils.isEmpty(transactionalIds)) {
      return Collections.emptyList();
    }
    return digitalAssetsService.search(realmId, userId,
        DigitalAssetHelper.searchQueryForIds(transactionalIds), false);
  }

  private CollectionRequest updateWithExistingDigitalAssets(String realmId, String userId,
      CollectionRequest createdCollectionRequest, List<DigitalAsset> digitalAssetsInCR) {
    List<String> digitalAssetDefinitionIds = Objects.requireNonNull(
        createdCollectionRequest.getAssets()).stream().filter(
        collectionRequestAsset -> !Objects.equals(collectionRequestAsset.getIsTransactional(),
            Boolean.TRUE)).map(CollectionRequestAsset::getId).toList();
    List<DigitalAsset> digitalAssets = digitalAssetsService.search(realmId, userId,
        DigitalAssetHelper.searchQueryForExistingAssets(digitalAssetDefinitionIds), false);

    // TODO: Revisit merge function. Incase of collision due to transactional docs, transaction docs
    //  should be ignored and the latest digital asset thats not transactional should be picked.
    Map<String, DigitalAsset> digitalAssetsMappedByDadId = digitalAssets.stream().collect(
        Collectors.toMap(DigitalAsset::getDigitalAssetDefinitionId, Function.identity(),
            (da1, da2) -> da2));

    createdCollectionRequest.getAssets().forEach(
        each -> Optional.ofNullable(digitalAssetsMappedByDadId.get(each.getId()))
            .ifPresent(digitalAsset -> {
              each.setDigitalAssetId(digitalAsset.getId());
              each.setStatus(digitalAsset.getStatus());
              digitalAssetsInCR.add(digitalAsset);
            }));
    return createdCollectionRequest;
  }
}
