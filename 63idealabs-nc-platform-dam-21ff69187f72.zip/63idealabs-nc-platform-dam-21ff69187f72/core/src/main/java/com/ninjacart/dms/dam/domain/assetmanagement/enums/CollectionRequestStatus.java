/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

import java.util.Arrays;
import java.util.List;

/**
 * Collection Request Status.
 */
public enum CollectionRequestStatus {
  APPROVED, REJECTED, PENDING, SUBMITTED, USER_INPUT_REQUIRED;

  public static List<CollectionRequestStatus> collectionRequestTerminalStatuses() {
    return Arrays.asList(APPROVED, REJECTED);
  }
}
