/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.command;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.ActionEntity;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.AssetStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetMetadata;
import com.ninjacart.dms.dam.domain.assetmanagement.model.MediaDetail;
import com.ninjacart.dms.dam.domain.assetmanagement.model.RejectionDetails;
import com.ninjacart.dms.dam.domain.assetmanagement.model.Tag;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Action Request.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalAssetCommand {

  private String provider;
  private String collectionRequestId;
  private String digitalAssetDefinitionId;
  private List<Tag> tags;
  private List<MediaDetail> mediaDetails;
  private Object payload;
  private String assetType;
  private String assetIdentifier;
  private String providerReferenceId;
  private String initiatorReferenceId;
  private String digitalAssetId;
  private AssetStatus status;
  private String actionName;
  private ActionEntity actionEntity;
  private List<DigitalAssetMetadata> metadata;
  private List<RejectionDetails> rejectionDetails;
}
