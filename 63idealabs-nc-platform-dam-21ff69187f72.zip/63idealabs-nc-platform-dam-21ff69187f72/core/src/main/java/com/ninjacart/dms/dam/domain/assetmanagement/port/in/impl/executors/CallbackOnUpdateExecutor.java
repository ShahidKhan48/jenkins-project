/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors;

import com.ninjacart.dms.dam.domain.assetmanagement.model.CallbackPayload;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.OnUpdateContext;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.CallbackClient;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * CallbackOnUpdateExecutor - Handles Collection Request and Digital Assets callbacks.
 */
@Slf4j
@RequiredArgsConstructor
public class CallbackOnUpdateExecutor implements OnUpdateExecutor {

  private final CallbackClient callbackClient;

  @Override
  public void execute(SessionContext sessionContext, String realmId, String userId,
      OnUpdateContext onUpdateContext) {
    if (CollectionUtils.isNotEmpty(onUpdateContext.getDigitalAssetsToSave().values())
        || CollectionUtils.isNotEmpty(onUpdateContext.getCollectionRequestsToSave().values())
        || Objects.isNull(onUpdateContext.getCollectionRequest())) {
      return;
    }

    triggerDigitalAssetCallbacks(onUpdateContext.getDigitalAssets().stream().filter(
        da -> Objects.equals(onUpdateContext.getCollectionRequest().getId(),
            da.getCollectionRequestId())).toList());
    // Call CR callbacks only if it's not a skip collection request callback.
    if (!onUpdateContext.isSkipCollectionRequestCallbacks()) {
      triggerCollectionRequestCallback(onUpdateContext.getCollectionRequest());
    }
  }

  private void triggerCollectionRequestCallback(CollectionRequest collectionRequest) {
    if (Objects.nonNull(collectionRequest) && StringUtils.isNotBlank(
        collectionRequest.getCallbackUrl())) {
      try {
        callbackClient.executeCallback(collectionRequest.getCallbackUrl(),
            CallbackPayload.builder().realmId(collectionRequest.getRealmId())
                .userId(collectionRequest.getUserId())
                .collectionRequestId(collectionRequest.getId()).build());
      } catch (Exception e) {
        // Swallowing exception - callback failure shouldn't affect program execution
        log.error("Error in CR Callback. {}", e.getMessage(), e);
      }
    }
  }

  private void triggerDigitalAssetCallbacks(List<DigitalAsset> digitalAssets) {
    digitalAssets.forEach(digitalAsset -> {
      if (Objects.nonNull(digitalAsset) && StringUtils.isNotBlank(digitalAsset.getCallbackUrl())) {
        try {
          callbackClient.executeCallback(digitalAsset.getCallbackUrl(),
              CallbackPayload.builder().realmId(digitalAsset.getRealmId())
                  .userId(digitalAsset.getUserId()).digitalAssetId(digitalAsset.getId()).build());
        } catch (Exception e) {
          // Swallowing exception - callback failure shouldn't affect program execution
          log.error("Error in DA Callback. {}", e.getMessage(), e);
        }
      }
    });
  }
}
