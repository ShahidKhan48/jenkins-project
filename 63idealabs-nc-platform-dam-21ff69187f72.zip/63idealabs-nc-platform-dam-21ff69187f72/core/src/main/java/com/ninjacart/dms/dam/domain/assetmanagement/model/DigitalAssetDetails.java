package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.AssetStatus;
import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Represents the details of a digital asset within the asset management system.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class DigitalAssetDetails implements Serializable {

  private String id;
  private String realmId;
  private String userId;
  private String name;
  private OffsetDateTime expiryTs;
  private AssetStatus status;
  private List<Tag> tags;
  private String comment;
  private List<RejectionDetails> rejectionDetails;
  private String externalReferenceId;
  private String digitalAssetDefinitionId;
  private List<MediaDetail> mediaDetails;
  private VerificationDetail verificationDetail;
  private DocumentData documentData;
  private String collectionRequestId;
  private Object payload;
  private String callbackUrl;
  private List<DigitalAssetAction> actions;
  private List<DigitalAssetMetadata> metadata;
  private List<Object> errorList;

  private String createdAt;
  private String updatedAt;
  private String createdByTool;
  private String updatedByTool;
  private String createdBy;
  private String updatedBy;
}
