/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.AssetStatus;
import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CollectionRequestAsset.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class CollectionRequestAsset implements Serializable {

  private String id;
  private String name;
  private String group;
  private Boolean isMandatory;
  private List<CollectionRequestAction> actions;
  private String digitalAssetId;
  private AssetStatus status;
  private List<Tag> tags;
  private String callbackUrl;
  private Boolean isTransactional;
  private String description;
  private String guideline;
}
