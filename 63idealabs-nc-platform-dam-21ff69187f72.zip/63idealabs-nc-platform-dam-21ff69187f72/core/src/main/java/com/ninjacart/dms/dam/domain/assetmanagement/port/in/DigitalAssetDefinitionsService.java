/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in;

import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDefinition;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import java.util.List;

/**
 * Digital Asset Definitions Service.
 */
public interface DigitalAssetDefinitionsService {

  /**
   * Create {@link DigitalAssetDefinition} with event sourcing.
   *
   * @param sessionContext         session context
   * @param realmId                realm of the user.
   * @param userId                 id of the user.
   * @param DigitalAssetDefinition entity to be created.
   * @return created {@link DigitalAssetDefinition}.
   */
  DigitalAssetDefinition create(SessionContext sessionContext, String realmId, String userId,
      DigitalAssetDefinition DigitalAssetDefinition);

  /**
   * Fetch latest version of {@link DigitalAssetDefinition} based on give id.
   *
   * @param id      id of the {@link DigitalAssetDefinition}
   * @param realmId realm of the user
   * @param userId  id of the user
   * @return fetched {@link DigitalAssetDefinition}
   */
  DigitalAssetDefinition read(String realmId, String userId, String id);

  /**
   * Update {@link DigitalAssetDefinition} with event sourcing.
   *
   * @param sessionContext         session context
   * @param realmId                realm of the user.
   * @param userId                 id of the user.
   * @param id                     id of the {@link DigitalAssetDefinition}.
   * @param digitalAssetDefinition update entity.
   * @param sendEvent              sendEvent
   * @return updated {@link DigitalAssetDefinition}
   */
  DigitalAssetDefinition update(SessionContext sessionContext, String realmId, String userId,
      String id, DigitalAssetDefinition digitalAssetDefinition, boolean sendEvent);

  /**
   * Search {@link DigitalAssetDefinition} based on search query.
   *
   * @param realmId     realm of the user.
   * @param userId      id of the user.
   * @param searchQuery search query.
   * @param advanced    advanced search flag.
   * @return fetched {@link DigitalAssetDefinition}(s).
   */
  List<DigitalAssetDefinition> search(String realmId, String userId, SearchQuery searchQuery,
      Boolean advanced);

  /**
   * Delete {@link DigitalAssetDefinition} based on give id.
   *
   * @param sessionContext session context
   * @param realmId        realm of the user
   * @param userId         id of the user
   * @param id             id of the {@link DigitalAssetDefinition}
   * @return deleted {@link DigitalAssetDefinition}
   */
  DigitalAssetDefinition delete(SessionContext sessionContext, String realmId, String userId,
      String id);


  /**
   * Delete {@link DigitalAssetDefinition} based on search query.
   *
   * @param sessionContext session context
   * @param realmId        realm of the user.
   * @param userId         id of the user.
   * @param searchQuery    search query.
   * @param advanced       advanced search flag.
   * @return fetched {@link DigitalAssetDefinition}(s).
   */
  List<DigitalAssetDefinition> deleteBySearch(SessionContext sessionContext, String realmId,
      String userId, SearchQuery searchQuery, Boolean advanced);
}
