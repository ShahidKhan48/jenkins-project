/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.ActionMode;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.CollectionRequestActionStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.CollectionRequestStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.DigitalAssetActionStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.EventOnStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.InitiatorType;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CallbackPayload;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestAction;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.EventData;
import com.ninjacart.dms.dam.domain.assetmanagement.model.OnUpdateContext;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.CallbackClient;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

/**
 * CollectionRequestEventsOnUpdateExecutor - Handles initiating SYSTEM initiated Actions at
 * Collection Request level.
 */
@Slf4j
@RequiredArgsConstructor
public class CollectionRequestEventsOnUpdateExecutor implements OnUpdateExecutor {

  private final CallbackClient callbackClient;

  @Override
  public void execute(SessionContext sessionContext, String realmId, String userId, OnUpdateContext onUpdateContext) {
    if (CollectionUtils.isNotEmpty(onUpdateContext.getDigitalAssetsToSave().values())
        || CollectionUtils.isNotEmpty(onUpdateContext.getCollectionRequestsToSave().values())) {
      return;
    }

    List<CollectionRequest> collectionRequests = onUpdateContext.getCollectionRequests().stream()
        .filter(cr -> !Objects.equals(CollectionRequestStatus.APPROVED, cr.getStatus())).toList();

    // process all non-approved collection requests of user
    for (CollectionRequest collectionRequest : collectionRequests) {
      List<String> digitalAssetIds = collectionRequest.getAssets().stream()
          .map(CollectionRequestAsset::getDigitalAssetId).toList();

      List<DigitalAsset> collectionRequestDigitalAssets = onUpdateContext.getDigitalAssets()
          .stream().filter(digitalAsset -> digitalAssetIds.contains(digitalAsset.getId())).toList();

      List<CollectionRequestAction> collectionRequestSystemInitiatedActions = Optional.ofNullable(
              collectionRequest.getActions()).orElse(Collections.emptyList()).stream()
          .filter(action -> InitiatorType.SYSTEM.equals(action.getInitiatorType())).filter(
              action -> !Objects.equals(action.getStatus(),
                  CollectionRequestActionStatus.SUBMITTED)).toList();

      if (CollectionUtils.isNotEmpty(collectionRequestSystemInitiatedActions)
          && validateForCallback(collectionRequestSystemInitiatedActions.get(0),
          collectionRequestDigitalAssets, collectionRequest.getActions())) {
        CollectionRequestAction action = collectionRequestSystemInitiatedActions.get(0);
        try {
          callbackClient.executeCallback(action.getEvent().getCallbackUrl(),
              CallbackPayload.builder().realmId(realmId).userId(userId)
                  .collectionRequestId(collectionRequest.getId()).build());
        } catch (Exception e) {
          // Swallowing exception - callback failure shouldn't affect program execution
          log.error("Error in events Callback. {}", e.getMessage(), e);
        }
      }
    }
  }

  private boolean validateForCallback(CollectionRequestAction processingCRAction,
      List<DigitalAsset> processingCRDigitalAssets,
      List<CollectionRequestAction> processingCRActions) {
    return Optional.ofNullable(processingCRAction.getEvent()).map(event -> {
      Map<String, EventOnStatus> digitalAssetDefinitionIdToOnStatusMap = Optional.ofNullable(
              processingCRAction.getEvent().getEventData()).orElse(Collections.emptyList()).stream()
          .collect(Collectors.toMap(EventData::getEntityId, EventData::getOnStatus));
      Set<String> digitalAssetDefinitionIds = digitalAssetDefinitionIdToOnStatusMap.keySet();
      return isProcessActionsDone(processingCRAction, processingCRDigitalAssets.stream()
          .filter(da -> digitalAssetDefinitionIds.contains(da.getDigitalAssetDefinitionId()))
          .toList(), processingCRActions) && processingCRDigitalAssets.stream().filter(
              da -> digitalAssetDefinitionIdToOnStatusMap.containsKey(da.getDigitalAssetDefinitionId()))
          .allMatch(
              da -> digitalAssetDefinitionIdToOnStatusMap.get(da.getDigitalAssetDefinitionId())
                  .getApplicableStatuses().contains(da.getStatus()));
    }).orElse(false);
  }

  private boolean isProcessActionsDone(CollectionRequestAction processingCRAction,
      List<DigitalAsset> processingCRDigitalAssets,
      List<CollectionRequestAction> processingCRActions) {
    // if processing CR Action is PROCESS return true, else check if all PROCESS DAs mentioned by
    // DAD Ids in event data and CR actions are done.
    return Objects.equals(processingCRAction.getMode(), ActionMode.PROCESS) || (
        processingCRDigitalAssets.stream().flatMap(
                digitalAsset -> Optional.ofNullable(digitalAsset.getActions())
                    .orElse(Collections.emptyList()).stream())
            .filter(action -> Objects.equals(action.getMode(), ActionMode.PROCESS)).allMatch(
                action -> Objects.equals(action.getStatus(), DigitalAssetActionStatus.SUBMITTED))
            && processingCRActions.stream()
            .filter(action -> Objects.equals(action.getMode(), ActionMode.PROCESS)).allMatch(
                action -> Objects.equals(action.getStatus(),
                    CollectionRequestActionStatus.SUBMITTED)));
  }
}