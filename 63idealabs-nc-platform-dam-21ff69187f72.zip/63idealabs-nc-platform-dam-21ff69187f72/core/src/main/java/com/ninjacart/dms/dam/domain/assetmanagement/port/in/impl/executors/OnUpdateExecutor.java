/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors;

import com.ninjacart.dms.dam.domain.assetmanagement.model.OnUpdateContext;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;

/**
 * OnUpdate Executor.
 */
public interface OnUpdateExecutor {

  /**
   * Method to execute various actions like Callback, initiating system initiated actions on update
   * event.
   *
   * @param sessionContext  session context
   * @param realmId         realm of the user.
   * @param userId          id of the user.
   * @param onUpdateContext context with CRs, DAs for OnUpdate event
   */
  void execute(SessionContext sessionContext, String realmId, String userId,
      OnUpdateContext onUpdateContext);
}
