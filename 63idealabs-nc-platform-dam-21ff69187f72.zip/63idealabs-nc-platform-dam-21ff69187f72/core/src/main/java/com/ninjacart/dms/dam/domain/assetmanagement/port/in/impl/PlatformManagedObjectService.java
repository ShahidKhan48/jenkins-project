package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl;

import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.model.PlatformManagedObject;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.EntityStore;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;

/**
 * Abstract class for handling all core entities.
 *
 * @param <T> type of entity
 */
@RequiredArgsConstructor
public abstract class PlatformManagedObjectService<T extends PlatformManagedObject> {

  private final EntityStore entityStore;

  protected T create(SessionContext sessionContext, String realmId, String userId,
      T platformManagedObject) {
    return (T) entityStore.create(sessionContext, realmId, userId, platformManagedObject, type());
  }

  protected T read(String realmId, String userId, String id) {
    return (T) entityStore.read(realmId, userId, id, type());
  }

  protected T update(SessionContext sessionContext, String realmId, String userId, String id,
      T platformManagedObject, boolean sendEvent) {
    return (T) entityStore.update(sessionContext, realmId, userId, id, platformManagedObject, sendEvent, type());
  }

  protected List<T> search(String realmId, String userId, SearchQuery searchQuery,
      Boolean advanced) {
    return (List<T>) entityStore.search(realmId, userId, searchQuery, advanced, type());
  }

  protected List<T> createAll(SessionContext sessionContext, String realmId, String userId, List<T> platformManagedObjects) {
    return Objects.requireNonNull(platformManagedObjects).stream()
        .map(each -> create(sessionContext, realmId, userId, each)).toList();
  }

  protected List<T> updateAll(SessionContext sessionContext, String realmId, String userId, List<T> platformManagedObjects) {
    return Objects.requireNonNull(platformManagedObjects).stream()
        .map(each -> update(sessionContext, realmId, userId, each.getId(), each, true)).toList();
  }

  protected abstract Class<T> type();

  protected T delete(SessionContext sessionContext, String realmId, String userId, String id) {
    return (T) entityStore.delete(sessionContext, realmId, userId, id, type());
  }

  protected List<T> deleteBySearch(SessionContext sessionContext, String realmId, String userId,
      SearchQuery searchQuery, Boolean advanced) {
    List<T> toBeDeleted = search(realmId, userId, searchQuery, advanced);
    toBeDeleted = toBeDeleted.stream()
        .map(each -> delete(sessionContext, realmId, userId, each.getId())).toList();
    return toBeDeleted;
  }
}
