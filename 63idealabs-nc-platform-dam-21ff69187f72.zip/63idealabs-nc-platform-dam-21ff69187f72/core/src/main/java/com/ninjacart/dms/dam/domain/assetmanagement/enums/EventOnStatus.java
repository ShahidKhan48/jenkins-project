/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.enums;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Event On Status enum.
 */
@Getter
@RequiredArgsConstructor
public enum EventOnStatus {
  APPROVED(Collections.singletonList(AssetStatus.APPROVED)),

  REJECTED(Collections.singletonList(AssetStatus.REJECTED)),

  PENDING(Arrays.asList(AssetStatus.PENDING, AssetStatus.USER_INPUT_REQUIRED, AssetStatus.SUBMITTED,
      AssetStatus.APPROVED)),

  SUBMITTED(Arrays.asList(AssetStatus.SUBMITTED, AssetStatus.APPROVED)),

  USER_INPUT_REQUIRED(Arrays.asList(AssetStatus.PENDING, AssetStatus.USER_INPUT_REQUIRED));

  private final List<AssetStatus> applicableStatuses;
}
