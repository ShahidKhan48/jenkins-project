/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in;

import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestTemplate;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import java.util.List;

/**
 * Collection Request Templates Service.
 */
public interface CollectionRequestTemplatesService {

  /**
   * Create {@link CollectionRequestTemplate} with event sourcing.
   *
   * @param sessionContext            session context
   * @param realmId                   realm of the user.
   * @param userId                    id of the user.
   * @param collectionRequestTemplate entity to be created.
   * @return created {@link CollectionRequestTemplate}.
   */
  CollectionRequestTemplate create(SessionContext sessionContext, String realmId, String userId,
      CollectionRequestTemplate collectionRequestTemplate);

  /**
   * Fetch latest version of {@link CollectionRequestTemplate} based on give id.
   *
   * @param id      id of the {@link CollectionRequestTemplate}
   * @param realmId realm of the user
   * @param userId  id of the user
   * @return fetched {@link CollectionRequestTemplate}
   */
  CollectionRequestTemplate read(String realmId, String userId, String id);

  /**
   * Update {@link CollectionRequestTemplate} with event sourcing.
   *
   * @param sessionContext            session context
   * @param realmId                   realm of the user.
   * @param userId                    id of the user.
   * @param id                        id of the {@link CollectionRequestTemplate}.
   * @param collectionRequestTemplate update entity.
   * @param sendEvent                 sendEvent
   * @return updated {@link CollectionRequestTemplate}
   */
  CollectionRequestTemplate update(SessionContext sessionContext, String realmId, String userId,
      String id, CollectionRequestTemplate collectionRequestTemplate, boolean sendEvent);

  /**
   * Search {@link CollectionRequestTemplate} based on search query.
   *
   * @param realmId     realm of the user.
   * @param userId      id of the user.
   * @param searchQuery search query.
   * @param advanced    advanced search flag.
   * @return fetched {@link CollectionRequestTemplate}(s).
   */
  List<CollectionRequestTemplate> search(String realmId, String userId, SearchQuery searchQuery,
      Boolean advanced);

  /**
   * Delete {@link CollectionRequestTemplate} based on give id.
   *
   * @param sessionContext session context
   * @param realmId        realm of the user
   * @param userId         id of the user
   * @param id             id of the {@link CollectionRequestTemplate}
   * @return deleted {@link CollectionRequestTemplate}
   */
  CollectionRequestTemplate delete(SessionContext sessionContext, String realmId, String userId, String id);

  /**
   * Delete {@link CollectionRequestTemplate} based on search query.
   *
   * @param sessionContext session context
   * @param realmId        realm of the user.
   * @param userId         id of the user.
   * @param searchQuery    search query.
   * @param advanced       advanced search flag.
   * @return deleted {@link CollectionRequestTemplate}(s).
   */
  List<CollectionRequestTemplate> deleteBySearch(SessionContext sessionContext, String realmId, String userId,
      SearchQuery searchQuery, Boolean advanced);
}
