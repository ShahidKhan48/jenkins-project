/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl;

import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.CollectionRequestsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.helper.CollectionRequestCreationHelper;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.EntityStore;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

/**
 * Collection Request Service implementation.
 */
@Slf4j
public class CollectionRequestsServiceImpl extends
    PlatformManagedObjectService<CollectionRequest> implements CollectionRequestsService {

  private final CollectionRequestCreationHelper collectionRequestCreationHelper;

  public CollectionRequestsServiceImpl(EntityStore entityStore,
      CollectionRequestCreationHelper collectionRequestCreationHelper) {
    super(entityStore);
    this.collectionRequestCreationHelper = collectionRequestCreationHelper;
  }

  @Override
  public CollectionRequest create(SessionContext sessionContext, String realmId, String userId,
      CollectionRequest collectionRequest) {
    collectionRequest.setRealmId(realmId);
    collectionRequest.setUserId(userId);
    CollectionRequest createdCollectionRequest = super.create(sessionContext, realmId, userId, collectionRequest);
    createdCollectionRequest = super.update(sessionContext, realmId, userId, createdCollectionRequest.getId(),
        collectionRequestCreationHelper.process(sessionContext, realmId, userId, createdCollectionRequest), true);
    return createdCollectionRequest;
  }

  @Override
  public CollectionRequest read(String realmId, String userId, String id) {
    return super.read(realmId, userId, id);
  }

  @Override
  public CollectionRequest update(SessionContext sessionContext, String realmId, String userId, String id,
      CollectionRequest collectionRequest, boolean sendEvent) {
    return super.update(sessionContext, realmId, userId, id, collectionRequest, sendEvent);
  }

  @Override
  public List<CollectionRequest> search(String realmId, String userId, SearchQuery searchQuery,
      Boolean advanced) {
    return super.search(realmId, userId, searchQuery, advanced);
  }

  @Override
  protected List<CollectionRequest> createAll(SessionContext sessionContext, String realmId, String userId,
      List<CollectionRequest> platformManagedObjects) {
    return super.createAll(sessionContext, realmId, userId, platformManagedObjects);
  }

  @Override
  public List<CollectionRequest> updateAll(SessionContext sessionContext, String realmId, String userId,
      List<CollectionRequest> collectionRequests) {
    return super.updateAll(sessionContext, realmId, userId, collectionRequests);
  }

  @Override
  public CollectionRequest delete(SessionContext sessionContext, String realmId, String userId, String id) {
    return super.delete(sessionContext, realmId, userId, id);
  }

  @Override
  public List<CollectionRequest> deleteBySearch(SessionContext sessionContext, String realmId, String userId,
      SearchQuery searchQuery, Boolean advanced) {
    return super.deleteBySearch(sessionContext, realmId, userId, searchQuery, advanced);
  }

  @Override
  protected Class<CollectionRequest> type() {
    return CollectionRequest.class;
  }
}
