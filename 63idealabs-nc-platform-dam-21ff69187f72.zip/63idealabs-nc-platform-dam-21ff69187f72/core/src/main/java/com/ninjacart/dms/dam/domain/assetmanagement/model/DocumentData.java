/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.model;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DocumentData.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocumentData implements Serializable {

  private String name;
  private String dob;
  private String identifier;
  private String fatherName;
  private String spouseName;
  private String gender;
}
