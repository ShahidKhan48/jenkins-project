package com.ninjacart.dms.dam.domain.consentmanagement.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ninjacart.dms.dam.domain.assetmanagement.model.MediaDetail;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Artifact Details.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ArtifactDetails {

  private String signature;
  private List<MediaDetail> mediaDetails;
  private String requestedTimestamp;
  private String approvedTimestamp;
}
