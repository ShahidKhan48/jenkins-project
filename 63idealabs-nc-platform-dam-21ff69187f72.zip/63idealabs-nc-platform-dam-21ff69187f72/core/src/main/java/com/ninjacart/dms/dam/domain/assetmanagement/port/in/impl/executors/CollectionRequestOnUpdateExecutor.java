/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors;

import com.ninjacart.dms.dam.domain.assetmanagement.enums.AssetStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.CollectionRequestStatus;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.OnUpdateContext;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.helper.DigitalAssetHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.SerializationUtils;

/**
 * CollectionRequestOnUpdateExecutor - Handles status updates at Collection Request level.
 */
@Slf4j
@RequiredArgsConstructor
public class CollectionRequestOnUpdateExecutor implements OnUpdateExecutor {

  private static Optional<CollectionRequest> updateCollectionRequestWithDigitalAsset(
      CollectionRequest collectionRequest,
      Map<String, DigitalAsset> digitalAssetByDigitalAssetDefinitionId) {
    CollectionRequest collectionRequestClone = SerializationUtils.clone(collectionRequest);
    boolean updatedRequired = false;
    if (!CollectionRequestStatus.collectionRequestTerminalStatuses()
        .contains(collectionRequest.getStatus())) {
      List<String> digitalAssetsInCollectionRequest = collectionRequest.getAssets().parallelStream()
          .map(CollectionRequestAsset::getDigitalAssetId).toList();
      for (CollectionRequestAsset asset : collectionRequest.getAssets()) {
        log.debug("Checking CR Status update with DA: {}", asset.getId());
        if (digitalAssetByDigitalAssetDefinitionId.containsKey(asset.getId())) {
          DigitalAsset digitalAssetPresent = digitalAssetByDigitalAssetDefinitionId.get(
              asset.getId());
          if (digitalAssetsInCollectionRequest.contains(digitalAssetPresent.getId())
              && !AssetStatus.digitalAssetTerminalStatuses().contains(asset.getStatus())) {
            log.debug("CR asset status: {} updating with DA status: {}", asset.getStatus(),
                digitalAssetPresent.getStatus());
            asset.setStatus(digitalAssetPresent.getStatus());
            updatedRequired = true;
          }
        }
      }
    }
    boolean crUpdateNeeded = !collectionRequest.equals(collectionRequestClone);
    log.debug("Update Required for CR: {} - CR changed: {}", updatedRequired, crUpdateNeeded);
    return updatedRequired && crUpdateNeeded ? Optional.of(collectionRequest) : Optional.empty();
  }

  private static Optional<CollectionRequest> prepareCollectionRequestStatusUpdate(
      CollectionRequest collectionRequest,
      Map<String, DigitalAsset> digitalAssetByDigitalAssetDefinitionId) {

    Optional<CollectionRequestStatus> statusToBeUpdated = DigitalAssetHelper.getCollectionRequestStatus(
        new ArrayList<>(digitalAssetByDigitalAssetDefinitionId.values()), collectionRequest);
    return statusToBeUpdated.filter(
        status -> !Objects.equals(collectionRequest.getStatus(), status)).map(status -> {
      log.debug("Updating CR: {} status to {}", collectionRequest.getId(), status);
      collectionRequest.setStatus(status);
      return collectionRequest;
    });
  }

  @Override
  public void execute(SessionContext sessionContext, String realmId, String userId, OnUpdateContext onUpdateContext) {
    List<CollectionRequest> collectionRequests = onUpdateContext.getCollectionRequests();
    List<DigitalAsset> digitalAssets = onUpdateContext.getDigitalAssets();

    if (CollectionUtils.isNotEmpty(digitalAssets)) {
      // TODO: revisit merge function - May need to do the grouping on collection request & dadId


      Map<String, CollectionRequest> collectionRequestsToBeSaved = new HashMap<>();
      for (CollectionRequest collectionRequest : collectionRequests) {
        Set<String> crDigitalAssetIds = collectionRequest.getAssets()
            .stream().map(CollectionRequestAsset::getDigitalAssetId)
            .collect(Collectors.toSet());

        Map<String, DigitalAsset> digitalAssetByDigitalAssetDefinitionId = digitalAssets.stream()
            .filter(each -> crDigitalAssetIds.contains(each.getId()))
            .collect(Collectors.toMap(DigitalAsset::getDigitalAssetDefinitionId, Function.identity(),
                (o1, o2) -> o2));
        log.debug("Processing CR: {}", collectionRequest.getId());

        updateCollectionRequestWithDigitalAsset(collectionRequest,
            digitalAssetByDigitalAssetDefinitionId).ifPresent(
            cr -> collectionRequestsToBeSaved.put(cr.getId(), cr));

        prepareCollectionRequestStatusUpdate(collectionRequest,
            digitalAssetByDigitalAssetDefinitionId).ifPresent(
            cr -> collectionRequestsToBeSaved.put(cr.getId(), cr));
      }
      onUpdateContext.setCollectionRequestsToSave(collectionRequestsToBeSaved);
    }
  }
}
