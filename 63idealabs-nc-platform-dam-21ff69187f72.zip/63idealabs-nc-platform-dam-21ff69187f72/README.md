# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* Summary of set up
  - Install JDK 17
  - Install groovy

* Configuration
  - make sure java version set to 17 before running the project
  - make sure gradle jvm also update to JDK 17 in project setting
  
* Dependencies
* Database configuration

* How to run 
  - ./gradlew
  - you can use gradle plugin also
  
* How to run tests
* Deployment instructions

### Swagger

* http://localhost:8989/dam/swagger-ui/index.html
* http://localhost:8989/dam/v3/api-docs
* Documentation can be available in yaml format as well, on the following path : /v3/api-docs.yaml
* Actuator - http://localhost:8989/dam/actuator/health

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact