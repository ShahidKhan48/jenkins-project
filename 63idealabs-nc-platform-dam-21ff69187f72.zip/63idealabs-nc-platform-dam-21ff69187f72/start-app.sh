#!/usr/bin/env sh

if [ -z "${SPRING_PROFILE}" ]
then
  SPRING_PROFILE=qa
fi

java -javaagent:opentelemetry-javaagent.jar \
  -Dotel.resource.attributes=service.name=nc-platform-dam \
  -jar -Duser.timezone=UTC -Dspring.profiles.active=${SPRING_PROFILE} app.jar
