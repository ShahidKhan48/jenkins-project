package com.ninjacart.dms.dam.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import java.util.Collections;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
  @Value("${application.open-api-title}")
  private String openApiTitle;

  @Value("${application.open-api-deployed-url}")
  private String openApiDeployedUrl;

  @Value("${application.open-api-description}")
  private String openApiDescription;

  @Value("${application.open-api-version}")
  private String openApiVersion;

  @Bean
  public OpenAPI openAPI() {
    return new OpenAPI().info(
            new Info().title(openApiTitle).description(openApiDescription).version(openApiVersion))
        .servers(Collections.singletonList(new Server().url(openApiDeployedUrl)));
  }
}
