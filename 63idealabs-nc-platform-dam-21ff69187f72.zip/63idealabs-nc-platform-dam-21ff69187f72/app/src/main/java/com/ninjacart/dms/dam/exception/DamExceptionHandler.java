/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.exception;

import com.ninjacart.platform.commons.error.exceptions.NinjaException;
import com.ninjacart.platform.commons.error.exceptions.NinjaExceptionHandler;
import com.ninjacart.platform.commons.error.exceptions.NinjaRuntimeException;
import java.util.Locale;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Error handling.
 */
@RestControllerAdvice
@RequiredArgsConstructor
@Slf4j
public class DamExceptionHandler extends ResponseEntityExceptionHandler {

  private final NinjaExceptionHandler ninjaExceptionHandler;
  private final ProblemDetailMapper problemDetailMapper;

  /**
   * Provides Problem Detail based response on a Ninja Exception.
   *
   * @param e      error
   * @param locale locale
   * @return ProblemDetails
   */
  @ExceptionHandler(NinjaRuntimeException.class)
  public ErrorResponse ninjaExceptionHandler(NinjaRuntimeException e, Locale locale) {
    log.error(e.getMessage(), e);
    return ninjaExceptionHandler.handleNinjaRuntimeException(e, problemDetailMapper, locale);
  }

  @ExceptionHandler(NinjaException.class)
  public ErrorResponse ninjaExceptionHandler(NinjaException e, Locale locale) {
    log.error(e.getMessage(), e);
    return ninjaExceptionHandler.handleNinjaException(e, problemDetailMapper, locale);
  }

  @ExceptionHandler(Exception.class)
  public ErrorResponse handleException(Exception e, Locale locale) {
    log.error(e.getMessage(), e);
    return ninjaExceptionHandler.handleNinjaRuntimeException(
        new NinjaRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_020, e.getMessage(), e),
        problemDetailMapper, locale);
  }
}