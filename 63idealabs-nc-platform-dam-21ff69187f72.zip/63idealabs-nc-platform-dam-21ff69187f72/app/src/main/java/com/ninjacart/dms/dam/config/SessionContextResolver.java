package com.ninjacart.dms.dam.config;

import com.ninjacart.dms.dam.model.SessionContext;
import java.util.Optional;
import lombok.NonNull;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

/**
 * Session Context Resolver.
 */
public class SessionContextResolver implements HandlerMethodArgumentResolver {

  private static final String USER_ID_HEADER = "x-nc-user-id";
  private static final String TOOL_ID_HEADER = "x-nc-tool-id";

  @Override
  public boolean supportsParameter(MethodParameter parameter) {
    return parameter.getParameterType().equals(SessionContext.class);
  }

  @Override
  public Object resolveArgument(@NonNull MethodParameter parameter, ModelAndViewContainer mavContainer,
      NativeWebRequest webRequest, WebDataBinderFactory binderFactory) {

    var requestActionUserId = webRequest.getHeader(USER_ID_HEADER);
    var sessionContext = new SessionContext();
    Optional.ofNullable(requestActionUserId).ifPresent(sessionContext::setActionUserId);

    var requestToolId = webRequest.getHeader(TOOL_ID_HEADER);
    Optional.ofNullable(requestToolId).ifPresent(sessionContext::setToolId);

    return sessionContext;
  }
}
