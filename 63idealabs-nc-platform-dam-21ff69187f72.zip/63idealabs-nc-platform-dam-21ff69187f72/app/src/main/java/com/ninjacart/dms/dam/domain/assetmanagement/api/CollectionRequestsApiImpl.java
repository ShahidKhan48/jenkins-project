/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.api;

import com.ninjacart.dms.dam.api.CollectionRequestsApi;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.CollectionRequestMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.SearchRequestMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.SessionContextMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.ActionsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.CollectionRequestsService;
import com.ninjacart.dms.dam.model.CollectionRequest;
import com.ninjacart.dms.dam.model.CollectionRequestCommandRequest;
import com.ninjacart.dms.dam.model.CollectionRequestListResponse;
import com.ninjacart.dms.dam.model.CollectionRequestResponse;
import com.ninjacart.dms.dam.model.SearchRequest;
import com.ninjacart.dms.dam.model.SessionContext;
import com.ninjacart.dms.dam.utils.ResponseUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 * Collection Request APIs.
 */
@RestController
@RequiredArgsConstructor
@Slf4j
// TODO: Add scopes
public class CollectionRequestsApiImpl implements CollectionRequestsApi {

  private final CollectionRequestsService collectionRequestsService;
  private final ActionsService actionsService;

  @Override
  public ResponseEntity<CollectionRequestResponse> createCollectionRequest(String realmId,
      String userId, CollectionRequest collectionRequest, SessionContext sessionContext) {
    return ResponseEntity.ok(
        CollectionRequestMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata()).data(
            CollectionRequestMapper.INSTANCE.fromDomain(collectionRequestsService.create(
                SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId,
                CollectionRequestMapper.INSTANCE.toDomain(collectionRequest)))));
  }

  @Override
  public ResponseEntity<CollectionRequestResponse> deleteCollectionRequest(String id,
      String realmId, String userId, SessionContext sessionContext) {
    return ResponseEntity.ok(
        CollectionRequestMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata()).data(
            CollectionRequestMapper.INSTANCE.fromDomain(collectionRequestsService.delete(
                SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId, id))));
  }

  @Override
  public ResponseEntity<CollectionRequestListResponse> deleteCollectionRequestsBySearch(
      String realmId, String userId, SearchRequest searchRequest, SessionContext sessionContext,
      Boolean advanced) {
    return ResponseEntity.ok(
        CollectionRequestMapper.INSTANCE.listFromMetadata(ResponseUtils.successMetadata()).data(
            CollectionRequestMapper.INSTANCE.fromDomain(collectionRequestsService.deleteBySearch(
                SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId,
                SearchRequestMapper.INSTANCE.toDomain(searchRequest), advanced))));
  }

  @Override
  public ResponseEntity<CollectionRequestResponse> processCollectionRequest(String realmId,
      String userId, String operation,
      CollectionRequestCommandRequest collectionRequestCommandRequest,
      SessionContext sessionContext) {
    CollectionRequestResponse digitalAssetResponse = CollectionRequestMapper.INSTANCE.toResponse(
        actionsService.processCollectionRequest(
            SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId, operation,
            CollectionRequestMapper.INSTANCE.toCommand(collectionRequestCommandRequest)));
    return new ResponseEntity<>(digitalAssetResponse, HttpStatus.OK);
  }

  @Override
  public ResponseEntity<CollectionRequestResponse> readCollectionRequest(String id, String realmId,
      String userId) {
    return ResponseEntity.ok(
        CollectionRequestMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata()).data(
            CollectionRequestMapper.INSTANCE.fromDomain(
                collectionRequestsService.read(realmId, userId, id))));
  }

  @Override
  public ResponseEntity<CollectionRequestListResponse> searchCollectionRequests(String realmId,
      String userId, SearchRequest searchQuery, Boolean advanced) {
    return ResponseEntity.ok(
        CollectionRequestMapper.INSTANCE.listFromMetadata(ResponseUtils.successMetadata()).data(
            CollectionRequestMapper.INSTANCE.fromDomain(
                collectionRequestsService.search(realmId, userId,
                    SearchRequestMapper.INSTANCE.toDomain(searchQuery), advanced))));
  }

  @Override
  public ResponseEntity<CollectionRequestResponse> updateCollectionRequest(String id,
      String realmId, String userId, CollectionRequest collectionRequest,
      SessionContext sessionContext) {
    return ResponseEntity.ok(
        CollectionRequestMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata()).data(
            CollectionRequestMapper.INSTANCE.fromDomain(collectionRequestsService.update(
                SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId, id,
                CollectionRequestMapper.INSTANCE.toDomain(collectionRequest), true))));
  }
}
