/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.mapper;

import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestTemplate;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDefinition;
import com.ninjacart.dms.dam.model.CollectionRequestTemplateListResponse;
import com.ninjacart.dms.dam.model.CollectionRequestTemplateRequest;
import com.ninjacart.dms.dam.model.CollectionRequestTemplateResponse;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionListResponse;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionRequest;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionResponse;
import com.ninjacart.dms.dam.model.Metadata;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * Mapper For Collection Request Templates for API Specification and Domain.
 */
@Mapper
public interface CollectionRequestTemplateMapper {

  CollectionRequestTemplateMapper INSTANCE = Mappers.getMapper(
      CollectionRequestTemplateMapper.class);

  /**
   * Get Response from Metadata.
   *
   * @param metadata metadata
   * @return response
   */
  CollectionRequestTemplateResponse fromMetadata(Metadata metadata);

  /**
   * Get Response from Metadata.
   *
   * @param metadata metadata
   * @return response
   */
  CollectionRequestTemplateListResponse listFromMetadata(Metadata metadata);

  /**
   * Converts API Specification Object to Domain Object.
   *
   * @param collectionRequestTemplate API Specification Object.
   * @return API Specification Object.
   */
  CollectionRequestTemplate toDomain(CollectionRequestTemplateRequest collectionRequestTemplate);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param collectionRequestTemplate domain object.
   * @return API Specification Object.
   */
  CollectionRequestTemplateRequest fromDomain(CollectionRequestTemplate collectionRequestTemplate);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param collectionRequestTemplates domain object.
   * @return API Specification Object.
   */
  List<CollectionRequestTemplateRequest> fromDomain(
      List<CollectionRequestTemplate> collectionRequestTemplates);
}
