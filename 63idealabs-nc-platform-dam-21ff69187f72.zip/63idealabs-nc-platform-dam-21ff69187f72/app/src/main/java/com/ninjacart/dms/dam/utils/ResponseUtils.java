package com.ninjacart.dms.dam.utils;

import com.ninjacart.dms.dam.model.Metadata;
import java.time.LocalDateTime;
import lombok.experimental.UtilityClass;
import org.springframework.http.HttpStatus;

/**
 * Response Utility.
 */
@UtilityClass
public class ResponseUtils {

  /**
   * Provides Success Metadata.
   *
   * @return success metadata
   */
  public static Metadata successMetadata() {
    return new Metadata().status(HttpStatus.OK.value()).timestamp(LocalDateTime.now().toString());
  }
}
