/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.api;

import com.ninjacart.dms.dam.api.CollectionRequestTemplatesApi;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.CollectionRequestTemplateMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.SearchRequestMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.SessionContextMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestTemplate;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.CollectionRequestTemplatesService;
import com.ninjacart.dms.dam.model.CollectionRequestTemplateListResponse;
import com.ninjacart.dms.dam.model.CollectionRequestTemplateRequest;
import com.ninjacart.dms.dam.model.CollectionRequestTemplateResponse;
import com.ninjacart.dms.dam.model.SearchRequest;
import com.ninjacart.dms.dam.model.SessionContext;
import com.ninjacart.dms.dam.utils.ResponseUtils;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 * Collection Request Template APIs.
 */
@RestController
@RequiredArgsConstructor
public class CollectionRequestTemplatesApiImpl implements CollectionRequestTemplatesApi {

  private final CollectionRequestTemplatesService collectionRequestTemplatesService;

  @Override
  public ResponseEntity<CollectionRequestTemplateResponse> createCollectionRequestTemplate(
      String realmId, String userId, CollectionRequestTemplateRequest collectionRequestTemplate,
      SessionContext sessionContext) {
    CollectionRequestTemplate createdCollectionRequestTemplate = collectionRequestTemplatesService.create(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId,
        CollectionRequestTemplateMapper.INSTANCE.toDomain(collectionRequestTemplate));
    return ResponseEntity.ok(
        CollectionRequestTemplateMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata()).data(
            CollectionRequestTemplateMapper.INSTANCE.fromDomain(createdCollectionRequestTemplate)));
  }

  @Override
  public ResponseEntity<CollectionRequestTemplateResponse> deleteCollectionRequestTemplate(
      String id, String realmId, String userId, SessionContext sessionContext) {
    CollectionRequestTemplate collectionRequestTemplate = collectionRequestTemplatesService.delete(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId, id);
    return ResponseEntity.ok(
        CollectionRequestTemplateMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
            .data(CollectionRequestTemplateMapper.INSTANCE.fromDomain(collectionRequestTemplate)));
  }

  @Override
  public ResponseEntity<CollectionRequestTemplateListResponse> deleteCollectionRequestTemplatesBySearch(
      String realmId, String userId, SearchRequest searchRequest, SessionContext sessionContext,
      Boolean advanced) {
    List<CollectionRequestTemplate> collectionRequestTemplates = collectionRequestTemplatesService.deleteBySearch(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId,
        SearchRequestMapper.INSTANCE.toDomain(searchRequest), advanced);

    return ResponseEntity.ok(
        CollectionRequestTemplateMapper.INSTANCE.listFromMetadata(ResponseUtils.successMetadata())
            .data(CollectionRequestTemplateMapper.INSTANCE.fromDomain(collectionRequestTemplates)));
  }

  @Override
  public ResponseEntity<CollectionRequestTemplateResponse> readCollectionRequestTemplate(String id,
      String realmId, String userId) {
    CollectionRequestTemplate collectionRequestTemplate = collectionRequestTemplatesService.read(
        realmId, userId, id);
    return ResponseEntity.ok(
        CollectionRequestTemplateMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
            .data(CollectionRequestTemplateMapper.INSTANCE.fromDomain(collectionRequestTemplate)));
  }

  @Override
  public ResponseEntity<CollectionRequestTemplateListResponse> searchCollectionRequestTemplates(
      String realmId, String userId, SearchRequest searchQuery, Boolean advanced) {
    List<CollectionRequestTemplate> collectionRequestTemplates = collectionRequestTemplatesService.search(
        realmId, userId, SearchRequestMapper.INSTANCE.toDomain(searchQuery), advanced);

    return ResponseEntity.ok(
        CollectionRequestTemplateMapper.INSTANCE.listFromMetadata(ResponseUtils.successMetadata())
            .data(CollectionRequestTemplateMapper.INSTANCE.fromDomain(collectionRequestTemplates)));
  }

  @Override
  public ResponseEntity<CollectionRequestTemplateResponse> updateCollectionRequestTemplate(
      String id, String realmId, String userId,
      CollectionRequestTemplateRequest collectionRequestTemplate, SessionContext sessionContext) {
    CollectionRequestTemplate updatedCollectionRequestTemplate = collectionRequestTemplatesService.update(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId, id,
        CollectionRequestTemplateMapper.INSTANCE.toDomain(collectionRequestTemplate), true);
    return ResponseEntity.ok(
        CollectionRequestTemplateMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata()).data(
            CollectionRequestTemplateMapper.INSTANCE.fromDomain(updatedCollectionRequestTemplate)));
  }
}
