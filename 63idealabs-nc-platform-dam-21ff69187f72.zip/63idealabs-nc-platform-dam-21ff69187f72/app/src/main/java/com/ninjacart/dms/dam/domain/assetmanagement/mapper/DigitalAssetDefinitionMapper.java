/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.mapper;

import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDefinition;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionListResponse;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionRequest;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionResponse;
import com.ninjacart.dms.dam.model.DigitalAssetRequest;
import com.ninjacart.dms.dam.model.Metadata;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;
import org.mapstruct.ValueMapping;
import org.mapstruct.factory.Mappers;

/**
 * Mapper For Digital Asset Definitions for API Specification and Domain.
 */
@Mapper
public interface DigitalAssetDefinitionMapper {

  DigitalAssetDefinitionMapper INSTANCE = Mappers.getMapper(DigitalAssetDefinitionMapper.class);

  /**
   * Get Response from Metadata.
   *
   * @param metadata metadata
   * @return response
   */
  DigitalAssetDefinitionResponse fromMetadata(Metadata metadata);

  /**
   * Get Response from Metadata.
   *
   * @param metadata metadata
   * @return response
   */
  DigitalAssetDefinitionListResponse listFromMetadata(Metadata metadata);

  /**
   * Converts API Specification Object to Domain Object.
   *
   * @param digitalAssetDefinition API Specification Object.
   * @return API Specification Object.
   */
  DigitalAssetDefinition toDomain(DigitalAssetDefinitionRequest digitalAssetDefinition);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param digitalAssetDefinition domain object.
   * @return API Specification Object.
   */
  @ValueMapping(source = MappingConstants.ANY_REMAINING, target = MappingConstants.NULL)
  DigitalAssetDefinitionRequest fromDomain(DigitalAssetDefinition digitalAssetDefinition);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param digitalAssetDefinitions domain object.
   * @return API Specification Object.
   */
  List<DigitalAssetDefinitionRequest> fromDomain(List<DigitalAssetDefinition> digitalAssetDefinitions);
}
