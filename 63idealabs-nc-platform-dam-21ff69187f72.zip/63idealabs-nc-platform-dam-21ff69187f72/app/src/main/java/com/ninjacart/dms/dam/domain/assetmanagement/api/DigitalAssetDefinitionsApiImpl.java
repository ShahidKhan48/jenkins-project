/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.api;

import com.ninjacart.dms.dam.api.DigitalAssetDefinitionsApi;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.DigitalAssetDefinitionMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.SearchRequestMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.SessionContextMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDefinition;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.DigitalAssetDefinitionsService;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionListResponse;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionRequest;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionResponse;
import com.ninjacart.dms.dam.model.SearchRequest;
import com.ninjacart.dms.dam.model.SessionContext;
import com.ninjacart.dms.dam.utils.ResponseUtils;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 * Digital Asset Definitions APIs.
 */
@RestController
@RequiredArgsConstructor
public class DigitalAssetDefinitionsApiImpl implements DigitalAssetDefinitionsApi {

  private final DigitalAssetDefinitionsService digitalAssetDefinitionsService;

  @Override
  public ResponseEntity<DigitalAssetDefinitionResponse> createDigitalAssetDefinition(String realmId,
      String userId, DigitalAssetDefinitionRequest digitalAssetDefinition,
      SessionContext sessionContext) {
    DigitalAssetDefinition createdDigitalAssetDefinition = digitalAssetDefinitionsService.create(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId,
        DigitalAssetDefinitionMapper.INSTANCE.toDomain(digitalAssetDefinition));
    return ResponseEntity.ok(
        DigitalAssetDefinitionMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
            .data(DigitalAssetDefinitionMapper.INSTANCE.fromDomain(createdDigitalAssetDefinition)));
  }

  @Override
  public ResponseEntity<DigitalAssetDefinitionResponse> deleteDigitalAssetDefinition(String id,
      String realmId, String userId, SessionContext sessionContext) {
    DigitalAssetDefinition digitalAssetDefinition = digitalAssetDefinitionsService.delete(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId, id);
    return ResponseEntity.ok(
        DigitalAssetDefinitionMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
            .data(DigitalAssetDefinitionMapper.INSTANCE.fromDomain(digitalAssetDefinition)));
  }

  @Override
  public ResponseEntity<DigitalAssetDefinitionListResponse> deleteDigitalAssetDefinitionsBySearch(
      String realmId, String userId, SearchRequest searchRequest, SessionContext sessionContext,
      Boolean advanced) {
    List<DigitalAssetDefinition> digitalAssetDefinitions = digitalAssetDefinitionsService.deleteBySearch(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId,
        SearchRequestMapper.INSTANCE.toDomain(searchRequest), advanced);

    return ResponseEntity.ok(
        DigitalAssetDefinitionMapper.INSTANCE.listFromMetadata(ResponseUtils.successMetadata())
            .data(DigitalAssetDefinitionMapper.INSTANCE.fromDomain(digitalAssetDefinitions)));
  }

  @Override
  public ResponseEntity<DigitalAssetDefinitionResponse> readDigitalAssetDefinition(String id,
      String realmId, String userId) {
    DigitalAssetDefinition digitalAssetDefinition = digitalAssetDefinitionsService.read(realmId,
        userId, id);
    return ResponseEntity.ok(
        DigitalAssetDefinitionMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
            .data(DigitalAssetDefinitionMapper.INSTANCE.fromDomain(digitalAssetDefinition)));
  }

  @Override
  public ResponseEntity<DigitalAssetDefinitionListResponse> searchDigitalAssetDefinitions(
      String realmId, String userId, SearchRequest searchQuery, Boolean advanced) {
    List<DigitalAssetDefinition> digitalAssetDefinitions = digitalAssetDefinitionsService.search(
        realmId, userId, SearchRequestMapper.INSTANCE.toDomain(searchQuery), advanced);

    return ResponseEntity.ok(
        DigitalAssetDefinitionMapper.INSTANCE.listFromMetadata(ResponseUtils.successMetadata())
            .data(DigitalAssetDefinitionMapper.INSTANCE.fromDomain(digitalAssetDefinitions)));
  }

  @Override
  public ResponseEntity<DigitalAssetDefinitionResponse> updateDigitalAssetDefinition(String id,
      String realmId, String userId, DigitalAssetDefinitionRequest digitalAssetDefinition,
      SessionContext sessionContext) {
    DigitalAssetDefinition updatedDigitalAssetDefinition = digitalAssetDefinitionsService.update(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId, id,
        DigitalAssetDefinitionMapper.INSTANCE.toDomain(digitalAssetDefinition), true);
    return ResponseEntity.ok(
        DigitalAssetDefinitionMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
            .data(DigitalAssetDefinitionMapper.INSTANCE.fromDomain(updatedDigitalAssetDefinition)));
  }
}
