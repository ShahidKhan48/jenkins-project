/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.filemanagement.mapper;

import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDefinition;
import com.ninjacart.dms.dam.domain.assetmanagement.model.MediaDetail;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionListResponse;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionRequest;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionResponse;
import com.ninjacart.dms.dam.model.MediaDetailListResponse;
import com.ninjacart.dms.dam.model.MediaDetailRequest;
import com.ninjacart.dms.dam.model.MediaDetailResponse;
import com.ninjacart.dms.dam.model.Metadata;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * Mapper For Media Details for API Specification and Domain.
 */
@Mapper
public interface MediaDetailMapper {

  MediaDetailMapper INSTANCE = Mappers.getMapper(MediaDetailMapper.class);

  /**
   * Get Response from Metadata.
   *
   * @param metadata metadata
   * @return response
   */
  MediaDetailResponse fromMetadata(Metadata metadata);

  /**
   * Get Response from Metadata.
   *
   * @param metadata metadata
   * @return response
   */
  MediaDetailListResponse listFromMetadata(Metadata metadata);

  /**
   * Converts API Specification Object to Domain Object.
   *
   * @param mediaDetail API Specification Object.
   * @return Domain Object.
   */
  MediaDetail toDomain(MediaDetailRequest mediaDetail);

  /**
   * Converts API Specification Object to Domain Object.
   *
   * @param mediaDetails domain object.
   * @return Domain Object.
   */
  List<MediaDetail> toDomain(List<MediaDetailRequest> mediaDetails);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param mediaDetail domain object.
   * @return API Specification Object.
   */
  MediaDetailRequest fromDomain(MediaDetail mediaDetail);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param mediaDetails domain object.
   * @return API Specification Object.
   */
  List<MediaDetailRequest> fromDomain(List<MediaDetail> mediaDetails);
}
