package com.ninjacart.dms.dam.domain.assetmanagement.mapper;

import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.model.SearchRequest;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * Mapper For Search Request for API Specification and Domain.
 */
@Mapper
public interface SearchRequestMapper {

  SearchRequestMapper INSTANCE = Mappers.getMapper(SearchRequestMapper.class);

  /**
   * Converts API Specification Object to Domain Object.
   *
   * @param searchRequest API specification object
   * @return domain Object
   */
  SearchQuery toDomain(SearchRequest searchRequest);
}
