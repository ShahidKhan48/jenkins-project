package com.ninjacart.dms.dam.domain.consentmanagement.mapper;

import com.ninjacart.dms.dam.domain.assetmanagement.mapper.DigitalAssetMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDefinition;
import com.ninjacart.dms.dam.domain.consentmanagement.model.Consent;
import com.ninjacart.dms.dam.model.ConsentListResponse;
import com.ninjacart.dms.dam.model.ConsentRequest;
import com.ninjacart.dms.dam.model.ConsentResponse;
import com.ninjacart.dms.dam.model.DigitalAssetDefinitionRequest;
import com.ninjacart.dms.dam.model.Metadata;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.ValueMapping;
import org.mapstruct.factory.Mappers;

/**
 * Consent Mapper.
 */
@Mapper
public interface ConsentMapper {

  ConsentMapper INSTANCE = Mappers.getMapper(ConsentMapper.class);

  /**
   * Get Response from Metadata.
   *
   * @param metadata metadata
   * @return response
   */
  ConsentResponse fromMetadata(Metadata metadata);

  /**
   * Get Response from Metadata.
   *
   * @param metadata metadata
   * @return response
   */
  ConsentListResponse listFromMetadata(Metadata metadata);

  /**
   * Converts API Specification Object to Domain Object.
   *
   * @param consent API Specification Object.
   * @return API Specification Object.
   */
  Consent toDomain(ConsentRequest consent);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param consent domain object.
   * @return API Specification Object.
   */
  @ValueMapping(source = MappingConstants.ANY_REMAINING, target = MappingConstants.NULL)
  ConsentRequest fromDomain(Consent consent);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param consents domain object.
   * @return API Specification Object.
   */
  List<ConsentRequest> fromDomain(List<Consent> consents);
}
