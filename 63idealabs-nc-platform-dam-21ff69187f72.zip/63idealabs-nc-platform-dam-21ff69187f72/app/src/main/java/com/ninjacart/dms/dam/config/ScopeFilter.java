/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

@Slf4j
@Configuration
public class ScopeFilter extends OncePerRequestFilter {

  private static final String CLIENT_SCOPES_HEADER = "x-ninjacart-client-scopes";

  @Override
  protected void doFilterInternal(HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse, FilterChain filterChain)
      throws ServletException, IOException {

    Collection<GrantedAuthority> authorities = new HashSet<>();
    Enumeration<String> headers = httpServletRequest.getHeaders(CLIENT_SCOPES_HEADER);

    while (headers.hasMoreElements()) {
      String scope = headers.nextElement();
      authorities.add(new SimpleGrantedAuthority(scope));
    }

    SecurityContextHolder.getContext()
        .setAuthentication(new UsernamePasswordAuthenticationToken(null, null, authorities));
    filterChain.doFilter(httpServletRequest, httpServletResponse);
  }
}
