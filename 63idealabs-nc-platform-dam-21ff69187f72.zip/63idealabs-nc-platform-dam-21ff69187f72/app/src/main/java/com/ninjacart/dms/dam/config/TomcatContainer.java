package com.ninjacart.dms.dam.config;

import org.apache.coyote.http11.Http11NioProtocol;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.stereotype.Component;

@Component
public class TomcatContainer implements WebServerFactoryCustomizer<TomcatServletWebServerFactory> {

  @Value("${tomcat.max.header.count:200}")
  private int maxHeaderCount;

  @Override
  public void customize(TomcatServletWebServerFactory factory) {
    factory.addConnectorCustomizers(connector -> {
      Http11NioProtocol handler = (Http11NioProtocol) connector.getProtocolHandler();
      handler.setMaxHeaderCount(maxHeaderCount); // set the number
    });
  }
}
