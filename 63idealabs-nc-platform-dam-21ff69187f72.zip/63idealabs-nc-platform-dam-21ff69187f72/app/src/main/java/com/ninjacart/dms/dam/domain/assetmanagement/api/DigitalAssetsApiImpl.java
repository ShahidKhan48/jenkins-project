/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.api;

import com.ninjacart.dms.dam.api.DigitalAssetsApi;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.DigitalAssetMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.SearchRequestMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.SessionContextMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.ActionsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.DigitalAssetsService;
import com.ninjacart.dms.dam.model.DigitalAssetCommandRequest;
import com.ninjacart.dms.dam.model.DigitalAssetDetailsResponse;
import com.ninjacart.dms.dam.model.DigitalAssetListResponse;
import com.ninjacart.dms.dam.model.DigitalAssetRequest;
import com.ninjacart.dms.dam.model.DigitalAssetResponse;
import com.ninjacart.dms.dam.model.SearchRequest;
import com.ninjacart.dms.dam.model.SessionContext;
import com.ninjacart.dms.dam.utils.ResponseUtils;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 * Digital Asset APIs.
 */
@RestController
@RequiredArgsConstructor
public class DigitalAssetsApiImpl implements DigitalAssetsApi {

  private final DigitalAssetsService digitalAssetsService;
  private final ActionsService actionsService;

  @Override
  public ResponseEntity<DigitalAssetResponse> createDigitalAsset(String realmId, String userId,
      DigitalAssetRequest digitalAsset, SessionContext sessionContext) {
    DigitalAsset createdDigitalAsset = digitalAssetsService.create(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId,
        DigitalAssetMapper.INSTANCE.toDomain(digitalAsset));
    return ResponseEntity.ok(
        DigitalAssetMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
            .data(DigitalAssetMapper.INSTANCE.fromDomain(createdDigitalAsset)));
  }

  @Override
  public ResponseEntity<DigitalAssetResponse> deleteDigitalAsset(String id, String realmId,
      String userId, SessionContext sessionContext, Boolean deleteMedia) {
    DigitalAsset digitalAsset = digitalAssetsService.delete(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId, id, deleteMedia);
    return ResponseEntity.ok(
        DigitalAssetMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
            .data(DigitalAssetMapper.INSTANCE.fromDomain(digitalAsset)));
  }

  @Override
  public ResponseEntity<DigitalAssetListResponse> deleteDigitalAssetsBySearch(String realmId,
      String userId, SearchRequest searchRequest, SessionContext sessionContext, Boolean advanced,
      Boolean deleteMedia) {
    return ResponseEntity.ok(
        DigitalAssetMapper.INSTANCE.listFromMetadata(ResponseUtils.successMetadata()).data(
            DigitalAssetMapper.INSTANCE.fromDomain(digitalAssetsService.deleteBySearch(
                SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId,
                SearchRequestMapper.INSTANCE.toDomain(searchRequest), advanced, deleteMedia))));
  }

  @Override
  public ResponseEntity<DigitalAssetResponse> readDigitalAsset(String id, String realmId,
      String userId) {
    DigitalAsset digitalAsset = digitalAssetsService.read(realmId, userId, id);
    return ResponseEntity.ok(
        DigitalAssetMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
            .data(DigitalAssetMapper.INSTANCE.fromDomain(digitalAsset)));
  }

  @Override
  public ResponseEntity<DigitalAssetListResponse> searchDigitalAssets(String realmId, String userId,
      SearchRequest searchQuery, Boolean advanced) {
    List<DigitalAsset> digitalAssets = digitalAssetsService.search(realmId, userId,
        SearchRequestMapper.INSTANCE.toDomain(searchQuery), advanced);

    return ResponseEntity.ok(
        DigitalAssetMapper.INSTANCE.listFromMetadata(ResponseUtils.successMetadata())
            .data(DigitalAssetMapper.INSTANCE.fromDomain(digitalAssets)));
  }

  @Override
  public ResponseEntity<DigitalAssetResponse> updateDigitalAsset(String id, String realmId,
      String userId, DigitalAssetRequest digitalAsset, SessionContext sessionContext) {
    DigitalAsset updatedDigitalAsset = digitalAssetsService.update(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId, id,
        DigitalAssetMapper.INSTANCE.toDomain(digitalAsset), true);
    return ResponseEntity.ok(
        DigitalAssetMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
            .data(DigitalAssetMapper.INSTANCE.fromDomain(updatedDigitalAsset)));
  }

  @Override
  public ResponseEntity<DigitalAssetDetailsResponse> processDigitalAssets(String realmId,
      String userId, String operation, DigitalAssetCommandRequest digitalAssetCommandRequest,
      SessionContext sessionContext) {
    DigitalAssetDetailsResponse digitalAssetResponse = DigitalAssetMapper.INSTANCE.toDigitalAssetDetailsResponse(
        actionsService.processDigitalAsset(SessionContextMapper.INSTANCE.toDomain(sessionContext),
            realmId, userId, operation,
            DigitalAssetMapper.INSTANCE.toCommand(digitalAssetCommandRequest)));
    return new ResponseEntity<>(digitalAssetResponse, HttpStatus.OK);
  }
}
