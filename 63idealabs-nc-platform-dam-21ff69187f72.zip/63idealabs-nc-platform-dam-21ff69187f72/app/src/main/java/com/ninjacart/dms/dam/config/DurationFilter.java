/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.config;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletResponseWrapper;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Adds duration in X_RESPONSE_TIME Header.
 */
@Component
@Slf4j
public class DurationFilter implements Filter {

  private static final String X_RESPONSE_TIME = "X-Response-Time";

  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws IOException, ServletException {
    long startTime = System.currentTimeMillis();
    request.setAttribute("startTime", startTime);

    /*
     * USING THIS TO OVERCOME
     * handlerInterceptor.postComplete and
     * responseAdvice.beforeBodyWrite
     * inability to add response headers after execution
     */
    HttpServletResponse wrappedResponse = new HttpServletResponseWrapper(
        (HttpServletResponse) response) {

      @Override
      public void setStatus(int sc) {
        super.setStatus(sc);
        addResponseTimeHeader(request, this);
      }
    };
    chain.doFilter(request, wrappedResponse);
  }

  private void addResponseTimeHeader(ServletRequest request, HttpServletResponse wrappedResponse) {
    long startTime = (Long) request.getAttribute("startTime");
    long endTime = System.currentTimeMillis();
    long executeTime = endTime - startTime;

    wrappedResponse.addHeader(X_RESPONSE_TIME, String.valueOf(executeTime));
  }
}
