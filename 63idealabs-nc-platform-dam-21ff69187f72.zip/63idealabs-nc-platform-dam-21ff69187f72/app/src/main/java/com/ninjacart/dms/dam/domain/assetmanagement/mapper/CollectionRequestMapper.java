/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.mapper;

import com.ninjacart.dms.dam.domain.assetmanagement.command.CollectionRequestCommand;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.model.CollectionRequest;
import com.ninjacart.dms.dam.model.CollectionRequestCommandRequest;
import com.ninjacart.dms.dam.model.CollectionRequestListResponse;
import com.ninjacart.dms.dam.model.CollectionRequestResponse;
import com.ninjacart.dms.dam.model.DigitalAssetRequest;
import com.ninjacart.dms.dam.model.Metadata;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * Mapper For Collection Request for API Specification and Domain.
 */
@Mapper
public interface CollectionRequestMapper {

  CollectionRequestMapper INSTANCE = Mappers.getMapper(CollectionRequestMapper.class);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param collectionRequestResponse domain object.
   * @return API Specification Object.
   */
  CollectionRequestResponse toResponse(
      com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestResponse collectionRequestResponse);

  /**
   * Converts API Specification Object to Domain Object.
   *
   * @param collectionRequestCommandRequest API Specification Object.
   * @return Domain Object.
   */
  CollectionRequestCommand toCommand(
      CollectionRequestCommandRequest collectionRequestCommandRequest);

  /**
   * Get Response from Metadata.
   *
   * @param metadata metadata
   * @return response
   */
  CollectionRequestResponse fromMetadata(Metadata metadata);

  /**
   * Get Response from Metadata.
   *
   * @param metadata metadata
   * @return response
   */
  CollectionRequestListResponse listFromMetadata(Metadata metadata);

  /**
   * Converts API Specification Object to Domain Object.
   *
   * @param collectionRequest API Specification Object.
   * @return Domain Object.
   */
  com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest toDomain(
      CollectionRequest collectionRequest);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param collectionRequest domain object.
   * @return API Specification Object.
   */
  CollectionRequest fromDomain(
      com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest collectionRequest);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param collectionRequests domain object.
   * @return API Specification Object.
   */
  List<CollectionRequest> fromDomain(
      List<com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest> collectionRequests);
}
