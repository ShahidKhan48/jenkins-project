package com.ninjacart.dms.dam.domain.consentmanagement.api;

import com.ninjacart.dms.dam.api.ConsentsApi;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.SearchRequestMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.mapper.SessionContextMapper;
import com.ninjacart.dms.dam.domain.consentmanagement.mapper.ConsentMapper;
import com.ninjacart.dms.dam.domain.consentmanagement.model.Consent;
import com.ninjacart.dms.dam.domain.consentmanagement.port.in.ConsentsService;
import com.ninjacart.dms.dam.model.ConsentListResponse;
import com.ninjacart.dms.dam.model.ConsentRequest;
import com.ninjacart.dms.dam.model.ConsentResponse;
import com.ninjacart.dms.dam.model.SearchRequest;
import com.ninjacart.dms.dam.model.SessionContext;
import com.ninjacart.dms.dam.utils.ResponseUtils;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

/**
 * Consents API.
 */
@RestController
@RequiredArgsConstructor
public class ConsentsApiImpl implements ConsentsApi {

  private final ConsentsService consentsService;

  @Override
  public ResponseEntity<ConsentResponse> createConsent(String realmId, String userId,
      ConsentRequest consentRequest, SessionContext sessionContext) {
    Consent createdConsent = consentsService.create(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId,
        ConsentMapper.INSTANCE.toDomain(consentRequest));
    return ResponseEntity.ok(ConsentMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
        .data(ConsentMapper.INSTANCE.fromDomain(createdConsent)));
  }

  @Override
  public ResponseEntity<ConsentResponse> readConsent(String id, String realmId, String userId) {
    Consent consent = consentsService.read(realmId, userId, id);
    return ResponseEntity.ok(ConsentMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
        .data(ConsentMapper.INSTANCE.fromDomain(consent)));
  }

  @Override
  public ResponseEntity<ConsentListResponse> searchConsents(String realmId, String userId,
      SearchRequest searchRequest, Boolean advanced) {
    List<Consent> consents = consentsService.search(realmId, userId,
        SearchRequestMapper.INSTANCE.toDomain(searchRequest), advanced);

    return ResponseEntity.ok(
        ConsentMapper.INSTANCE.listFromMetadata(ResponseUtils.successMetadata())
            .data(ConsentMapper.INSTANCE.fromDomain(consents)));
  }

  @Override
  public ResponseEntity<ConsentResponse> updateConsent(String id, String realmId, String userId,
      ConsentRequest consentRequest, SessionContext sessionContext) {
    Consent updatedConsent = consentsService.update(
        SessionContextMapper.INSTANCE.toDomain(sessionContext), realmId, userId, id,
        ConsentMapper.INSTANCE.toDomain(consentRequest), true);
    return ResponseEntity.ok(ConsentMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
        .data(ConsentMapper.INSTANCE.fromDomain(updatedConsent)));
  }
}
