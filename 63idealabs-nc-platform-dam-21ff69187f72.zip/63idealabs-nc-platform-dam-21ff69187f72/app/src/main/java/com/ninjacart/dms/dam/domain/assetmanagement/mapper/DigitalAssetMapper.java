/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.mapper;

import com.ninjacart.dms.dam.domain.assetmanagement.command.DigitalAssetCommand;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.model.DigitalAssetCommandRequest;
import com.ninjacart.dms.dam.model.DigitalAssetDetailsResponse;
import com.ninjacart.dms.dam.model.DigitalAssetListResponse;
import com.ninjacart.dms.dam.model.DigitalAssetRequest;
import com.ninjacart.dms.dam.model.DigitalAssetResponse;
import com.ninjacart.dms.dam.model.Metadata;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

/**
 * Mapper For Digital Assets for API Specification and Domain.
 */
@Mapper
public interface DigitalAssetMapper {

  DigitalAssetMapper INSTANCE = Mappers.getMapper(DigitalAssetMapper.class);

  /**
   * Get Response from Metadata.
   *
   * @param metadata metadata
   * @return response
   */
  @Mapping(target = "status", ignore = true)
  DigitalAssetResponse fromMetadata(Metadata metadata);

  /**
   * Get Response from Metadata.
   *
   * @param metadata metadata
   * @return response
   */
  DigitalAssetListResponse listFromMetadata(Metadata metadata);

  /**
   * Converts API Specification Object to Domain Object.
   *
   * @param digitalAssetCommandRequest API Specification Object.
   * @return Domain Object.
   */
  DigitalAssetCommand toCommand(DigitalAssetCommandRequest digitalAssetCommandRequest);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param digitalAssetResponse domain object.
   * @return API Specification Object.
   */
  DigitalAssetResponse toResponse(
      com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetResponse digitalAssetResponse);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param digitalAssetDetailsResponse domain object.
   * @return API Specification Object.
   */
  @Mappings({
      @Mapping(target = "data", source = "digitalAsset"),
      @Mapping(target = "digitalAssetDetails", source = "data")})
  DigitalAssetDetailsResponse toDigitalAssetDetailsResponse(
      com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDetailsResponse digitalAssetDetailsResponse);

  /**
   * Converts API Specification Object to Domain Object.
   *
   * @param digitalAsset API Specification Object.
   * @return API Specification Object.
   */
  DigitalAsset toDomain(DigitalAssetRequest digitalAsset);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param digitalAsset domain object.
   * @return API Specification Object.
   */
  DigitalAssetRequest fromDomain(DigitalAsset digitalAsset);

  /**
   * Converts Domain Object to API Specification Object.
   *
   * @param digitalAssets domain object.
   * @return API Specification Object.
   */
  List<DigitalAssetRequest> fromDomain(List<DigitalAsset> digitalAssets);
}
