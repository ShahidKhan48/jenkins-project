package com.ninjacart.dms.dam.exception;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

import com.ninjacart.dms.dam.constants.ApplicationConstants;
import com.ninjacart.platform.commons.error.exceptions.NinjaException;
import com.ninjacart.platform.commons.error.exceptions.NinjaRuntimeException;
import com.ninjacart.platform.commons.error.iface.ErrorResponseMapper;
import com.ninjacart.platform.commons.error.iface.ServiceErrorCode;
import com.ninjacart.platform.commons.error.utils.ErrorUtils;
import java.time.Instant;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.ErrorResponse;
import org.springframework.web.ErrorResponse.Builder;

/**
 * This class is used to map the exception to the response.
 */
@RequiredArgsConstructor
@Component
public class ProblemDetailMapper implements ErrorResponseMapper<ErrorResponse> {

  private final MessageSource messageSource;

  @Override
  public ErrorResponse map(Exception ex, Locale locale, Object... params) {
    if (ex instanceof NinjaException ne) {
      return handleNinjaException(ne, locale);
    } else if (ex instanceof NinjaRuntimeException nre) {
      return handleNinjaRuntimeException(nre, locale);
    } else {
      return handleUnknownException(ex, locale, params);
    }
  }

  private ErrorResponse handleUnknownException(Exception ex, Locale locale, Object[] params) {
    String defaultMsg = ErrorUtils.format(ex.getMessage(), params);
    return ErrorResponse.builder(ex, INTERNAL_SERVER_ERROR, defaultMsg)
        .title(INTERNAL_SERVER_ERROR.getReasonPhrase())
        .property(ApplicationConstants.TIMESTAMP, Instant.now()).build();
  }

  private ErrorResponse handleNinjaRuntimeException(NinjaRuntimeException nre, Locale locale) {
    return getFailure(locale, nre.getMessage(), nre.getParams(), nre.getErrorCode(), nre);
  }

  private ErrorResponse handleNinjaException(NinjaException ne, Locale locale) {
    return getFailure(locale, ne.getMessage(), ne.getParams(), ne.getErrorCode(), ne);
  }

  private ErrorResponse getFailure(Locale locale, String message, Object[] params,
      ServiceErrorCode errorCode, Exception e) {
    String defaultMsg = ErrorUtils.format(message, params);
    String code = errorCode.getCode();
    int status = errorCode.getStatus();
    String msg = Optional.ofNullable(messageSource.getMessage(code, null, defaultMsg, locale))
        .orElse(StringUtils.EMPTY);
    msg = ErrorUtils.format(msg, params);

    Builder builder = ErrorResponse.builder(e, HttpStatusCode.valueOf(status), msg).title(code)
        .property(ApplicationConstants.TIMESTAMP, Instant.now());
    if (Objects.nonNull(params) && params.length > 0 && !(params[0] instanceof Throwable)) {
      builder.property(ApplicationConstants.MESSAGE, params[0]);
    }
    return builder.build();
  }
}
