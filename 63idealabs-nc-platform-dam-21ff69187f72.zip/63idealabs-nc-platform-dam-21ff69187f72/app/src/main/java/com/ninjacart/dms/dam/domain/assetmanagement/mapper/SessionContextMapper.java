package com.ninjacart.dms.dam.domain.assetmanagement.mapper;

import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * Mapper For Session Context for API Specification and Domain.
 */
@Mapper
public interface SessionContextMapper {

  SessionContextMapper INSTANCE = Mappers.getMapper(SessionContextMapper.class);

  /**
   * Converts API Specification Object to Domain Object.
   *
   * @param sessionContext API specification object
   * @return domain Object
   */
  SessionContext toDomain(com.ninjacart.dms.dam.model.SessionContext sessionContext);
}
