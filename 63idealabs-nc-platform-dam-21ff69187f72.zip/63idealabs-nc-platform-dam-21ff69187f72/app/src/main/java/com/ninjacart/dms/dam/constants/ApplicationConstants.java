package com.ninjacart.dms.dam.constants;

import lombok.experimental.UtilityClass;

/**
 * Application Constants.
 */
@UtilityClass
public class ApplicationConstants {

  public static final String MESSAGE = "message";
  public static final String TIMESTAMP = "timestamp";
}
