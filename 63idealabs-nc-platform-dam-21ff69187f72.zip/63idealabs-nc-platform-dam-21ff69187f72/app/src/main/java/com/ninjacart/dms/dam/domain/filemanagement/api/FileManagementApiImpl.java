/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.filemanagement.api;

import com.ninjacart.dms.dam.api.FileManagementApi;
import com.ninjacart.dms.dam.domain.assetmanagement.model.MediaDetail;
import com.ninjacart.dms.dam.domain.filemanagement.mapper.MediaDetailMapper;
import com.ninjacart.dms.dam.domain.filemanagement.model.FileContent;
import com.ninjacart.dms.dam.domain.filemanagement.port.in.FileManagementService;
import com.ninjacart.dms.dam.exception.DAMRuntimeException;
import com.ninjacart.dms.dam.exception.DAMServiceErrorCode;
import com.ninjacart.dms.dam.model.MediaDetailListResponse;
import com.ninjacart.dms.dam.model.MediaDetailRequest;
import com.ninjacart.dms.dam.model.MediaDetailResponse;
import com.ninjacart.dms.dam.model.SessionContext;
import com.ninjacart.dms.dam.utils.ResponseUtils;
import java.io.IOException;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * File Management APIs.
 */
@RestController
@RequiredArgsConstructor
public class FileManagementApiImpl implements FileManagementApi {

  private final FileManagementService fileManagementService;

  @Override
  public ResponseEntity<MediaDetailResponse> fileUpload(String realmId, String userId,
      List<MultipartFile> files, SessionContext sessionContext, String storageProvider, String path) {
    List<FileContent> fileContents = files.stream().map(eachFile -> {
      try {
        return FileContent.builder().byteContent(eachFile.getBytes())
            .contentType(eachFile.getContentType()).originalFilename(eachFile.getOriginalFilename())
            .build();
      } catch (IOException e) {
        throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_002, e);
      }
    }).toList();
    MediaDetail uploadedFile = fileManagementService.uploadFile(realmId, userId, path, fileContents,
        storageProvider);
    return ResponseEntity.ok(
        MediaDetailMapper.INSTANCE.fromMetadata(ResponseUtils.successMetadata())
            .data(MediaDetailMapper.INSTANCE.fromDomain(uploadedFile)));
  }

  @Override
  public ResponseEntity<MediaDetailListResponse> presignUrl(String realmId, String userId,
      List<MediaDetailRequest> mediaDetails, SessionContext sessionContext, Integer expiryInMin) {
    List<MediaDetail> presignedMediaDetails = fileManagementService.presignUrls(realmId, userId,
        MediaDetailMapper.INSTANCE.toDomain(mediaDetails), expiryInMin);
    return ResponseEntity.ok(
        MediaDetailMapper.INSTANCE.listFromMetadata(ResponseUtils.successMetadata())
            .data(MediaDetailMapper.INSTANCE.fromDomain(presignedMediaDetails)));
  }
}
