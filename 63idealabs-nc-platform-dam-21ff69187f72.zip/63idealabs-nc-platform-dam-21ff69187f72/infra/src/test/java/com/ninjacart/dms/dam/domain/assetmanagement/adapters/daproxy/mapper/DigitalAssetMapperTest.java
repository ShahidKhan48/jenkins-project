/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.daproxy.mapper;

import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DocumentData;
import com.ninjacart.dms.daproxy.model.DocumentInfo;
import com.ninjacart.dms.daproxy.model.FetchAssetResponseData;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class DigitalAssetMapperTest {

  private static final String providerReferenceId = "b1565337-6af8-4255-867e-2fe5ed4eb742";
  private static final String dob = "1970-01-01";
  private static final String name = "name";
  private static final String documentIdentifier = "1234-5678-9876";
  private static FetchAssetResponseData fetchAssetResponse;
  private static DocumentInfo documentInfo;

  @BeforeAll
  static void init() {
    documentInfo = DocumentInfo.builder().name(name).dob(dob).documentIdentifier(documentIdentifier)
        .build();
    fetchAssetResponse = FetchAssetResponseData.builder().providerReferenceId(providerReferenceId)
        .documentInfo(documentInfo).build();
  }

  @Test
  @DisplayName("FetchAssetResponseData to DigitalAsset conversion test")
  void toDigitalAsset() {
    DigitalAsset digitalAsset = DigitalAssetMapper.INSTANCE.toDigitalAsset(fetchAssetResponse);

    // Validate custom mapping ProviderReferenceId -> ExternalReferenceId.
    Assertions.assertEquals(fetchAssetResponse.getProviderReferenceId(),
        digitalAsset.getExternalReferenceId());

    // Validate custom mapping DocumentInfo.dob -> DocumentData.dob
    Assertions.assertEquals(fetchAssetResponse.getDocumentInfo().getDob(),
        digitalAsset.getDocumentData().getDob());

    // Validate custom mapping DocumentInfo.documentIdentifier -> DocumentData.identifier
    Assertions.assertEquals(fetchAssetResponse.getDocumentInfo().getDocumentIdentifier(),
        digitalAsset.getDocumentData().getIdentifier());
  }

  @Test
  @DisplayName("DocumentInfo to DocumentData conversion test")
  void toDocumentData() {
    DocumentData documentData = DigitalAssetMapper.INSTANCE.toDocumentData(documentInfo);

    // Validation all variables are mapped properly
    Assertions.assertEquals(documentInfo.getName(), documentData.getName());
    Assertions.assertEquals(documentInfo.getDob(), documentData.getDob());
    Assertions.assertEquals(documentInfo.getDocumentIdentifier(), documentData.getIdentifier());
  }
}