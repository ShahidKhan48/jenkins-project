/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.config.events;

import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.EventProducerProvider;

/**
 * Registers all the clusters present in the configuration to the EventProducerProvider.
 */
public class EventHubRegistration {

  private final EventHubConfiguration eventHubConfiguration;
  private final EventProducerProvider eventProducerProvider;

  /**
   * Initialize producers for each cluster based on configuration
   */
  public EventHubRegistration(EventHubConfiguration eventHubConfiguration,
      EventProducerProvider eventProducerProvider1) {

    this.eventHubConfiguration = eventHubConfiguration;
    this.eventProducerProvider = eventProducerProvider1;
  }
}
