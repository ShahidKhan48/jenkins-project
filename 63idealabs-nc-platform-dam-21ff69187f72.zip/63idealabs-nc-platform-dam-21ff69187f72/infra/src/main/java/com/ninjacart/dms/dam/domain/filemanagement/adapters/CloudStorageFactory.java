/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.filemanagement.adapters;

import com.ninjacart.dms.dam.domain.filemanagement.port.out.CloudStorageProviderFactory;
import com.ninjacart.dms.dam.domain.filemanagement.port.out.CloudStorageService;
import jakarta.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * This factory class is responsible for providing the appropriate CloudStorageService based on the
 * cloud provider.
 */
@RequiredArgsConstructor
@Slf4j
public class CloudStorageFactory implements CloudStorageProviderFactory {

  private static final String DEFAULT_STORAGE_PROVIDER = "S3";
  private static final Map<String, CloudStorageService> CLOUD_STORAGE_SERVICE_MAP = new HashMap<>();

  private final List<CloudStorageService> cloudStorageProviders;

  @PostConstruct
  public void postConstruct() {
    CLOUD_STORAGE_SERVICE_MAP.putAll(cloudStorageProviders.stream()
        .collect(Collectors.toMap(CloudStorageService::provider, Function.identity())));
  }

  @Override
  public CloudStorageService getCloudStorageService(String provider) {
    CloudStorageService factoryProvider = CLOUD_STORAGE_SERVICE_MAP.getOrDefault(
        Optional.ofNullable(provider).orElse(DEFAULT_STORAGE_PROVIDER),
        getDefaultCloudStorageService());

    if (Objects.isNull(factoryProvider)) {
      log.error("Invalid cloud storage provider: " + provider);
      throw new IllegalArgumentException("Invalid cloud storage provider: " + provider);
    }

    return factoryProvider;
  }

  private CloudStorageService getDefaultCloudStorageService() {
    return CLOUD_STORAGE_SERVICE_MAP.get(DEFAULT_STORAGE_PROVIDER);
  }

  @Override
  public String getDefaultStorageProvider() {
    return DEFAULT_STORAGE_PROVIDER;
  }
}

