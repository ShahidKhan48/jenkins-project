/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class EventConfig {

  @Bean("asyncExecutor")
  public TaskExecutor threadPoolTaskExecutor(
      @Value("${infra.asyncExecutor.thread-pool.core-size:5}") Integer coreSize,
      @Value("${infra.asyncExecutor.thread-pool.max-size:10}") Integer maxSize,
      @Value("${infra.asyncExecutor.thread-pool.queue-size:100}") Integer queueSize) {
    final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    executor.setCorePoolSize(coreSize);
    executor.setMaxPoolSize(maxSize);
    executor.setQueueCapacity(queueSize);
    executor.initialize();
    return executor;
  }
}
