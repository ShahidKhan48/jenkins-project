/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events;

import com.ninjacart.dms.dam.config.events.EventHubCluster;
import com.ninjacart.dms.dam.exception.DAMRuntimeException;
import com.ninjacart.dms.dam.exception.DAMServiceErrorCode;
import com.ninjacart.dp.commons.events.producer.EventProducer;
import com.ninjacart.dp.commons.events.producer.config.EventProducerConfig;
import com.ninjacart.dp.commons.events.producer.exception.EventProducerException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * Sends message to different clusters based on Cluster Id provided by the client.
 */
@Slf4j
public class EventProducerProvider {

  private final String schemaUrl;
  private final String basicAuthToken;
  private final Map<String, EventProducer> clusterEventProducerMap = new HashMap<>();
  private static final int KAFKA_RETRIES = 3;
  private static final String KAFKA_PRODUCER_DELAY_IN_MILLIS = "5000";

  public EventProducerProvider(String schemaUrl, String basicAuthToken,
      List<EventHubCluster> eventHubClusters) {
    this.schemaUrl = schemaUrl;
    this.basicAuthToken = basicAuthToken;
    registerClusters(eventHubClusters);
  }

  private void registerClusters(List<EventHubCluster> clusters) {
    if (CollectionUtils.isNotEmpty(clusters)) {
      for (EventHubCluster cluster : clusters) {
        clusterEventProducerMap.put(cluster.getClusterId(),
            buildClusterEventProducer(schemaUrl, cluster));
      }
    }
  }

  private EventProducer buildClusterEventProducer(String schemaUrl, EventHubCluster cluster) {
    EventProducerConfig config = new EventProducerConfig();
    config.setSchemaRegistryUrl(schemaUrl);
    config.setSchemaRegistryAuth(basicAuthToken);
    config.setSaslJaasConfig(cluster.getJaasConfig());
    config.setKafkaBrokers(cluster.getBrokerUrl());
    config.setSaslMechanism("PLAIN");
    config.setRetryCount(KAFKA_RETRIES);
    config.setProperties(getEventProducerProps());

    return new EventProducer(config);
  }

  private Map<String, String> getEventProducerProps() {
    HashMap<String, String> properties = new HashMap<>();
    properties.put("linger.ms", KAFKA_PRODUCER_DELAY_IN_MILLIS);
    return properties;
  }

  /**
   * Send event through event hub for the given cluster id
   *
   * @param clusterId cluster id as per configuration
   * @param topic     topic of message to be sent
   * @param key       unique identifier for the payload
   * @param payload   the actual payload
   * @param schemaId  the schema definition for the given payload
   * @return Future response, if it is needed
   */
  public Future<?> sendEventWithSchema(String clusterId, String topic, String key, Object payload,
      String schemaId) throws RuntimeException {
    if (StringUtils.isEmpty(clusterId) || !clusterEventProducerMap.containsKey(clusterId)) {
      log.error("Cluster not defined for event");
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_009);
    } else {
      try {
        return clusterEventProducerMap.get(clusterId)
            .sendEventWithSchema(topic, key, payload, schemaId, false);
      } catch (EventProducerException epe) {
        log.error(epe.getMessage());
        throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_010, epe);
      }
    }
  }

  /**
   * Send event through event hub for the given cluster id
   *
   * @param clusterId cluster id as per configuration
   * @param topic     topic of message to be sent
   * @param key       unique identifier for the payload
   * @param payload   the actual payload
   * @return Future response, if it is needed
   */
  public Future<?> sendEvent(String clusterId, String topic, String key, Object payload)
      throws RuntimeException {
    if (StringUtils.isEmpty(clusterId) || !clusterEventProducerMap.containsKey(clusterId)) {
      log.error("Cluster not defined for event");
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_009);
    } else {
      try {
        return clusterEventProducerMap.get(clusterId).sendEvent(topic, key, payload);
      } catch (EventProducerException epe) {
        log.error(epe.getMessage());
        throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_010, epe);
      }
    }
  }
}

