/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Setter
@Getter
@RefreshScope
@Configuration
@ConfigurationProperties(prefix = "infra.schema-registry")
public class SchemaRegistryConfig {

  private String serviceUrl;
  private String connectionUrl;
  private String groups;
  private boolean authEnabled;
  private String userName;
  private String password;
  private String basicAuth;
}
