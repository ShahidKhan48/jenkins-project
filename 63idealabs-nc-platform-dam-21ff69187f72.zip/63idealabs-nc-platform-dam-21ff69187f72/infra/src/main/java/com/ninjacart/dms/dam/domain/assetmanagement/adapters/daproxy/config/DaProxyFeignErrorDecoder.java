/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.daproxy.config;

import static com.ninjacart.dms.dam.utils.JSONUtil.OBJECT_MAPPER;

import com.fasterxml.jackson.databind.JsonNode;
import com.ninjacart.dms.dam.exception.DAMRuntimeException;
import com.ninjacart.dms.dam.exception.DAMServiceErrorCode;
import feign.Response;
import feign.codec.ErrorDecoder;
import java.io.IOException;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;

/**
 * Da-Proxy Client Error Decoder.
 */
@Slf4j
public class DaProxyFeignErrorDecoder implements ErrorDecoder {

  @Override
  public Exception decode(String s, Response response) {
    try {
      JsonNode apiResponse = OBJECT_MAPPER.readValue(response.body().asInputStream(),
          JsonNode.class);
      log.error("DaProxy ERROR: {}", apiResponse);
      return new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_019,
          getErrorMessage(apiResponse));
    } catch (IOException e) {
      log.error("Something went wrong: {}", e.getMessage(), e);
      return new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_019,
          response.body().toString());
    }
  }

  private String getErrorMessage(JsonNode apiResponse) {
    return Optional.ofNullable(apiResponse.get("message")).map(JsonNode::asText)
        .orElse(String.valueOf(apiResponse));
  }
}
