/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.utils;

import lombok.experimental.UtilityClass;
import org.apache.tika.Tika;

/**
 * File Utils.
 */
@UtilityClass
public class FileUtils {

  public static final Tika TIKA = new Tika();

  /**
   * Extract MIME type from file and name.
   *
   * @param fileData fileData.
   * @param name     name of the file.
   * @return MIME type of the file.
   */
  public static String getMimeType(byte[] fileData, String name) {
    return TIKA.detect(fileData, name);
  }
}
