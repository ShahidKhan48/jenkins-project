/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.daproxy.mapper;

import com.ninjacart.dms.dam.constants.InfraConstants;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDetails;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DocumentData;
import com.ninjacart.dms.daproxy.model.DocumentInfo;
import com.ninjacart.dms.daproxy.model.FetchAssetResponse;
import com.ninjacart.dms.daproxy.model.FetchAssetResponseData;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * Mapper to convert {@link FetchAssetResponse} to {@link DigitalAsset}.
 */
@Mapper
public interface DigitalAssetMapper {

  DigitalAssetMapper INSTANCE = Mappers.getMapper(DigitalAssetMapper.class);

  /**
   * converts {@link FetchAssetResponse} to {@link DigitalAsset}.
   *
   * @param fetchAssetResponse {@link FetchAssetResponse} to be converted.
   * @return converted {@link DigitalAsset}.
   */
  @Mapping(source = InfraConstants.PROVIDER_REFERENCE_ID, target = InfraConstants.EXTERNAL_REFERENCE_ID)
  @Mapping(source = InfraConstants.DOCUMENT_INFO, target = InfraConstants.DOCUMENT_DATA)
  @Mapping(source = InfraConstants.DOCUMENT_INFO_DOCUMENT_IDENTIFIER, target = InfraConstants.DOCUMENT_DATA_IDENTIFIER)
  DigitalAsset toDigitalAsset(FetchAssetResponseData fetchAssetResponse);


  /**
   * converts {@link FetchAssetResponse} to {@link DigitalAssetDetails}.
   *
   * @param fetchAssetResponse {@link FetchAssetResponse} to be converted.
   * @return converted {@link DigitalAssetDetails}.
   */
  @Mapping(source = InfraConstants.PROVIDER_REFERENCE_ID, target = InfraConstants.EXTERNAL_REFERENCE_ID)
  @Mapping(source = InfraConstants.DOCUMENT_INFO, target = InfraConstants.DOCUMENT_DATA)
  @Mapping(source = InfraConstants.DOCUMENT_INFO_DOCUMENT_IDENTIFIER, target = InfraConstants.DOCUMENT_DATA_IDENTIFIER)
  DigitalAssetDetails toDigitalAssetDetails(FetchAssetResponseData fetchAssetResponse);
  /**
   * converts {@link FetchAssetResponse} to {@link CollectionRequest}.
   *
   * @param fetchAssetResponse {@link FetchAssetResponse} to be converted.
   * @return converted {@link CollectionRequest}.
   */
  CollectionRequest toCollectionRequest(FetchAssetResponseData fetchAssetResponse);

  /**
   * Converts {@link DocumentInfo} into {@link DocumentData}.
   *
   * @param documentInfo {@link DocumentInfo} to be converted.
   * @return converted {@link DocumentData}.
   */
  @Mapping(source = InfraConstants.DOCUMENT_IDENTIFIER, target = InfraConstants.IDENTIFIER)
  DocumentData toDocumentData(DocumentInfo documentInfo);

}
