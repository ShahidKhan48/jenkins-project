package com.ninjacart.dms.dam.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

/**
 * Elastic Search Config.
 */
@Setter
@Getter
@RefreshScope
@Configuration
@ConfigurationProperties(prefix = "infra.persistence.elastic")
public class ESConfig {

  private String connectionUrl;
  private String connectionUrlPort;
  private String connectionUser;
  private String connectionPassword;
}
