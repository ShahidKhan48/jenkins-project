/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.filemanagement.adapters;


import com.ninjacart.dms.dam.domain.assetmanagement.model.MediaDetail;
import com.ninjacart.dms.dam.domain.filemanagement.port.out.CloudStorageService;
import com.ninjacart.dms.dam.exception.DAMRuntimeException;
import com.ninjacart.dms.dam.exception.DAMServiceErrorCode;
import com.ninjacart.dms.dam.utils.FileUtils;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.PathContainer;
import org.springframework.http.server.PathContainer.Element;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.GetUrlRequest;
import software.amazon.awssdk.services.s3.model.ObjectCannedACL;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

/**
 * This class is an implementation of the CloudStorageService interface specifically for AWS S3.
 */
@RequiredArgsConstructor
@Slf4j
public class AwsS3Service implements CloudStorageService {

  public static final String DEFAULT_S3_PATH = "s3.amazonaws.com";

  private final String defaultBucket;
  private final String defaultRegion;
  private final S3ClientFactory s3ClientFactory;

  private static boolean defaultPath(PathContainer pathContainer) {
    return pathContainer.subPath(3, 4).toString().equals(DEFAULT_S3_PATH);
  }

  @Override
  public String uploadPrivate(String bucketName, String filePath, byte[] fileData, String mimeType,
      String region) {
    return upload(bucketName, filePath, fileData, region, ObjectCannedACL.PRIVATE);
  }

  private String upload(String bucketName, String filePath, byte[] fileData, String region,
      ObjectCannedACL objectCannedACL) {
    S3Client s3Client = getClient(region);
    if (StringUtils.isEmpty(bucketName)) {
      bucketName = defaultBucket;
    }
    Map<String, String> metadata = new HashMap<>();
    metadata.put(HttpHeaders.CONTENT_LENGTH, String.valueOf(fileData.length));
    metadata.put(HttpHeaders.CONTENT_TYPE, FileUtils.getMimeType(fileData, filePath));
    PutObjectRequest putObjectRequest = PutObjectRequest.builder().bucket(bucketName).key(filePath)
        .metadata(metadata).acl(objectCannedACL).build();
    s3Client.putObject(putObjectRequest, RequestBody.fromBytes(fileData));
    GetUrlRequest request = GetUrlRequest.builder().bucket(bucketName).key(filePath).build();
    return s3Client.utilities().getUrl(request).toExternalForm();
  }

  @Override
  public String uploadPublic(String bucketName, String filePath, byte[] fileData, String mimeType,
      String region) {
    return upload(bucketName, filePath, fileData, region, ObjectCannedACL.PUBLIC_READ);
  }

  @Override
  public byte[] downloadAsArray(String bucketName, String filePath, String region) {
    S3Client s3Client = getClient(region);
    if (StringUtils.isEmpty(bucketName)) {
      bucketName = defaultBucket;
    }
    GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(bucketName).key(filePath)
        .build();
    ResponseBytes<GetObjectResponse> objectBytes = s3Client.getObjectAsBytes(getObjectRequest);
    byte[] data = objectBytes.asByteArray();
    return data;
  }

  @Override
  public void delete(String bucketName, String filePath, String region) {
    if (StringUtils.isEmpty(filePath)) {
      return;
    }
    S3Client s3Client = getClient(region);
    if (StringUtils.isEmpty(bucketName)) {
      bucketName = defaultBucket;
    }
    DeleteObjectRequest deleteObjectRequest = null;
    try {
      deleteObjectRequest = DeleteObjectRequest.builder().bucket(bucketName)
          .key(new URI(filePath).getPath().substring(1)).build();
      s3Client.deleteObject(deleteObjectRequest);
    } catch (URISyntaxException e) {
      log.error("Error during Delete Media: {}", filePath);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_021, filePath, e);
    }
  }

  private S3Client getClient(String region) {
    S3Client s3Client;
    if (StringUtils.isEmpty(region)) {
      region = defaultRegion;
    }
    s3Client = s3ClientFactory.getClientByRegion(region);
    return s3Client;
  }

  @Override
  public List<MediaDetail> presignUrl(List<MediaDetail> media, Integer expiryInMin) {
    for (MediaDetail mediaDetail : media) {
      GetObjectRequest getObjectRequest = GetObjectRequest.builder()
          .bucket(getObjectBucket(mediaDetail.getMediaUrl()))
          .key(getObjectKey(mediaDetail.getMediaUrl())).build();

      GetObjectPresignRequest getObjectPresignRequest = GetObjectPresignRequest.builder()
          .signatureDuration(Duration.ofMinutes(ObjectUtils.defaultIfNull(expiryInMin, 10)))
          .getObjectRequest(getObjectRequest).build();

      // Generate the presigned request
      PresignedGetObjectRequest presignedGetObjectRequest = s3ClientFactory.getPresignerByRegion(
          defaultRegion).presignGetObject(getObjectPresignRequest);

      // Log the presigned URL, for example.
      log.debug("Presigned URL: " + presignedGetObjectRequest.url());
      mediaDetail.setPresignedUrl(presignedGetObjectRequest.url().toString());
    }

    return media;
  }

  private String getObjectKey(String mediaUrl) {
    PathContainer pathContainer = PathContainer.parsePath(mediaUrl);

    if (defaultPath(pathContainer)) {
      return pathContainer.elements().subList(7, pathContainer.elements().size()).stream()
          .map(Element::value).collect(Collectors.joining());
    } else {
      return pathContainer.elements().subList(5, pathContainer.elements().size()).stream()
          .map(Element::value).collect(Collectors.joining());
    }
  }

  private String getObjectBucket(String mediaUrl) {
    PathContainer pathContainer = PathContainer.parsePath(mediaUrl);

    if (defaultPath(pathContainer)) {
      return pathContainer.elements().get(5).value();
    } else {
      String hostPath = pathContainer.elements().get(3).value();
      return hostPath.substring(0, hostPath.indexOf("."));
    }
  }

  @Override
  public String provider() {
    return "S3";
  }
}
