/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.persistence;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ninjacart.dms.dam.constants.InfraConstants;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.DefinitionsManager;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models.SchemaInfo;
import com.ninjacart.dms.dam.exception.DAMRuntimeException;
import com.ninjacart.dms.dam.exception.DAMServiceErrorCode;
import com.ninjacart.dms.dam.utils.JSONUtil;
import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.net.ConnectException;
import java.time.Instant;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.CollectionOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;

/**
 * Implementation for MongoDB as persistence unit.
 */
@Slf4j
@RequiredArgsConstructor
public class MongoProvider implements IPersistenceProvider {

  private final DefinitionsManager definitionsManager;
  private final MongoTemplate mongoTemplate;

  @PostConstruct
  public void initializeMongoProvider() {
    Set<String> definitions = definitionsManager.getAllKnownDefinitions();
    for (String definition : definitions) {
      if (!mongoTemplate.collectionExists(definition)) {
        mongoTemplate.createCollection(definition, CollectionOptions.empty());
      }
    }
  }

  @Retryable(value = {IOException.class,
      ConnectException.class}, maxAttemptsExpression = "#{${service.retry.maxAttempts}}", backoff = @Backoff(delayExpression = "#{${service.retry.backoff.delay}}"))
  @Override
  public JsonNode addEntity(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity) {
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    try {
      Document document = new Document(InfraConstants._ID, id);
      document.append(InfraConstants.REALM_ID, realmId);
      document.append(InfraConstants.USER_ID, userId);
      document.append(index, Document.parse(inputEntity.toString()));
      mongoTemplate.getCollection(index).insertOne(document);
      return readEntity(realmId, userId, schemaInfo, id);
    } catch (Exception e) {
      log.error("Exception while persisting entity {} for type {}", inputEntity.toString(), index,
          e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_005, e, index);
    }
  }

  private List<Document> findById(@NonNull SchemaInfo schemaInfo, String id) {
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    Query query = new Query();
    if (StringUtils.isNotEmpty(id)) {
      query.addCriteria(Criteria.where(getId(schemaInfo)).is(id));
    }
    return mongoTemplate.find(query, Document.class, index);
  }

  private List<Document> findAll(@NonNull String realmId, @NonNull String userId,
      @NonNull SchemaInfo schemaInfo) {
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    Query query = new Query();
    query.addCriteria(Criteria.where(InfraConstants.REALM_ID).is(realmId));
    query.addCriteria(Criteria.where(InfraConstants.USER_ID).is(userId));
    return mongoTemplate.find(query, Document.class, index);
  }

  private String getId(SchemaInfo schemaInfo) {
    return schemaInfo.getEntityType() + InfraConstants.DOT + schemaInfo.getEntityType()
        + InfraConstants.DOT + InfraConstants.ID;
  }

  @Override
  public JsonNode readEntity(String realmId, String userId, SchemaInfo schemaInfo, String id) {
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    List<Document> document = findById(schemaInfo, id);
    if (CollectionUtils.isEmpty(document)) {
      log.error("Document not available for id: {}", id);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_007, id);
    }
    try {
      ObjectNode node = JSONUtil.OBJECT_MAPPER.readValue(document.get(document.size() - 1).toJson(),
          ObjectNode.class);
      node.remove(InfraConstants._ID);
      node.remove(InfraConstants.REALM_ID);
      node.remove(InfraConstants.USER_ID);
      return node.get(index);
    } catch (Exception e) {
      log.error("Exception while reading entity {} for type {}", id, index, e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_004, index, id, e);
    }
  }

  private List<Document> findByIdIn(@NonNull String realmId, @NonNull String userId,
      @NonNull SchemaInfo schemaInfo, Collection<String> ids) {
    Query query = new Query();
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    if (!CollectionUtils.isEmpty(ids)) {
      query.addCriteria(Criteria.where(InfraConstants._ID).in(ids));
    }
    query.addCriteria(Criteria.where(InfraConstants.REALM_ID).is(realmId));
    query.addCriteria(Criteria.where(InfraConstants.USER_ID).is(userId));
    return mongoTemplate.find(query, Document.class, index);
  }

  @Override
  public JsonNode updateEntity(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity) {
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    try {
      // Find the Doc
      List<Document> documents = findById(schemaInfo, id);
      if (CollectionUtils.isEmpty(documents)) {
        log.error("Document not available for id: {}", id);
        throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_007, id);
      }
      ObjectNode node = JSONUtil.OBJECT_MAPPER.readValue(documents.get(0).toJson(),
          ObjectNode.class);
      node.remove(InfraConstants._ID);
      node.remove(InfraConstants.REALM_ID);
      node.remove(InfraConstants.USER_ID);
      ObjectNode jsonNode = (ObjectNode) node.get(index);
      // Update only Required Fields
      inputEntity.get(index).fields().forEachRemaining(
          stringJsonNodeEntry -> ((ObjectNode) jsonNode.get(index)).put(
              stringJsonNodeEntry.getKey(), stringJsonNodeEntry.getValue()));
      // Upsert the document back
      Document document = new Document(InfraConstants._ID, id);
      document.append(InfraConstants.REALM_ID, realmId);
      document.append(InfraConstants.USER_ID, userId);
      document.append(index, Document.parse(jsonNode.toString()));
      mongoTemplate.save(document, index);
      return readEntity(realmId, userId, schemaInfo, id);
    } catch (Exception e) {
      log.error("Exception while reading entity {} for type {}", id, index, e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_004, e, index, id);
    }
  }

  @Override
  public List<String> readAll(String realmId, String userId, SchemaInfo schemaInfo) {
    String entityType = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    try {
      List<Document> documents = findAll(realmId, userId, schemaInfo);
      return documents.stream().map(document -> {
        try {
          ObjectNode node = JSONUtil.OBJECT_MAPPER.readValue(document.toJson(), ObjectNode.class);
          node.remove(InfraConstants._ID);
          return node.get(entityType).toString();
        } catch (Exception e) {
          // SWALLOW EXCEPTION AT DOCUMENT LEVEL
          log.warn("Exception while reading all entities of type:{}", entityType, e);
          return "";
        }
      }).filter(StringUtils::isNotEmpty).collect(Collectors.toList());
    } catch (Exception e) {
      log.error("Exception while reading all entities for type:{}", entityType, e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_004, e, entityType,
          "all");
    }
  }

  @Override
  public void deleteEntity(String realmId, String userId, SchemaInfo schemaInfo, String id) {
    String index = schemaInfo.getEntityType();
    try {
      List<Document> documents = findById(schemaInfo, id);
      if (CollectionUtils.isEmpty(documents)) {
        log.error("Document not available for id: {}", id);
        throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_007, id);
      }
      this.mongoTemplate.remove(documents.get(0), index);
    } catch (Exception e) {
      log.error("Exception while deleting the entity {} for type {}", id, index, e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_004, e, index, id);
    }
  }

  @Override
  public List<String> search(String realmId, String userId, SchemaInfo schemaInfo,
      Object searchQuery) {
    return Collections.emptyList();
  }

  @Override
  public JsonNode addEvent(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity) {
    String entityType = schemaInfo.getEntityType();
    schemaInfo.setEntityType(InfraConstants.EVENT);
    String schemaGroup = schemaInfo.getSchemaGroup();
    try {
      Document document = new Document(InfraConstants._ID, id);
      document.append(InfraConstants.REALM_ID, realmId);
      document.append(InfraConstants.USER_ID, userId);
      document.append(InfraConstants.EVENT, Document.parse(inputEntity.toString()));
      mongoTemplate.getCollection(InfraConstants.EVENT).insertOne(document);
      return readEntity(realmId, userId, schemaInfo, id);
    } catch (Exception e) {
      log.error("Error during event persist: {}", id, e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_008, e, entityType, id);
    }
  }

  @Override
  public JsonNode findAllByIdIn(SchemaInfo schemaInfo, List<String> ids) {
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    Query query = new Query();
    ArrayNode arrayNode = JSONUtil.OBJECT_MAPPER.createArrayNode();

    if (CollectionUtils.isNotEmpty(ids)) {
      query.addCriteria(Criteria.where(getId(schemaInfo)).in(ids));
    } else {
      return arrayNode;
    }
    List<Document> documents = mongoTemplate.find(query, Document.class, index);
    for (Document doc : documents) {
      try {
        arrayNode.add(JSONUtil.OBJECT_MAPPER.readValue(doc.toJson(), ObjectNode.class).get(index));
      } catch (JsonProcessingException jpe) {
        log.error("Unable to read entity: {}", doc.toJson());
        throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_004, index, ids);
      }
    }

    // Handle backwards compatibility
    Map<JsonNode, List<JsonNode>> groupedById = StreamSupport.stream(arrayNode.spliterator(), false)
        .collect(Collectors.groupingBy(each -> each.get(index).get(InfraConstants.ID)));
    ArrayNode result = JSONUtil.OBJECT_MAPPER.createArrayNode();
    groupedById.forEach((k, v) -> result.add(v.get(v.size() - 1)));

    return result;
  }

  public List<Document> findAllEventsByEntityId(@NonNull String realmId, @NonNull String userId,
      @NonNull SchemaInfo schemaInfo, String id) {
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    Query query = new Query();
    if (StringUtils.isNotEmpty(id)) {
      query.addCriteria(Criteria.where("Event.eventData." + index + ".id").is(id));
    }
    query.addCriteria(Criteria.where(InfraConstants.REALM_ID).is(realmId));
    query.addCriteria(Criteria.where(InfraConstants.USER_ID).is(userId));
    query.with(Sort.by(Direction.ASC, "Event.createdAt"));
    return mongoTemplate.find(query, Document.class, InfraConstants.EVENT);
  }

  public Document findLastEventByEntityId(@NonNull String realmId, @NonNull String userId,
      @NonNull SchemaInfo schemaInfo, String id) {
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    Query query = new Query();
    if (StringUtils.isNotEmpty(id)) {
      query.addCriteria(Criteria.where("Event.eventData." + index + ".id").is(id));
    }
    query.addCriteria(Criteria.where(InfraConstants.REALM_ID).is(realmId));
    query.addCriteria(Criteria.where(InfraConstants.USER_ID).is(userId));

    final Pageable pageableRequest = PageRequest.of(0, 1,
        Sort.by(Direction.DESC, "Event.createdAt"));
    query.with(pageableRequest);
    List<Document> event = mongoTemplate.find(query, Document.class, InfraConstants.EVENT);
    return CollectionUtils.isEmpty(event) ? null : event.get(0);
  }

  /**
   * Saves document into MongoDB
   *
   * @param realmId     realm id
   * @param userId      user id
   * @param schemaInfo  - schema info, schemaInfo.getEntityType() is ElasticSearch Index
   * @param id          - document id
   * @param inputEntity - input json document for adding
   * @return
   */
  @Retryable(value = {IOException.class,
      ConnectException.class}, maxAttemptsExpression = "#{${service.retry.maxAttempts}}", backoff = @Backoff(delayExpression = "#{${service.retry.backoff.delay}}"))
  @Override
  public JsonNode addEventEntity(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity, Integer version) {
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    try {
      Document document = new Document(InfraConstants._ID, id);
      document.append(InfraConstants.REALM_ID, realmId);
      document.append(InfraConstants.USER_ID, userId);
      document.append(InfraConstants.CREATED_AT, Instant.now().toEpochMilli());
      document.append(InfraConstants.UPDATED_AT, Instant.now().toEpochMilli());
      document.append(InfraConstants.VERSION, version);
      document.append(index, Document.parse(inputEntity.toString()));
      mongoTemplate.getCollection(index).insertOne(document);
      return readEntity(realmId, userId, schemaInfo, id);
    } catch (Exception e) {
      log.error("Exception while persisting entity {} for type {}", inputEntity.toString(), index,
          e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_008, e, index, id);
    }
  }
}

