/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.model;

import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Workflow Event.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class WorkflowEvent {

  private String realmId;
  private Integer userId;
  private String eventName;
  private Map<String, Object> requestBody;
  private int retryNumber;
}
