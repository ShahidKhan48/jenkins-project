/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.model;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Audit Field informations
 * <p>
 * System Fields
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SystemFieldDetails {

  /**
   * Event Created Timestamp
   * <p>
   */
  @JsonProperty("createdAt")
  private String createdAt;
  /**
   * Created by UserId
   * <p>
   */
  @JsonProperty("createdBy")
  private Integer createdBy;
  @JsonIgnore
  private Map<String, String> additionalProperties = new HashMap<String, String>();

  /**
   * Event Created Timestamp
   * <p>
   */
  @JsonProperty("createdAt")
  public String getCreatedAt() {
    return createdAt;
  }

  /**
   * Event Created Timestamp
   * <p>
   */
  @JsonProperty("createdAt")
  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * Created by UserId
   * <p>
   */
  @JsonProperty("createdBy")
  public Integer getCreatedBy() {
    return createdBy;
  }

  /**
   * Created by UserId
   * <p>
   */
  @JsonProperty("createdBy")
  public void setCreatedBy(Integer createdBy) {
    this.createdBy = createdBy;
  }

  @JsonAnyGetter
  public Map<String, String> getAdditionalProperties() {
    return this.additionalProperties;
  }

  @JsonAnySetter
  public void setAdditionalProperty(String name, String value) {
    this.additionalProperties.put(name, value);
  }

}

