/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.persistence;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.ninjacart.dms.dam.config.ElasticSearchClientConfig;
import com.ninjacart.dms.dam.constants.CoreConstants;
import com.ninjacart.dms.dam.constants.InfraConstants;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.DefinitionsManager;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models.SchemaInfo;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.helper.ESUtils;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.Operator;
import com.ninjacart.dms.dam.domain.assetmanagement.model.Filter;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.exception.DAMRuntimeException;
import com.ninjacart.dms.dam.exception.DAMServiceErrorCode;
import com.ninjacart.dms.dam.utils.JSONUtil;
import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.DocWriteResponse.Result;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.common.ParsingException;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchModule;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.SortOrder;
import org.elasticsearch.xcontent.DeprecationHandler;
import org.elasticsearch.xcontent.NamedXContentRegistry;
import org.elasticsearch.xcontent.XContentFactory;
import org.elasticsearch.xcontent.XContentParser;
import org.elasticsearch.xcontent.XContentType;
import org.springframework.util.CollectionUtils;

/**
 * Implementation for Elastic Search as persistence unit.
 */
@RequiredArgsConstructor
@Slf4j
public class ElasticProvider implements IPersistenceProvider {

  private final DefinitionsManager definitionsManager;
  private final ElasticSearchClientConfig esClientConfig;
  private final Map<String, Set<String>> indexWiseExcludeFields;

  @PostConstruct
  private void initializeElasticProvider() {
    definitionsManager.getAllKnownSchemaInfo().iterator().forEachRemaining(schemaInfo -> {
      try {
        addIndex(esClientConfig, schemaInfo.getEntityType().toLowerCase());
      } catch (IOException e) {
        log.error("Error during ES index creation: {}", schemaInfo.getEntityType());
        throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_011, e,
            schemaInfo.getEntityType());
      }
    });
  }

  private boolean addIndex(ElasticSearchClientConfig elasticSearchClientConfig, String indexName)
      throws IOException {
    boolean response = false;
    RestHighLevelClient client = elasticSearchClientConfig.getEsClient();
    if (!isIndexExists(elasticSearchClientConfig, indexName)) {
      CreateIndexRequest createIndexRequest = new CreateIndexRequest(indexName);
      CreateIndexResponse createIndexResponse = client.indices()
          .create(createIndexRequest, RequestOptions.DEFAULT);
      response = createIndexResponse.isAcknowledged();
    }
    return response;
  }

  private boolean isIndexExists(ElasticSearchClientConfig elasticSearchClientConfig,
      String indexName) {
    Response response;
    try {
      response = elasticSearchClientConfig.getEsClient().getLowLevelClient()
          .performRequest(new Request("HEAD", "/" + indexName));
      return (200 == response.getStatusLine().getStatusCode());
    } catch (IOException e) {
      return false;
    }
  }

  @Override
  public JsonNode addEntity(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity) {
    IndexResponse response;
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    try {
      DocumentContext doc = getDocumentContextAfterRemovingExcludedFields(index, inputEntity);
      JsonNode filteredNode = JSONUtil.convertStringJsonNode(doc.jsonString());
      Map<String, Object> inputMap = JSONUtil.convertJsonNodeToMap(filteredNode);
      inputMap.putIfAbsent(InfraConstants.REALM_ID, realmId);
      inputMap.putIfAbsent(InfraConstants.USER_ID, userId);
      response = esClientConfig.getEsClient()
          .index(new IndexRequest(index.toLowerCase()).id(id).source(inputMap),
              RequestOptions.DEFAULT);
      if (response.getResult() != DocWriteResponse.Result.CREATED) {
        log.warn("Record Not Created");
      }
      return JSONUtil.OBJECT_MAPPER.readValue(esClientConfig.getEsClient()
          .get(new GetRequest(index.toLowerCase(), esClientConfig.getSearchType(), id),
              RequestOptions.DEFAULT).getSourceAsString(), JsonNode.class);
    } catch (IOException e) {
      log.error("Error during ES index creation: {}", schemaInfo.getEntityType());
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_012, e,
          schemaInfo.getEntityType());
    }
  }

  @Override
  public JsonNode readEntity(String realmId, String userId, SchemaInfo schemaInfo, String id) {
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    List<Filter> filters = filters(realmId, userId, schemaInfo);
    filters.add(
        Filter.builder().path(index).operator(Operator.eq).property(InfraConstants.ID).value(id)
            .build());
    SearchQuery searchQuery = SearchQuery.builder().limit(1).filters(filters).build();
    ArrayNode nodes = searchInternal(realmId, userId, schemaInfo, searchQuery);
    if (nodes.size() > 0) {
      ObjectNode node = (ObjectNode) nodes.get(0);
      node.remove(InfraConstants.REALM_ID);
      node.remove(InfraConstants.USER_ID);
      return node;
    } else {
      log.error("No documents available for Id(s): {}", id);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_007, id);
    }
  }

  private List<Filter> filters(String realmId, String userId, SchemaInfo schemaGroup) {
    return filters(realmId, userId, schemaGroup, null);
  }

  private List<Filter> filters(String realmId, String userId, SchemaInfo schemaInfo, String id) {
    List<Filter> filters = new ArrayList<>();
    // Add RealmId Filter
    filters.add(
        Filter.builder().operator(Operator.eq).property(InfraConstants.REALM_ID).value(realmId)
            .build());
    // Add UserId Filter
    filters.add(
        Filter.builder().operator(Operator.eq).property(InfraConstants.USER_ID).value(userId)
            .build());
    // Id filter
    if (StringUtils.isNotBlank(id)) {
      filters.add(Filter.builder().path(schemaInfo.getEntityType()).operator(Operator.eq)
          .property(InfraConstants.ID + "." + CoreConstants.KEYWORD).value(id).build());
    }
    return filters;
  }

  @Override
  public JsonNode updateEntity(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity) {
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    log.debug("updateEntity starts with index {} and entityId {}", index, id);
    UpdateResponse response;
    try {
      DocumentContext doc = getDocumentContextAfterRemovingExcludedFields(index, inputEntity);
      JsonNode filteredNode = JSONUtil.convertStringJsonNode(doc.jsonString());
      Map<String, Object> inputMap = JSONUtil.convertJsonNodeToMap(filteredNode);
      inputMap.putIfAbsent(InfraConstants.REALM_ID, realmId);
      inputMap.putIfAbsent(InfraConstants.USER_ID, userId);
      log.debug("updateEntity inputMap {}", inputMap);
      log.debug("updateEntity inputEntity {}", inputEntity);
      response = esClientConfig.getEsClient()
          .update(new UpdateRequest(index.toLowerCase(), id).doc(inputMap), RequestOptions.DEFAULT);
      if (response.getResult() != DocWriteResponse.Result.UPDATED) {
        log.warn("Record Not Updated");
      }
      return inputEntity;
    } catch (IOException e) {
      log.error("Exception in updating a record to ElasticSearch", e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_012, e,
          schemaInfo.getEntityType());
    }
  }

  @Override
  public void deleteEntity(String realmId, String userId, SchemaInfo schemaInfo, String id) {
    DeleteResponse response;
    String index = schemaInfo.getEntityType();
    try {
      String indexL = index.toLowerCase();
      response = esClientConfig.getEsClient()
          .delete(new DeleteRequest(indexL, id), RequestOptions.DEFAULT);
      if (response.getResult() != DocWriteResponse.Result.DELETED) {
        log.warn("Record Not Deleted");
      }
    } catch (NullPointerException | IOException e) {
      log.error("exception in delete Entity: {}", id, e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_012, e,
          schemaInfo.getEntityType());
    }
  }

  @Override
  public List<String> search(String realmId, String userId, SchemaInfo schemaInfo,
      Object searchQueryObj) throws IOException {
    QueryBuilder query;
    SearchSourceBuilder sourceBuilder;
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    if (searchQueryObj instanceof SearchQuery searchQuery) {
      List<Filter> defaultFilters =
          Objects.nonNull(searchQuery.getGlobalSearch()) && searchQuery.getGlobalSearch()
              ? new ArrayList<>() : filters(realmId, userId, schemaInfo);
      defaultFilters.addAll(
          Optional.ofNullable(searchQuery.getFilters()).orElse(Collections.emptyList()));
      searchQuery.setFilters(defaultFilters);
      query = ESUtils.buildQuery(searchQuery);
      sourceBuilder = new SearchSourceBuilder().query(query).size(searchQuery.getLimit())
          .from(searchQuery.getOffset()).fetchSource(InfraConstants._ID, null).fetchSource(false);
      if (Objects.nonNull(searchQuery.getSort())) {
        sourceBuilder.sort(searchQuery.getSort(), SortOrder.valueOf(searchQuery.getSortOrder()));
      }
    } else {
      SearchModule searchModule = new SearchModule(Settings.EMPTY, false, Collections.emptyList());
      try {
        sourceBuilder = new SearchSourceBuilder();
        try (XContentParser parser = XContentFactory.xContent(XContentType.JSON)
            .createParser(new NamedXContentRegistry(searchModule.getNamedXContents()),
                DeprecationHandler.THROW_UNSUPPORTED_OPERATION, (String) searchQueryObj)) {
          sourceBuilder.parseXContent(parser);
        }
      } catch (IOException | ParsingException e) {
        log.error("Invalid query: " + searchQueryObj + ": " + e.getMessage(), e);
        throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_014, e,
            schemaInfo.getEntityType());
      }
    }
    SearchRequest searchRequest = new SearchRequest(index.toLowerCase()).source(sourceBuilder);
    List<String> resultArray = new ArrayList<>();
    SearchResponse searchResponse = esClientConfig.getEsClient()
        .search(searchRequest, RequestOptions.DEFAULT);
    for (SearchHit hit : searchResponse.getHits()) {
      if (Objects.nonNull(hit.getId())) {
        resultArray.add(hit.getId());
      }
    }
    log.info("Total search records found " + resultArray.size());
    return resultArray;
  }

  @Override
  public List<String> readAll(String realmId, String userId, SchemaInfo schemaInfo) {
    try {
      String entityType = schemaInfo.getEntityType();
      String schemaGroup = schemaInfo.getSchemaGroup();
      List<Filter> filters = filters(realmId, userId, schemaInfo);
      SearchQuery searchQuery = SearchQuery.builder().limit(100).filters(filters).build();
      BoolQueryBuilder query = ESUtils.buildQuery(searchQuery);
      SearchSourceBuilder sourceBuilder = new SearchSourceBuilder().query(query)
          .size(searchQuery.getLimit()).from(searchQuery.getOffset());
      SearchResponse response = esClientConfig.getEsClient()
          .search(new SearchRequest(entityType.toLowerCase()).source(sourceBuilder),
              RequestOptions.DEFAULT);
      SearchHit[] hits = response.getHits().getHits();
      return Arrays.stream(hits).map(documentFields -> documentFields.getSourceAsString())
          .collect(Collectors.toList());
    } catch (Exception e) {
      log.error("Exception while fetching all docs: {}", schemaInfo.getEntityType(), e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_015, e,
          schemaInfo.getEntityType());
    }
  }

  @Override
  public JsonNode addEvent(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity) {
    return null;
  }

  @Override
  public JsonNode findAllByIdIn(SchemaInfo schemaInfo, List<String> id) {
    return null;
  }

  @Override
  public Document findLastEventByEntityId(String realmId, String userId, SchemaInfo schemaInfo,
      String id) {
    return null;
  }

  private DocumentContext getDocumentContextAfterRemovingExcludedFields(String index,
      JsonNode inputEntity) throws com.fasterxml.jackson.core.JsonProcessingException {
    DocumentContext doc = JsonPath.parse(JSONUtil.convertObjectJsonString(inputEntity));
    Set<String> excludedFields = indexWiseExcludeFields.get(index.toLowerCase());
    if (!CollectionUtils.isEmpty(excludedFields)) {
      for (String jsonPath : excludedFields) {
        try {
          doc.delete(jsonPath);
        } catch (Exception e) {
          // SWALLOWING EXCEPTION AS IT IS NOT A BLOCKING EVENT
          log.error("Path not found {} {}", jsonPath, e.getMessage());
        }
      }
    }
    return doc;
  }

  @Override
  public Optional<ObjectNode> readLastEvent(String realmId, String userId, SchemaInfo schemaInfo,
      String id) throws IOException {
    String schemaGroup = schemaInfo.getSchemaGroup();
    List<Filter> filters = filters(realmId, userId, schemaInfo, id);
    SearchQuery searchQuery = SearchQuery.builder().limit(1).filters(filters).build();
    ArrayNode nodes = searchInternal(realmId, userId, schemaInfo, searchQuery);
    if (nodes.size() > 0) {
      ObjectNode node = (ObjectNode) nodes.get(0);
      node.remove(InfraConstants.REALM_ID);
      node.remove(InfraConstants.USER_ID);
      return Optional.of(node);
    }
    return Optional.empty();
  }

  /**
   * Saves the latest entry of the event source into ES(ElasticSearch)
   *
   * @param realmId     realm id
   * @param userId      user id
   * @param schemaInfo  - schema info, schemaInfo.getEntityType() is ElasticSearch Index
   * @param id          - document id
   * @param inputEntity - input json document for adding
   * @return
   */
  @Override
  public JsonNode addEventEntity(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity, Integer version) {
    IndexResponse response;
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    try {
      DocumentContext doc = getDocumentContextAfterRemovingExcludedFields(index, inputEntity);
      JsonNode filteredNode = JSONUtil.convertStringJsonNode(doc.jsonString());
      Map<String, Object> inputMap = JSONUtil.convertJsonNodeToMap(filteredNode);
      inputMap.putIfAbsent(InfraConstants.REALM_ID, realmId);
      inputMap.putIfAbsent(InfraConstants.USER_ID, userId);
      inputMap.putIfAbsent(InfraConstants.CREATED_AT, Instant.now().toEpochMilli());
      inputMap.putIfAbsent(InfraConstants.UPDATED_AT, Instant.now().toEpochMilli());
      inputMap.putIfAbsent(InfraConstants.VERSION, version);
      response = esClientConfig.getEsClient()
          .index(new IndexRequest(index.toLowerCase()).id(id).source(inputMap),
              RequestOptions.DEFAULT);
      if (response.getResult() != DocWriteResponse.Result.CREATED) {
        log.warn("Record Not Created");
      }
      return JSONUtil.OBJECT_MAPPER.convertValue(esClientConfig.getEsClient()
          .get(new GetRequest(index.toLowerCase(), esClientConfig.getSearchType(), id),
              RequestOptions.DEFAULT).getSourceAsString(), ObjectNode.class);
    } catch (IOException e) {
      log.error("Exception in adding record to ElasticSearch", e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_012, e,
          schemaInfo.getEntityType());
    }
  }

  @Override
  public Optional<ObjectNode> searchByUniqueFields(String realmId, String userId,
      SchemaInfo schemaInfo, JsonNode inputJson, List<String> uniqueFields) {
    try {
      SearchQuery searchQuery = SearchQuery.builder().offset(0).limit(1)
          .entityTypes(List.of(schemaInfo.getEntityType())).build();
      List<Filter> filters = new ArrayList<>();
      boolean uniqueValuePresent = false;
      for (String s : uniqueFields) {
        Filter filter = Filter.builder().build();
        filter.setPath(schemaInfo.getEntityType());
        filter.setOperator(Operator.eq);
        filter.setProperty(s);
        JsonNode uniqueValueNode = inputJson.get(schemaInfo.getEntityType()).get(s);
        if (Objects.nonNull(uniqueValueNode) && !uniqueValueNode.asText().isEmpty()) {
          uniqueValuePresent = true;
        } else {
          continue;
        }
        filter.setValue(uniqueValueNode.asText());
        filters.add(filter);
      }
      if (!uniqueValuePresent) {
        return Optional.empty();
      }
      searchQuery.setFilters(filters);
      ArrayNode nodes = searchInternal(realmId, userId, schemaInfo, searchQuery);
      if (Objects.nonNull(nodes) && nodes.size() > 0) {
        ObjectNode node = (ObjectNode) nodes.get(0);
        return Optional.of(node);
      }
    } catch (Exception e) {
      log.warn("Exception while searching for unique values:", e);
      // Swallowing the exception
    }
    return Optional.empty();
  }

  private ArrayNode searchInternal(String realmId, String userId, SchemaInfo schemaInfo,
      SearchQuery searchQuery) {
    QueryBuilder query;
    SearchSourceBuilder sourceBuilder;
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();

    List<Filter> defaultFilters =
        Objects.nonNull(searchQuery.getGlobalSearch()) && searchQuery.getGlobalSearch()
            ? new ArrayList<>() : filters(realmId, userId, schemaInfo);
    defaultFilters.addAll(searchQuery.getFilters());
    searchQuery.setFilters(defaultFilters);
    query = ESUtils.buildQuery(searchQuery);
    sourceBuilder = new SearchSourceBuilder().query(query).size(searchQuery.getLimit())
        .from(searchQuery.getOffset());
    if (Objects.nonNull(searchQuery.getSort())) {
      sourceBuilder.sort(searchQuery.getSort(), SortOrder.valueOf(searchQuery.getSortOrder()));
    }

    SearchRequest searchRequest = new SearchRequest(index.toLowerCase()).source(sourceBuilder);
    ArrayNode resultArray = JSONUtil.OBJECT_MAPPER.createArrayNode();
    try {
      SearchResponse searchResponse = esClientConfig.getEsClient()
          .search(searchRequest, RequestOptions.DEFAULT);
      for (SearchHit hit : searchResponse.getHits()) {
        JsonNode node = JSONUtil.OBJECT_MAPPER.readValue(hit.getSourceAsString(), JsonNode.class);
        if (Objects.isNull(node.get(InfraConstants._STATUS)) || node.get(InfraConstants._STATUS)
            .asBoolean()) {
          resultArray.add(node);
        }
      }
    } catch (IOException e) {
      log.error("Error during search: {}", searchRequest);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_004, index, schemaGroup);
    }
    log.info("Total search records found " + resultArray.size());
    return resultArray;
  }

  /**
   * Updates the latest entry of the event source into ES(ElasticSearch) with respect to input osid
   *
   * @param realmId     realm id
   * @param userId      user id
   * @param schemaInfo  - schema info, schemaInfo.getEntityType() is ElasticSearch Index
   * @param inputEntity - input json document for updating
   * @param id          - which maps to document
   * @return
   */
  @Override
  public String updateEventEntity(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity, int newVersion) {
    String index = schemaInfo.getEntityType();
    String schemaGroup = schemaInfo.getSchemaGroup();
    log.debug("updateEntity starts with index {} and entityId {}", index, id);
    IndexResponse response;
    try {
      DocumentContext doc = getDocumentContextAfterRemovingExcludedFields(index, inputEntity);
      JsonNode filteredNode = JSONUtil.convertStringJsonNode(doc.jsonString());
      Map<String, Object> inputMap = JSONUtil.convertJsonNodeToMap(filteredNode);
      inputMap.putIfAbsent(InfraConstants.REALM_ID, realmId);
      inputMap.putIfAbsent(InfraConstants.USER_ID, userId);
      inputMap.putIfAbsent(InfraConstants.UPDATED_AT, Instant.now().toEpochMilli());
      inputMap.putIfAbsent(InfraConstants.VERSION, newVersion);

      log.debug("updateEntity inputMap {}", inputMap);
      log.debug("updateEntity inputEntity {}", inputEntity);
      response = esClientConfig.getEsClient()
          .index(new IndexRequest(index.toLowerCase()).id(id).source(inputMap),
              RequestOptions.DEFAULT);
      if (response.getResult() != DocWriteResponse.Result.CREATED
          || response.getResult() != Result.UPDATED) {
        log.warn("Record Not Updated");
      }
      return esClientConfig.getEsClient()
          .get(new GetRequest(index.toLowerCase(), esClientConfig.getSearchType(), id),
              RequestOptions.DEFAULT).getSourceAsString();
    } catch (IOException e) {
      log.error("Exception in updating a record to ElasticSearch", e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_012, e,
          schemaInfo.getEntityType());
    }
  }
}
