/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.config;

import com.ninjacart.dms.dam.config.events.EventHubConfiguration;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.daproxy.DaProxyFeignClient;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.daproxy.DaProxyWebAdapter;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.EntityStoreAdapter;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.ValidationProcessor;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.ValidationProcessorAdapter;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.DefinitionsManager;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models.Definition;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.EventNotification;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.EventProducerProvider;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.IEventNotification;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.persistence.ElasticProvider;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.persistence.IPersistenceProvider;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.persistence.MongoProvider;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.ActionsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.CollectionRequestTemplatesService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.CollectionRequestsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.DigitalAssetDefinitionsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.DigitalAssetsService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.ActionsServiceImpl;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.CollectionRequestTemplatesServiceImpl;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.CollectionRequestsServiceImpl;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.DigitalAssetDefinitionsServiceImpl;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.DigitalAssetsServiceImpl;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors.CallbackOnUpdateExecutor;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors.CollectionRequestEventsOnUpdateExecutor;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors.CollectionRequestOnUpdateExecutor;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors.DigitalAssetEventsOnUpdateExecutor;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors.DigitalAssetOnUpdateExecutor;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors.OnUpdateExecutor;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.executors.PersistenceOnUpdateExecutor;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.helper.CollectionRequestCreationHelper;
import com.ninjacart.dms.dam.domain.assetmanagement.port.in.impl.helper.DigitalAssetHelper;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.CallbackClient;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.DaProxyClient;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.EntityStore;
import com.ninjacart.dms.dam.domain.consentmanagement.port.in.ConsentsService;
import com.ninjacart.dms.dam.domain.consentmanagement.port.in.impl.ConsentsServiceImpl;
import com.ninjacart.dms.dam.domain.filemanagement.adapters.AwsS3Service;
import com.ninjacart.dms.dam.domain.filemanagement.adapters.CloudStorageFactory;
import com.ninjacart.dms.dam.domain.filemanagement.adapters.S3ClientFactory;
import com.ninjacart.dms.dam.domain.filemanagement.port.in.FileManagementService;
import com.ninjacart.dms.dam.domain.filemanagement.port.in.impl.FileManagementServiceImpl;
import com.ninjacart.dms.dam.domain.filemanagement.port.out.CloudStorageProviderFactory;
import com.ninjacart.dms.dam.domain.filemanagement.port.out.CloudStorageService;
import com.ninjacart.dms.dam.exception.DAMException;
import com.ninjacart.dms.dam.exception.DAMServiceErrorCode;
import com.ninjacart.platform.commons.error.exceptions.NinjaExceptionHandler;
import io.apicurio.registry.rest.client.RegistryClient;
import io.apicurio.registry.rest.client.RegistryClientFactory;
import io.apicurio.rest.client.auth.Auth;
import io.apicurio.rest.client.auth.BasicAuth;
import io.micrometer.core.instrument.MeterRegistry;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.data.mongodb.core.MongoTemplate;

/**
 * Infra Module Beans and Configurations class.
 */
@Configuration
@Slf4j
@EnableFeignClients(basePackages = {"com.ninjacart"})
public class InfraBeanConfig {

  /// APPLICATION - START

  @Bean
  public NinjaExceptionHandler ninjaExceptionHandler(MeterRegistry meterRegistry) {
    return new NinjaExceptionHandler(meterRegistry);
  }

  /// APPLICATION - END

  /// INCOMING - PORTS - START

  @Bean
  public CollectionRequestTemplatesService collectionRequestTemplateService(
      EntityStore entityStore) {
    return new CollectionRequestTemplatesServiceImpl(entityStore);
  }

  @Bean
  public DigitalAssetDefinitionsService digitalAssetDefinitionsService(EntityStore entityStore) {
    return new DigitalAssetDefinitionsServiceImpl(entityStore);
  }

  @Bean
  public DigitalAssetsService digitalAssetsService(EntityStore entityStore,
      FileManagementService fileManagementService) {
    return new DigitalAssetsServiceImpl(entityStore, fileManagementService);
  }

  @Bean
  public DigitalAssetHelper digitalAssetHelper(List<OnUpdateExecutor> onUpdateExecutors,
      DigitalAssetsService digitalAssetsService,
      CollectionRequestsService collectionRequestsService) {
    return new DigitalAssetHelper(onUpdateExecutors, digitalAssetsService,
        collectionRequestsService);
  }

  @Bean
  public CollectionRequestCreationHelper collectionRequestCreationHelper(
      DigitalAssetsService digitalAssetsService) {
    return new CollectionRequestCreationHelper(digitalAssetsService);
  }

  @Bean
  public CollectionRequestsService collectionRequestsService(EntityStore entityStore,
      CollectionRequestCreationHelper collectionRequestCreationHelper) {
    return new CollectionRequestsServiceImpl(entityStore, collectionRequestCreationHelper);
  }

  @Bean
  public ActionsService actionsService(DigitalAssetsService digitalAssetsService,
      CollectionRequestsService collectionRequestsService, DaProxyClient daProxyClient,
      DigitalAssetHelper digitalAssetHelper,
      CollectionRequestCreationHelper collectionRequestCreationHelper) {
    return new ActionsServiceImpl(digitalAssetsService, collectionRequestsService, daProxyClient,
        digitalAssetHelper, collectionRequestCreationHelper);
  }

  @Bean
  public FileManagementService fileManagementService(
      CloudStorageProviderFactory cloudStorageProviderFactory) {
    return new FileManagementServiceImpl(cloudStorageProviderFactory);
  }

  @Bean
  public ConsentsService consentsService(EntityStore entityStore) {
    return new ConsentsServiceImpl(entityStore);
  }

  @Bean
  @Order(1)
  public OnUpdateExecutor digitalAssetOnUpdateExecutor() {
    return new DigitalAssetOnUpdateExecutor();
  }

  @Bean
  @Order(2)
  public OnUpdateExecutor collectionRequestOnUpdateExecutor() {
    return new CollectionRequestOnUpdateExecutor();
  }

  @Bean
  @Order(3)
  public OnUpdateExecutor persistanceOnUpdateExecutor(DigitalAssetsService digitalAssetsService,
      CollectionRequestsService collectionRequestsService) {
    return new PersistenceOnUpdateExecutor(digitalAssetsService, collectionRequestsService);
  }

  @Bean
  @Order(4)
  public OnUpdateExecutor digitalAssetEventsOnUpdateExecutor(CallbackClient callbackClient) {
    return new DigitalAssetEventsOnUpdateExecutor(callbackClient);
  }

  @Bean
  @Order(5)
  public OnUpdateExecutor collectionRequestEventsOnUpdateExecutor(CallbackClient callbackClient) {
    return new CollectionRequestEventsOnUpdateExecutor(callbackClient);
  }

  @Bean
  @Order(6)
  public OnUpdateExecutor callbackOnUpdateExecutor(CallbackClient callbackClient) {
    return new CallbackOnUpdateExecutor(callbackClient);
  }

  /// INCOMING - PORTS - END

  /// OUTGOING - PORTS - ENTITY - START

  @Bean
  public RegistryClient registryRestClient(SchemaRegistryConfig schemaRegistryConfig)
      throws DAMException {
    if (schemaRegistryConfig.isAuthEnabled() && validateRegistryProperties(
        schemaRegistryConfig.getConnectionUrl(), schemaRegistryConfig.getUserName(),
        schemaRegistryConfig.getPassword())) {
      Auth auth = new BasicAuth(schemaRegistryConfig.getUserName(),
          schemaRegistryConfig.getPassword());
      return RegistryClientFactory.create(schemaRegistryConfig.getConnectionUrl(),
          Collections.emptyMap(), auth);
    }
    return RegistryClientFactory.create(schemaRegistryConfig.getConnectionUrl());
  }

  private boolean validateRegistryProperties(String registryUrl, String username, String password)
      throws DAMException {
    if (StringUtils.isAnyEmpty(registryUrl, username, password)) {
      log.error("Registry properties are not properly configured.");
      throw new DAMException(DAMServiceErrorCode.DAM_SERVICE_ERROR_016,
          "Registry properties are not properly configured.");
    }
    return true;
  }

  @Bean
  public DefinitionsManager definitionsManager(RegistryClient registryClient,
      SchemaRegistryConfig schemaRegistryConfiguration) {
    return new DefinitionsManager(schemaRegistryConfiguration.getGroups(), registryClient);
  }

  @Bean
  public ValidationProcessor validationProcessor(DefinitionsManager definitionsManager,
      SchemaRegistryConfig schemaRegistryConfig) {
    Map<String, String> definitionsMap = definitionsManager.getAllDefinitions().stream()
        .collect(Collectors.toMap(Definition::getTitle, Definition::getContent));
    return new ValidationProcessorAdapter(schemaRegistryConfig.getConnectionUrl(), definitionsMap);
  }

  @Bean
  public IPersistenceProvider mongoProvider(DefinitionsManager definitionsManager,
      MongoTemplate mongoTemplate) {
    return new MongoProvider(definitionsManager, mongoTemplate);
  }

  @Bean
  public IPersistenceProvider elasticProvider(DefinitionsManager definitionsManager,
      ElasticSearchClientConfig elasticSearchClientConfig) {
    return new ElasticProvider(definitionsManager, elasticSearchClientConfig,
        definitionsManager.getExcludingFields());
  }

  @Bean
  public EventProducerProvider eventProducerProvider(SchemaRegistryConfig schemaRegistryConfig,
      EventHubConfiguration eventHubConfiguration) {
    return new EventProducerProvider(schemaRegistryConfig.getServiceUrl(),
        schemaRegistryConfig.getBasicAuth(), eventHubConfiguration.getClusters());
  }

  @Bean
  public IEventNotification eventNotification(EventProducerProvider eventProducerProvider,
      DefinitionsManager definitionsManager, RegistryClient registryClient) {
    return new EventNotification(eventProducerProvider, definitionsManager, registryClient);
  }

  @Bean
  public EntityStore entityStore(IPersistenceProvider mongoProvider,
      IPersistenceProvider elasticProvider, IEventNotification eventNotification,
      ValidationProcessor validationProcessor) {
    return new EntityStoreAdapter(mongoProvider, elasticProvider, validationProcessor,
        eventNotification);
  }

  /// OUTGOING - PORTS - ENTITY - END

  /// OUTGOING - PORTS - DAPROXY - START

  @Bean
  public DaProxyClient daProxyClient(DaProxyFeignClient daProxyFeignClient) {
    return new DaProxyWebAdapter(daProxyFeignClient);
  }

  /// OUTGOING - PORTS - DAPROXY - END

  /// OUTGOING - PORTS - FILE MANAGEMENT - START

  @Bean
  public S3ClientFactory s3ClientFactory(AwsS3Config awsS3Config) {
    return new S3ClientFactory(awsS3Config.getAccessKey(), awsS3Config.getSecretKey());
  }

  @Bean
  public CloudStorageService awsS3Service(AwsS3Config awsS3Config,
      S3ClientFactory s3ClientFactory) {
    return new AwsS3Service(awsS3Config.getBucket(), awsS3Config.getRegion(), s3ClientFactory);
  }

  @Bean
  public CloudStorageProviderFactory cloudStorageFactory(
      List<CloudStorageService> cloudStorageServices) {
    return new CloudStorageFactory(cloudStorageServices);
  }

  /// OUTGOING - PORTS - FILE MANAGEMENT - END
}
