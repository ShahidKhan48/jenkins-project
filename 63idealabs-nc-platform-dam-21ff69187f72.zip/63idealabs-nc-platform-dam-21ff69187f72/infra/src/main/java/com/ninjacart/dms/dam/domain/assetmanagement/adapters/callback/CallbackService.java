/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.callback;

import com.ninjacart.dms.dam.domain.assetmanagement.model.CallbackPayload;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CallbackResponse;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.CallbackClient;
import java.net.URI;
import java.util.concurrent.CompletableFuture;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;

/**
 * Callback Service.
 */
@Slf4j
@RequiredArgsConstructor
public class CallbackService implements CallbackClient {

  private final CallbackFeignClient callbackFeignClient;

  @Override
  @Async("asyncExecutor")
  public CompletableFuture<CallbackResponse> executeCallback(String url, CallbackPayload payload) {
    return CompletableFuture.completedFuture(
        callbackFeignClient.executeCallback(URI.create(url), payload));
  }
}
