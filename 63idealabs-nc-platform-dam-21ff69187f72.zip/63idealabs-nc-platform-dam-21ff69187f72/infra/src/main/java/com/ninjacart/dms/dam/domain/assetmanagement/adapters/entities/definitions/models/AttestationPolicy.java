/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * AttestationPolicy.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttestationPolicy {

  private String osid;
  /**
   * name property will be used to pick the specific attestation policy.
   */
  private String name;
  /**
   * Holds the name of the attestation property. eg. education, certificate, course.
   */
  private Object attestationProperties;
  /**
   * Holds the info of manual or automated attestation.
   */
  private AttestationType type;
  /**
   * Holds the expression to identify the attestor.
   */
  private String conditions;
  /**
   * It will be used to define the actor name.
   */
  private String attestorPlugin;
  /**
   * It will be used for signin redirection eg. consent based screens.
   */
  private String attestorSignin;
  /**
   * Credential template for an attestation.
   */
  private Object credentialTemplate;
  private String entity;
  private Date updatedAt;
  private String createdBy;
  private AttestationStatus status;
  private Map<String, Object> additionalInput;
  private List<AttestationStep> attestationSteps;
}

