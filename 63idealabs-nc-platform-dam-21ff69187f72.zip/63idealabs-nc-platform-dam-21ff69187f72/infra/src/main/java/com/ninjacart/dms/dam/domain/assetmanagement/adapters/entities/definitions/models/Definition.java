/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.ninjacart.dms.dam.constants.CoreConstants;
import com.ninjacart.dms.dam.exception.DAMRuntimeException;
import com.ninjacart.dms.dam.exception.DAMServiceErrorCode;
import com.ninjacart.dms.dam.utils.JSONUtil;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Creates Definition for a given JsonNode This accepts a schema.
 */
public class Definition {

  private static final String OSCONFIG = "_osConfig";
  private static final String DEFINITIONS = "definitions";
  private static final String PROPERTIES = "properties";
  private static final String REF = "$ref";
  private static final String TYPE = "type";
  private static final Logger logger = LoggerFactory.getLogger(Definition.class);
  private final String content;
  private final String title;

  private final Map<String, String> subSchemaNames = new HashMap<>();

  private final Map<SchemaInfo, String> subSchemaInfo = new HashMap<>();

  private OSSchemaConfiguration osSchemaConfiguration = new OSSchemaConfiguration();

  /**
   * To parse a jsonNode of given schema type.
   *
   * @param schemaNode  node
   * @param schemaGroup group
   */
  public Definition(JsonNode schemaNode, String schemaGroup) {
    content = schemaNode.toString();
    if (!schemaNode.has(CoreConstants.TITLE)) {
      logger.error("{} not found for schema: {}", CoreConstants.TITLE, schemaNode);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_001, CoreConstants.TITLE,
          schemaNode);
    }
    title = schemaNode.get(CoreConstants.TITLE).asText();

    JsonNode configJson = schemaNode.get(OSCONFIG);
    if (null != configJson) {
      try {
        osSchemaConfiguration = JSONUtil.OBJECT_MAPPER.treeToValue(configJson, OSSchemaConfiguration.class);
      } catch (JsonProcessingException e) {
        // SWALLOWING EXCEPTION - OS CONFIG IS NOT MANDATORY
        logger.error("Error processing {} JSON: ", OSCONFIG, e);
        logger.debug(title + " does not have OS configuration.");
      }
    }

    // Iterate over all properties in the current definition
    JsonNode defnTitle = schemaNode.get(DEFINITIONS).get(title);
    JsonNode properties = null;
    if (null != defnTitle) {
      properties = defnTitle.get(PROPERTIES);
      properties.fields().forEachRemaining(field -> {
        JsonNode typeTextNode = field.getValue().get(TYPE);
        boolean isArrayType =
            Objects.nonNull(typeTextNode) && typeTextNode.asText().equals("array");

        JsonNode refTextNode = field.getValue().get(REF);
        if (isArrayType) {
          refTextNode = field.getValue().get("items").get(REF);
        }

        boolean isRefValid = isRefNode(refTextNode);
        if (isRefValid) {
          String refVal = refTextNode.asText();
          logger.debug("{}.{} is a ref field with value {}", title, field.getKey(), refVal);
          addFieldSchema(field.getKey(), refVal.substring(refVal.lastIndexOf("/") + 1));
          SchemaInfo schemaInfo = new SchemaInfo();
          schemaInfo.setEntityType(field.getKey());
          schemaInfo.setSchemaGroup(schemaGroup);
          addSchemaInfo(schemaInfo, refVal.substring(refVal.lastIndexOf("/") + 1));
        }
      });
    }
  }

  private boolean isRefNode(JsonNode refTextNode) {
    return (Objects.nonNull(refTextNode) && !refTextNode.isMissingNode() && !refTextNode.isNull());
  }

  /**
   * Holds the title for a given schema.
   *
   * @return title
   */
  public String getTitle() {
    return title;
  }

  /**
   * Holds the String representation of schema.
   *
   * @return content
   */
  public String getContent() {
    return content;
  }

  /**
   * Gets the OSSchemaConfiguration.
   *
   * @return os config
   */
  public OSSchemaConfiguration getOsSchemaConfiguration() {
    return osSchemaConfiguration;
  }

  public void addFieldSchema(String fieldName, String definitionName) {
    subSchemaNames.put(fieldName, definitionName);
  }

  public void addSchemaInfo(SchemaInfo schemaInfo, String definitionName) {
    subSchemaInfo.put(schemaInfo, definitionName);
  }

  public String getDefinitionNameForField(String name) {
    return subSchemaNames.getOrDefault(name, null);
  }

  public Map<String, String> getSubSchemaNames() {
    return subSchemaNames;
  }

  public Map<SchemaInfo, String> getSubSchemaInfo() {
    return subSchemaInfo;
  }
}

