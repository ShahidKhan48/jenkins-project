/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events;

import static com.ninjacart.dms.dam.utils.JSONUtil.OBJECT_MAPPER;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ninjacart.dms.dam.constants.InfraConstants;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.DefinitionsManager;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models.SchemaInfo;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.model.AuditEvent;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.model.WorkflowEvent;
import io.apicurio.registry.rest.client.RegistryClient;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;

/**
 * Sends Notification on event sourcing.
 */
@Slf4j
@RequiredArgsConstructor
public class EventNotification implements IEventNotification {

  private static final String ENTITY_TYPE = "entityType";
  private static final String ENTITY = "entity";
  private static final String AUDIT_EVENTS_TOPIC = "auditevents";
  private static final int AUDIT_EVENT_SCHEMA_ID = 59;
  private static final String AUDIT_EVENT_CLUSTER = "1";
  private static final String DAM_EVENTS_INPUT_TOPIC = "dam.events.input.topic";
  private static final String DAM_EVENTS_CLUSTER = "1";
  private static final String WORKFLOW_EVENT_NAME = "damEvent";
  private static final String WORKFLOW_EVENT_TOPIC = "workflow.events.p1.input.topic";
  private static final String WORKFLOW_EVENT_CLUSTER = "1";

  private final EventProducerProvider eventProducerProvider;
  private final DefinitionsManager definitionsManager;
  private final RegistryClient registryClient;

  @Override
  @Async("asyncExecutor")
  public void pushEvent(AuditEvent auditEvent) {
    try {
      ObjectNode objectNode = (ObjectNode) OBJECT_MAPPER.readTree(
          OBJECT_MAPPER.writeValueAsString(auditEvent));
      ObjectNode updatedNode = JsonNodeFactory.instance.objectNode();
      updatedNode.set("AuditEvent", objectNode);
      List<SchemaInfo> schemaInfos = definitionsManager.getAllKnownSchemaInfo().stream().filter(
          schemaInfo -> schemaInfo.getEntityType().equals(
              ((SchemaInfo) (auditEvent.getAdditionalProperties()
                  .get("schemaInfo"))).getEntityType())).toList();
      //default schema group
      String schemaGroup = "dam";
      String key = "";
      for (var entry : (auditEvent.getAdditionalProperties()).entrySet()) {
        if (entry.getKey().equals(InfraConstants.SCHEMAINFO)) {
          SchemaInfo schemaInfo = (SchemaInfo) entry.getValue();
          key = schemaInfo.getEntityType();
          //overriding default schema group
          schemaGroup = schemaInfo.getSchemaGroup();
        }
      }
      schemaGroup = schemaInfos.size() > 1 ? schemaGroup : schemaInfos.get(0).getSchemaGroup();
      long schemaId = registryClient.getArtifactMetaData(schemaGroup, key).getGlobalId();

      Optional<Future<?>> future1 = Optional.empty();
      Optional<Future<?>> future2 = Optional.empty();

      /*try {
        future1 = Optional.ofNullable(
            eventProducerProvider.sendEventWithSchema(AUDIT_EVENT_CLUSTER, AUDIT_EVENTS_TOPIC,
                auditEvent.getId(), updatedNode.toString(), String.valueOf(AUDIT_EVENT_SCHEMA_ID)));
        future2 = Optional.ofNullable(
            eventProducerProvider.sendEventWithSchema(DAM_EVENTS_CLUSTER, DAM_EVENTS_INPUT_TOPIC,
                auditEvent.getId(), auditEvent.getAdditionalProperties().get(InfraConstants.ENTITY),
                String.valueOf(schemaId)));
      } catch (Exception e) {
        log.warn("");
      }*/

      var future3 = sendWorkflowEvent(key, auditEvent);

      future1.ifPresent(f1 -> {
        try {
          f1.get();
        } catch (ExecutionException | InterruptedException e) {
          // SWALLOWING EXCEPTION AS DOWNSTREAM MIGHT STILL SUCCEED
          log.warn("Exception while pushing event to events hub: ", e);
        }
      });
      future2.ifPresent(f2 -> {
        try {
          f2.get();
        } catch (ExecutionException | InterruptedException e) {
          // SWALLOWING EXCEPTION AS DOWNSTREAM MIGHT STILL SUCCEED
          log.warn("Exception while pushing event to events hub: ", e);
        }
      });
      future3.get();
      log.info("Event Pushed to Event Hub");
    } catch (Exception e) {
      log.warn("Exception while pushing event to events hub:", e);
    }
  }

  private Future<?> sendWorkflowEvent(String key, AuditEvent auditEvent)
      throws JsonProcessingException {
    Map<String, Object> requestBody = new HashMap<>();
    requestBody.put(ENTITY_TYPE, key);
    requestBody.put(ENTITY, OBJECT_MAPPER.readValue(
        (String) auditEvent.getAdditionalProperties().get(InfraConstants.ENTITY), JsonNode.class));
    return eventProducerProvider.sendEvent(WORKFLOW_EVENT_CLUSTER, WORKFLOW_EVENT_TOPIC,
        auditEvent.getUserDetails().getUserId(),
        WorkflowEvent.builder().realmId(auditEvent.getUserDetails().getRealmId())
            .userId(Integer.valueOf(auditEvent.getUserDetails().getUserId()))
            .eventName(WORKFLOW_EVENT_NAME).requestBody(requestBody).build());
  }
}
