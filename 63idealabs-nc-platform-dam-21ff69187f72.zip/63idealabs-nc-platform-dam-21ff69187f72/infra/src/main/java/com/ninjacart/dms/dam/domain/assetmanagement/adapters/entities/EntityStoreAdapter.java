/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ninjacart.dms.dam.constants.CoreConstants;
import com.ninjacart.dms.dam.constants.InfraConstants;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.OSSystemFieldsHelper;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models.SchemaInfo;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.IEventNotification;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.model.AuditEvent;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.model.UserDetails;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.persistence.IPersistenceProvider;
import com.ninjacart.dms.dam.domain.assetmanagement.model.PlatformManagedObject;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.EntityStore;
import com.ninjacart.dms.dam.exception.DAMRuntimeException;
import com.ninjacart.dms.dam.exception.DAMServiceErrorCode;
import com.ninjacart.dms.dam.utils.JSONUtil;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.StreamSupport;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.map.HashedMap;

/**
 * Mongo + Elastic Search Adapter for Entity Store.
 */
@Slf4j
@RequiredArgsConstructor
public class EntityStoreAdapter implements EntityStore {

  private final IPersistenceProvider mongoProvider;
  private final IPersistenceProvider elasticProvider;
  private final ValidationProcessor validate;
  private final IEventNotification eventNotification;

  @Override
  public List<? extends PlatformManagedObject> search(String realmId, String userId,
      SearchQuery searchQuery, Boolean advancedSearch,
      Class<? extends PlatformManagedObject> entityName) {
    try {
      ArrayNode entitiesJson = (ArrayNode) search(realmId, userId,
          SchemaInfo.builder().entityType(entityName.getSimpleName()).build(), searchQuery,
          advancedSearch);

      return StreamSupport.stream(entitiesJson.spliterator(), false).map(
          each -> JSONUtil.OBJECT_MAPPER.convertValue(each.get(entityName.getSimpleName()),
              entityName)).toList();
    } catch (Exception e) {
      log.error("Exception while searching entity in persistence store", e);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_004,
          entityName.getSimpleName(), e.getMessage(), e);
    }
  }

  @Override
  public PlatformManagedObject create(SessionContext sessionContext, String realmId, String userId,
      PlatformManagedObject entity, Class<? extends PlatformManagedObject> entityName) {
    String entityType = entityName.getSimpleName();

    try {
      JSONUtil.OBJECT_MAPPER.findAndRegisterModules();
      JsonNode inputJson = toJsonNode(entity, entityType);
      validate.validate(entityType, JSONUtil.OBJECT_MAPPER.writeValueAsString(inputJson), true);
      log.info("Schema Validation Successful");

      final String id = getId();
      ObjectNode objectNode = (ObjectNode) inputJson;
      ((ObjectNode) objectNode.get(entityType)).put("id", id);
      OSSystemFieldsHelper.ensureAuditFields(entityType, objectNode, sessionContext,
          CoreConstants.DAM_SCHEMA_GROUP, true);

      SchemaInfo schemaInfo = SchemaInfo.builder().entityType(entityType)
          .schemaGroup(CoreConstants.DAM_SCHEMA_GROUP).build();

      // Mongo Create
      JsonNode addedEntity = mongoProvider.addEntity(realmId, userId, schemaInfo, id, inputJson);

      // ES Update Sync
      elasticProvider.addEntity(realmId, userId, schemaInfo, id, inputJson);

      // Event
      eventNotification.pushEvent(
          auditEvent(JSONUtil.OBJECT_MAPPER.writeValueAsString(addedEntity), id, realmId, userId,
              schemaInfo, "Insert"));

      return JSONUtil.OBJECT_MAPPER.convertValue(addedEntity.get(entityType), entityName);
    } catch (JsonProcessingException jpe) {
      log.error("Error during create: {}", jpe.getMessage(), jpe);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_005, entityType, jpe);
    }
  }

  @Override
  public PlatformManagedObject read(String realmId, String userId, String id,
      Class<? extends PlatformManagedObject> entityName) {
    JSONUtil.OBJECT_MAPPER.findAndRegisterModules();
    JsonNode entity = mongoProvider.readEntity(realmId, userId,
        SchemaInfo.builder().entityType(entityName.getSimpleName()).build(), id);

    return Optional.ofNullable(entity).map(
        existing -> JSONUtil.OBJECT_MAPPER.convertValue(existing.get(entityName.getSimpleName()),
            entityName)).orElse(null);
  }

  @Override
  public PlatformManagedObject update(SessionContext sessionContext, String realmId, String userId,
      String id, PlatformManagedObject entity, boolean sendEvent,
      Class<? extends PlatformManagedObject> type) {
    String entityType = type.getSimpleName();

    try {
      JsonNode entityJson = toJsonNode(entity, entityType);
      validate.validate(entityType, JSONUtil.OBJECT_MAPPER.writeValueAsString(entityJson), true);
      log.info("Schema Validation Successful");
      SchemaInfo schemaInfo = SchemaInfo.builder().schemaGroup(CoreConstants.DAM_SCHEMA_GROUP)
          .entityType(entityType).build();

      OSSystemFieldsHelper.ensureAuditFields(entityType, entityJson, sessionContext,
          CoreConstants.DAM_SCHEMA_GROUP, false);

      // Mongo Update
      JsonNode updatedEntity = mongoProvider.updateEntity(realmId, userId, schemaInfo, id,
          entityJson);
      // Sync ES update
      elasticProvider.updateEntity(realmId, userId, schemaInfo, id, entityJson);

      if (sendEvent) {
        // Event
        eventNotification.pushEvent(
            auditEvent(JSONUtil.OBJECT_MAPPER.writeValueAsString(updatedEntity), id, realmId,
                userId, schemaInfo, "Insert"));
      }

      return JSONUtil.OBJECT_MAPPER.convertValue(updatedEntity.get(entityType), type);
    } catch (JsonProcessingException jpe) {
      log.error("Error during create: {}", jpe.getMessage(), jpe);
      throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_005, entityType, jpe);
    }
  }

  @Override
  public PlatformManagedObject delete(SessionContext sessionContext, String realmId, String userId,
      String id, Class<? extends PlatformManagedObject> type) {
    String entityType = type.getSimpleName();

    SchemaInfo schemaInfo = SchemaInfo.builder().schemaGroup(CoreConstants.DAM_SCHEMA_GROUP)
        .entityType(entityType).build();

    JsonNode toBeDeletedEntity = mongoProvider.readEntity(realmId, userId, schemaInfo, id);
    mongoProvider.deleteEntity(realmId, userId, schemaInfo, id);
    elasticProvider.deleteEntity(realmId, userId, schemaInfo, id);

    return JSONUtil.OBJECT_MAPPER.convertValue(toBeDeletedEntity.get(entityType), type);
  }

  private AuditEvent auditEvent(String entity, String entityId, String realmId, String userId,
      SchemaInfo schemaInfo, String eventType) {
    Map<String, Object> additionalPropertiesMap = new HashedMap();
    additionalPropertiesMap.put(InfraConstants.SCHEMAINFO, schemaInfo);
    additionalPropertiesMap.put(InfraConstants.ENTITY, entity);
    return AuditEvent.builder().id(entityId).actionName(eventType)
        .userDetails(UserDetails.builder().userId(userId).realmId(realmId).build())
        .actionStatus(InfraConstants.COMPLETED).additionalProperties(additionalPropertiesMap)
        .build();
  }

  private JsonNode search(String realmId, String userId, SchemaInfo schemaInfo,
      SearchQuery searchQuery, Boolean advancedSearch) throws IOException {
    List<String> ids;
    if (Objects.nonNull(advancedSearch) && advancedSearch) {
      ids = elasticProvider.search(realmId, userId, schemaInfo, searchQuery.getRawQuery());
    } else {
      ids = elasticProvider.search(realmId, userId, schemaInfo, searchQuery);
    }

    return mongoProvider.findAllByIdIn(schemaInfo, ids);
  }

  public String getId() {
    return UUID.randomUUID().toString();
  }

  private <S> JsonNode toJsonNode(S input, String entityType) {
    JSONUtil.OBJECT_MAPPER.findAndRegisterModules();
    ObjectNode objectNode = JSONUtil.OBJECT_MAPPER.createObjectNode();
    objectNode.set(entityType, JSONUtil.OBJECT_MAPPER.convertValue(input, JsonNode.class));
    return JSONUtil.recursivelyRemoveEmpties(objectNode);
  }
}
