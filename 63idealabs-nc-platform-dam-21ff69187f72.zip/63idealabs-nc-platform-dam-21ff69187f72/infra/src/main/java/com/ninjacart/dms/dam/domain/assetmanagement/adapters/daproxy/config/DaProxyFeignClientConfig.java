/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.daproxy.config;

import feign.codec.ErrorDecoder;
import org.springframework.context.annotation.Bean;

/**
 * Da-Proxy Feign Client Config.
 */
public class DaProxyFeignClientConfig {

  @Bean
  public ErrorDecoder getErrorDecoder() {
    return new DaProxyFeignErrorDecoder();
  }
}
