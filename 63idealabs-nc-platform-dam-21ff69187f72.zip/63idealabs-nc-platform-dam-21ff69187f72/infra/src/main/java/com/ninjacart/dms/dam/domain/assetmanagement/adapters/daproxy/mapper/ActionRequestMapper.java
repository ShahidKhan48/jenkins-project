/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.daproxy.mapper;

import com.ninjacart.dms.dam.domain.assetmanagement.command.CollectionRequestCommand;
import com.ninjacart.dms.dam.domain.assetmanagement.command.DigitalAssetCommand;
import com.ninjacart.dms.daproxy.model.ActionRequest;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * Mapper to convert Domain ActionRequest into provider specific ActionRequest.
 */
@Mapper
public interface ActionRequestMapper {

  ActionRequestMapper INSTANCE = Mappers.getMapper(ActionRequestMapper.class);

  /**
   * Converts Domain ActionRequest into provider specific ActionRequest.
   *
   * @param digitalAssetCommand Domain ActionRequest.
   * @return provider ActionRequest
   */
  ActionRequest fromDomain(DigitalAssetCommand digitalAssetCommand, String realmId, String userId);

  /**
   * Converts Domain ActionRequest into provider specific ActionRequest.
   *
   * @param collectionRequestCommand Domain ActionRequest.
   * @return provider ActionRequest
   */
  ActionRequest fromDomain(CollectionRequestCommand collectionRequestCommand, String realmId,
      String userId);
}
