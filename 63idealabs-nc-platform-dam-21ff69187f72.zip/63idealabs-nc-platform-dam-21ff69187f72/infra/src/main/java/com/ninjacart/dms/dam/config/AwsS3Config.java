package com.ninjacart.dms.dam.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

/**
 * AWS S3 Config.
 */
@Setter
@Getter
@RefreshScope
@Configuration
@ConfigurationProperties(prefix = "infra.aws.s3")
public class AwsS3Config {

  private String region;
  private String accessKey;
  private String secretKey;
  private String bucket;
}
