package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.EnumSet;
import java.util.List;

/**
 * System fields for created, updated time and userId appended to the json node.
 */
public enum OSSystemFields {

  createdAt {
    @Override
    public void createdAt(JsonNode node, String timeStamp, String entityType) {
      ((ObjectNode) node.get(entityType)).put(createdAt.toString(), timeStamp);
    }
  },
  updatedAt {
    @Override
    public void updatedAt(JsonNode node, String timeStamp, String entityType) {
      ((ObjectNode) node.get(entityType)).put(updatedAt.toString(), timeStamp);
    }

  },
  createdByTool {
    @Override
    public void createdByTool(JsonNode node, String tool, String entityType) {
      ((ObjectNode) node.get(entityType)).put(createdByTool.toString(), tool != null ? tool : "");
    }
  },
  updatedByTool {
    @Override
    public void updatedByTool(JsonNode node, String tool, String entityType) {
      ((ObjectNode) node.get(entityType)).put(updatedByTool.toString(), tool != null ? tool : "");
    }
  },
  createdBy {
    @Override
    public void createdBy(JsonNode node, String userId, String entityType) {
      ((ObjectNode) node.get(entityType)).put(createdBy.toString(), userId != null ? userId : "");
    }
  },
  updatedBy {
    @Override
    public void updatedBy(JsonNode node, String userId, String entityType) {
      ((ObjectNode) node.get(entityType)).put(updatedBy.toString(), userId != null ? userId : "");
    }
  },
  _osState, _osClaimId, _osAttestedData, _osSignedData;

  public void createdByTool(JsonNode node, String tool, String entityType) {
  }

  public void updatedByTool(JsonNode node, String tool, String entityType) {
  }

  public void createdAt(JsonNode node, String timeStamp, String entityType) {
  }

  public void updatedAt(JsonNode node, String timeStamp, String entityType) {
  }

  public void createdBy(JsonNode node, String userId, String entityType) {
  }

  public void updatedBy(JsonNode node, String userId, String entityType) {
  }

  public static OSSystemFields getByValue(String value) {
    for (final OSSystemFields element : EnumSet.allOf(OSSystemFields.class)) {
      if (element.toString().equals(value)) {
        return element;
      }
    }
    return null;
  }

  public void setOsOwner(JsonNode node, List<String> owner) {
  }

}
