/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities;

/**
 * Validation Processor.
 */
@FunctionalInterface
public interface ValidationProcessor {

  /**
   * Validate entity with schema
   *
   * @param entityType
   * @param objString
   * @param ignoreRequiredFields
   */
  void validate(String entityType, String objString, boolean ignoreRequiredFields);
}