/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.callback.config;

import com.ninjacart.dms.dam.domain.assetmanagement.adapters.callback.CallbackFeignClient;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.callback.CallbackService;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.CallbackClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CallbackConfig {

  @Bean
  public CallbackClient callbackClient(CallbackFeignClient callbackFeignClient) {
    return new CallbackService(callbackFeignClient);
  }
}
