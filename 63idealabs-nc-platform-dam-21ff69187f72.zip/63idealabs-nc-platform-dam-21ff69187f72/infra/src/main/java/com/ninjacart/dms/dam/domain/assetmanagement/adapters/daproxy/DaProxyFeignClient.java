/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.daproxy;

import com.ninjacart.dms.dam.constants.InfraConstants;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.daproxy.config.DaProxyFeignClientConfig;
import com.ninjacart.dms.daproxy.model.ActionRequest;
import com.ninjacart.dms.daproxy.model.FetchAssetResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Rest client to make API calls to DA-Proxy.
 */
@FeignClient(name = InfraConstants.DA_PROXY_CLIENT, url = "${infra.da-proxy.base-url}", configuration = DaProxyFeignClientConfig.class)
public interface DaProxyFeignClient {

  /**
   * Makes Action API call to DA-Proxy with given params.
   *
   * @param provider      provider to be used by DA-Proxy.
   * @param operation     operation to be performed.
   * @param actionRequest request object.
   * @return fetched assets.
   */
  @RequestMapping(path = "/api/v1/providers/{provider}/actions/{operationId}", method = RequestMethod.POST)
  FetchAssetResponse process(@PathVariable(InfraConstants.PROVIDER) String provider,
      @PathVariable(InfraConstants.OPERATION_ID) String operation, ActionRequest actionRequest);
}
