/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models;


import lombok.Data;

/**
 * AttestationStep.
 */
@Data
public class AttestationStep {

  private String osid;
  private String apiURL;
  private String apiMethod;
  private String apiRequestSchema;
}
