/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Audit Event Schema.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditEvent {

  /**
   * Event Id
   * <p>
   */
  @JsonProperty("id")
  private String id;
  /**
   * Event Name
   * <p>
   * Event Name
   */
  @JsonProperty("name")
  private String name;
  /**
   * Event Type
   * <p>
   * Event Type
   */
  @JsonProperty("type")
  private String type;
  /**
   * Event Sub Type
   * <p>
   * Event Sub Type
   */
  @JsonProperty("subType")
  private String subType;
  /**
   * Event Type Code
   * <p>
   * Event Type Code - Service Start, Service Stop
   */
  @JsonProperty("eventTypeCode")
  private String eventTypeCode;
  /**
   * Event Type Code i.e. System Generated events
   * <p>
   */
  @JsonProperty("participantEventTypeCode")
  private ParticipantEventTypeCode participantEventTypeCode;
  /**
   * Originating Service Name
   * <p>
   * Audit Event Orginating Service Name
   */
  @JsonProperty("participantServiceName")
  private String participantServiceName;
  /**
   * Reporting application Host details
   * <p>
   * Audit Event Orginating Host Details i.e. Mac address
   */
  @JsonProperty("originatingHostDetails")
  private String originatingHostDetails;
  /**
   * Requestor Detail
   * <p>
   * Requestor Detail - Information gathered from HTTP Request Headers
   */
  @JsonProperty("requestorDetails")
  private String requestorDetails;
  /**
   * Audit Action Name
   * <p>
   * Audit Action Name
   */
  @JsonProperty("actionName")
  private String actionName;
  /**
   * Audit Action Code
   * <p>
   * Audit Action Code - Create, Update, Delete, Read, Execute etc.
   */
  @JsonProperty("actionCode")
  private ActionCode actionCode;
  /**
   * Audit Action Status
   * <p>
   * Action Status - Used for Claim and Policy to track status
   */
  @JsonProperty("actionStatus")
  private String actionStatus;
  /**
   * Indicates whether the event succeeded or failed
   * <p>
   * 0=Success 4=Minor failure 8=Serious Failure 12=Major Failure
   */
  @JsonProperty("eventOutcomeIndicator")
  private EventOutcomeIndicator eventOutcomeIndicator;
  /**
   * Event Description
   * <p>
   * Event Description
   */
  @JsonProperty("description")
  private String description;
  /**
   * External Event Id
   * <p>
   */
  @JsonProperty("externalId")
  private String externalId;
  /**
   * Provider Id
   * <p>
   */
  @JsonProperty("providerId")
  private Integer providerId;
  /**
   * Claim Policy/Contract Id Reference
   * <p>
   */
  @JsonProperty("policyId")
  private Integer policyId;
  /**
   * Contract Id
   * <p>
   */
  @JsonProperty("contractId")
  private Integer contractId;
  /**
   * Insuree Id (Asgard User Id)
   * <p>
   */
  @JsonProperty("insureeId")
  private String insureeId;
  /**
   * Free Flow Entity created for Current Claim
   * <p>
   */
  @JsonProperty("freeFlowEntityId")
  private Integer freeFlowEntityId;
  /**
   * Source System Details
   * <p>
   * Source Details
   */
  @JsonProperty("sourceDetails")
  @JsonPropertyDescription("Source Details")
  private SourceDetails sourceDetails;
  /**
   * User System Details
   * <p>
   * User Details
   */
  @JsonProperty("userDetails")
  @JsonPropertyDescription("User Details")
  private UserDetails userDetails;
  /**
   * Additional Detail
   * <p>
   */
  @JsonProperty("additionalDetails")
  private List<AdditionalDetail> additionalDetails = null;
  /**
   * Audit Field informations
   * <p>
   * System Fields
   */
  @JsonProperty("systemFields")
  @JsonPropertyDescription("System Fields")
  private SystemFieldDetails systemFields;
  @JsonIgnore
  private Map<String, Object> additionalProperties = new HashMap<String, Object>();

  /**
   * Audit Action Code
   * <p>
   * Audit Action Code - Create, Update, Delete, Read, Execute etc.
   */
  public enum ActionCode {

    C("C"), R("R"), U("U"), D("D"), E("E");
    private final static Map<String, ActionCode> CONSTANTS = new HashMap<String, ActionCode>();

    static {
      for (ActionCode c : values()) {
        CONSTANTS.put(c.value, c);
      }
    }

    private final String value;

    ActionCode(String value) {
      this.value = value;
    }

    @JsonCreator
    public static ActionCode fromValue(String value) {
      ActionCode constant = CONSTANTS.get(value);
      if (Objects.isNull(constant)) {
        throw new IllegalArgumentException(value);
      } else {
        return constant;
      }
    }

    @Override
    public String toString() {
      return this.value;
    }

    @JsonValue
    public String value() {
      return this.value;
    }

  }


  /**
   * Indicates whether the event succeeded or failed
   * <p>
   * 0=Success 4=Minor failure 8=Serious Failure 12=Major Failure
   */
  public enum EventOutcomeIndicator {

    _0("0"), _4("4"), _8("8"), _12("12");
    private final static Map<String, EventOutcomeIndicator> CONSTANTS = new HashMap<String, EventOutcomeIndicator>();

    static {
      for (EventOutcomeIndicator c : values()) {
        CONSTANTS.put(c.value, c);
      }
    }

    private final String value;

    EventOutcomeIndicator(String value) {
      this.value = value;
    }

    @JsonCreator
    public static EventOutcomeIndicator fromValue(String value) {
      EventOutcomeIndicator constant = CONSTANTS.get(value);
      if (Objects.isNull(constant)) {
        throw new IllegalArgumentException(value);
      } else {
        return constant;
      }
    }

    @Override
    public String toString() {
      return this.value;
    }

    @JsonValue
    public String value() {
      return this.value;
    }

  }

  /**
   * Event Type Code i.e. System Generated events
   * <p>
   */
  public enum ParticipantEventTypeCode {

    SYSTEM("System"), APPLICATION("Application"), TOOLS("Tools");
    private final static Map<String, ParticipantEventTypeCode> CONSTANTS = new HashMap<String, ParticipantEventTypeCode>();

    static {
      for (ParticipantEventTypeCode c : values()) {
        CONSTANTS.put(c.value, c);
      }
    }

    private final String value;

    ParticipantEventTypeCode(String value) {
      this.value = value;
    }

    @JsonCreator
    public static ParticipantEventTypeCode fromValue(String value) {
      ParticipantEventTypeCode constant = CONSTANTS.get(value);
      if (Objects.isNull(constant)) {
        throw new IllegalArgumentException(value);
      } else {
        return constant;
      }
    }

    @Override
    public String toString() {
      return this.value;
    }

    @JsonValue
    public String value() {
      return this.value;
    }

  }

}

