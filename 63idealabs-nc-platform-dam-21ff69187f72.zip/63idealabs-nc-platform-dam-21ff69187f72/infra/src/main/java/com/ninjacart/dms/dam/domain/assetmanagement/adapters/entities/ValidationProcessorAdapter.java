/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities;

import com.ninjacart.dms.dam.exception.DAMRuntimeException;
import com.ninjacart.dms.dam.exception.DAMServiceErrorCode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;

/**
 * Validation Processor Adapter.
 */
@RequiredArgsConstructor
@Slf4j
public class ValidationProcessorAdapter implements ValidationProcessor {

  private static final String REQUIRED_KEYWORD = "required";
  private final String schemaUrl;
  private final Map<String, String> definitionMap;
  private final Map<String, Schema> entitySchemaMap = new HashMap<>();

  private Schema getEntitySchema(String entityType) {
    if (entitySchemaMap.containsKey(entityType)) {
      return entitySchemaMap.get(entityType);
    } else {
      Schema schema;
      try {
        String definitionContent = definitionMap.get(entityType);
        if (Objects.nonNull(definitionContent)) {
          JSONObject rawSchema = new JSONObject(definitionContent);
          SchemaLoader schemaLoader = SchemaLoader.builder().schemaJson(rawSchema).draftV7Support()
              .resolutionScope(schemaUrl).build();
          schema = schemaLoader.load().build();
          entitySchemaMap.put(entityType, schema);
        } else {
          return null;
        }
      } catch (Exception ioe) {
        log.error("Error during schema read: {}", entityType);
        throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_006, ioe, entityType);
      }
      return schema;
    }
  }

  @Override
  public void validate(String entityType, String objString, boolean ignoreRequiredFields)
      throws RuntimeException {
    Schema schema = getEntitySchema(entityType);
    if (Objects.nonNull(schema)) {
      JSONObject obj = new JSONObject(objString);
      try {
        schema.validate(obj); // throws a ValidationException if this object is invalid
      } catch (ValidationException e) {
        log.error("Validation Exception : " + e.getAllMessages());
        if (ignoreRequiredFields) {
          List<ValidationException> flattenedExceptions = flattenException(e).stream()
              .filter(ve -> !ve.getKeyword().equals(REQUIRED_KEYWORD)).toList();
          if (!flattenedExceptions.isEmpty()) {
            String errMsg = flattenedExceptions.stream()
                .map(ve -> String.format("%s : %s", e.getPointerToViolation(), e.getMessage()))
                .collect(Collectors.joining("; "));
            throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_003, entityType,
                errMsg);
          }
        } else {
          throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_003, entityType,
              String.join("; ", e.getAllMessages()));
        }
      }
    } else {
      log.warn("{} schema not found for validation", entityType);
    }
  }

  private List<ValidationException> flattenException(ValidationException e) {
    List<ValidationException> flattenedValidationExceptions = new ArrayList<>();
    if (!e.getCausingExceptions().isEmpty()) {
      for (ValidationException ve : e.getCausingExceptions()) {
        flattenedValidationExceptions.addAll(flattenException(ve));
      }
    } else {
      flattenedValidationExceptions.add(e);
    }
    return flattenedValidationExceptions;
  }
}
