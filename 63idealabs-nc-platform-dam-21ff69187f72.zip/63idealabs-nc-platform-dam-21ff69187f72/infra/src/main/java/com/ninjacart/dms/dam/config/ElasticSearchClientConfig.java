/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.config;

import com.ninjacart.dms.dam.constants.CoreConstants;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 * Configuration class responsible for fetching elastic search config and returns elastic client.
 */
@Configuration
@RequiredArgsConstructor
public class ElasticSearchClientConfig {

  private final ESConfig esConfig;

  /**
   * Method to return singleton instance of elastic search connection
   */
  @Bean
  @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
  public RestHighLevelClient getEsClient() {

    String[] connectionUrl = esConfig.getConnectionUrl().split(",");
    Map<String, Integer> hostPort = new HashMap<>();

    // Make Connection Url
    for (String info : connectionUrl) {
      hostPort.put(info, Integer.valueOf(Objects.requireNonNull(esConfig.getConnectionUrlPort())));
    }

    // Update the http host and port
    List<HttpHost> httpHosts = new ArrayList<>();
    for (String host : hostPort.keySet()) {
      httpHosts.add(new HttpHost(host.split("://", -1)[1], hostPort.get(host),
          host.startsWith("https") ? "https" : "http"));
    }

    // Build Credentials Builder
    final String userName = esConfig.getConnectionUser();
    final String password = esConfig.getConnectionPassword();
    final CredentialsProvider credentialsProvider =
        (Objects.nonNull(userName) && Objects.nonNull(password)) ? new BasicCredentialsProvider()
            : null;

    // Create ES Client
    RestClientBuilder clientBuilder = RestClient.builder(httpHosts.toArray(new HttpHost[0]));
    if (Objects.nonNull(credentialsProvider)) {
      credentialsProvider.setCredentials(AuthScope.ANY,
          new UsernamePasswordCredentials(userName, password));
      clientBuilder.setHttpClientConfigCallback(
          httpClientBuilder -> httpClientBuilder.setDefaultCredentialsProvider(
              credentialsProvider));
    }

    return new RestHighLevelClient(clientBuilder);
  }

  @Bean(destroyMethod = "close")
  public RestClient restClient() {
    return getEsClient().getLowLevelClient();
  }


  @Bean
  public String getSearchType() {
    return CoreConstants.ES_DOC_TYPE;
  }
}
