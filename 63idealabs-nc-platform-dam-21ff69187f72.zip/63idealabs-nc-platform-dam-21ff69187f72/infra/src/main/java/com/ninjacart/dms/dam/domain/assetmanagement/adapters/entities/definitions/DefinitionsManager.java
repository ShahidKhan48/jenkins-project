/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions;

import com.fasterxml.jackson.databind.JsonNode;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models.Definition;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models.SchemaInfo;
import com.ninjacart.dms.dam.exception.DAMRuntimeException;
import com.ninjacart.dms.dam.exception.DAMServiceErrorCode;
import com.ninjacart.dms.dam.utils.JSONUtil;
import io.apicurio.registry.rest.client.RegistryClient;
import io.apicurio.registry.rest.v2.beans.ArtifactSearchResults;
import io.apicurio.registry.rest.v2.beans.SearchedArtifact;
import jakarta.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;

/**
 * Definitions manager for entities.
 */
@Slf4j
@RequiredArgsConstructor
public class DefinitionsManager {

  private final Map<SchemaInfo, Definition> definitionMap = new HashMap<>();
  private final Map<SchemaInfo, Definition> derivedDefinitionMap = new HashMap<>();

  private final String schemaGroups;
  private final RegistryClient registryClient;

  /**
   * Loads the definitions from the _schemas folder.
   */
  @PostConstruct
  public void loadDefinition() {

    loadResourcesFromPath();

    derivedDefinitionMap.putAll(definitionMap);
    Set<Definition> loadedDefinitionsSet = new HashSet<>(definitionMap.values());

    // CAVEAT: attribute names must be distinct to not cause definition collisions.
    loadedDefinitionsSet.forEach(def -> {
      def.getSubSchemaInfo().forEach((fieldName, defnName) -> {
        Definition definition = definitionMap.getOrDefault(defnName, null);
        if (null != definition) {
          derivedDefinitionMap.putIfAbsent(fieldName, definitionMap.get(defnName));
        } else {
          log.warn("{} definition not found for field {}", defnName, fieldName);
        }
      });
    });

    log.debug("loaded schema resource(s): " + definitionMap.size());
  }

  private void loadResourcesFromPath() {
    String[] schemaGroups = this.schemaGroups.split(",");
    for (String schemaGroup : schemaGroups) {
      ArtifactSearchResults artifactIds = registryClient.listArtifactsInGroup(schemaGroup);
      List<SearchedArtifact> artifacts = artifactIds.getArtifacts();
      for (SearchedArtifact artifactId : artifacts) {
        try {
          String schema = IOUtils.toString(
              registryClient.getLatestArtifact(schemaGroup, artifactId.getId()));
          JsonNode jsonNode = JSONUtil.OBJECT_MAPPER.readTree(schema);
          Definition definition = new Definition(jsonNode, schemaGroup);
          SchemaInfo schemaInfo = new SchemaInfo();
          schemaInfo.setSchemaGroup(schemaGroup);
          schemaInfo.setEntityType(definition.getTitle());
          log.debug("loading resource:" + artifactId + " with private field size:"
              + definition.getOsSchemaConfiguration().getPrivateFields().size()
              + " & signed fields size:" + definition.getOsSchemaConfiguration().getSignedFields()
              .size());
          definitionMap.putIfAbsent(schemaInfo, definition);
        } catch (Exception e) {
          log.error("Exception while reading schema from apicurio for id: {}", artifactId, e);
          log.error("Error during schema read: {}", artifactId);
          throw new DAMRuntimeException(DAMServiceErrorCode.DAM_SERVICE_ERROR_006, e, artifactId);
        }
      }
    }
  }

  /**
   * Returns the title for all definitions loaded.
   *
   * @return known definitions
   */
  public Set<String> getAllKnownDefinitions() {
    Set<String> definitions = new HashSet<>();
    for (SchemaInfo schemaInfo : definitionMap.keySet()) {
      definitions.add(schemaInfo.getEntityType());
    }
    return definitions;
  }

  /**
   * Returns the schema info object (i.e. title and schema group) for all definitions loaded.
   *
   * @return all known schema
   */
  public Set<SchemaInfo> getAllKnownSchemaInfo() {
    return definitionMap.keySet();
  }

  /**
   * Returns all definitions that are loaded.
   *
   * @return all definitions
   */
  public List<Definition> getAllDefinitions() {
    List<Definition> definitions = new ArrayList<>();
    for (Entry<SchemaInfo, Definition> entry : definitionMap.entrySet()) {
      definitions.add(entry.getValue());
    }
    return definitions;
  }

  /**
   * Provide a definition by given title which is already loaded.
   *
   * @param schemaInfo schema info
   * @return definition
   */
  public Definition getDefinition(SchemaInfo schemaInfo) {
    return definitionMap.getOrDefault(schemaInfo, null);
  }

  /**
   * Returns the map, where key is the index and value is the internal fields.
   *
   * @return excluding fields
   */
  public Map<String, Set<String>> getExcludingFields() {
    Map<String, Set<String>> result = new HashMap<>();
    for (SchemaInfo schemaInfo : getAllKnownSchemaInfo()) {
      String index = schemaInfo.getEntityType();
      List<String> internalFields = getDefinition(schemaInfo).getOsSchemaConfiguration()
          .getInternalFields();
      List<String> privateFields = getDefinition(schemaInfo).getOsSchemaConfiguration()
          .getPrivateFields();
      internalFields.addAll(privateFields);
      result.put(index.toLowerCase(), new HashSet<>(internalFields));
    }
    return result;
  }
}
