/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models;

/**
 * AttestorPluginType Enum.
 */
public enum AttestorPluginType {
  internal, external
}
