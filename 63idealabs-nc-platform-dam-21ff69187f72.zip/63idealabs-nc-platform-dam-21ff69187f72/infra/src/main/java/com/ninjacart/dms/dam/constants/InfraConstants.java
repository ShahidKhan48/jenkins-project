/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.constants;

/**
 * Infra Constants.
 */
public class InfraConstants {

  public static final String DA_PROXY_CLIENT = "DaProxyClient";

  public static final String PROVIDER = "provider";
  public static final String REALM_ID = "realmId";
  public static final String USER_ID = "userId";
  public static final String OPERATION_ID = "operationId";
  public static final String PROVIDER_REFERENCE_ID = "providerReferenceId";
  public static final String EXTERNAL_REFERENCE_ID = "externalReferenceId";
  public static final String DOCUMENT_INFO = "documentInfo";
  public static final String DOCUMENT_DATA = "documentData";
  public static final String DOCUMENT_INFO_DOCUMENT_IDENTIFIER = "documentInfo.documentIdentifier";
  public static final String DOCUMENT_DATA_IDENTIFIER = "documentData.identifier";
  public static final String DOCUMENT_IDENTIFIER = "documentIdentifier";
  public static final String IDENTIFIER = "identifier";
  public static final String _STATUS = "_status";
  public static final String ID = "id";
  public static final String _ID = "_id";
  public static final String EVENT = "Event";
  public static final String SCHEMAINFO = "schemaInfo";
  public static final String ENTITY = "entity";
  public static final String COMPLETED = "COMPLETED";
  public static final String CREATED_AT = "createdAt";
  public static final String UPDATED_AT = "updatedAt";
  public static final String VERSION = "version";
  public static final String DOT = ".";
}
