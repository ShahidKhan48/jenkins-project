/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events;

import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.model.AuditEvent;

/**
 * Interface to push notification event to notification system.
 */
public interface IEventNotification {

  /**
   * Method to push event to notification system
   *
   * @param auditEvent which needs to be pushed
   */
  void pushEvent(AuditEvent auditEvent);
}
