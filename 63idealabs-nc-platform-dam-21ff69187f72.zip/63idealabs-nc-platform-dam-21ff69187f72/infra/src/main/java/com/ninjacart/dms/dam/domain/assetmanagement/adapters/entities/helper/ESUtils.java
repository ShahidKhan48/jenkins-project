/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.helper;

import com.ninjacart.dms.dam.domain.assetmanagement.model.Filter;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SearchQuery;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.Operator;
import java.util.List;
import java.util.Objects;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;

/**
 * Class responsible for having ES Utils.
 */
@UtilityClass
public final class ESUtils {

  /**
   * Builds ES Search Query.
   *
   * @param searchQuery
   * @return BoolQueryBuilder
   */
  public static BoolQueryBuilder buildQuery(SearchQuery searchQuery) {
    List<Filter> filters = searchQuery.getFilters();
    BoolQueryBuilder query = QueryBuilders.boolQuery();
    for (Filter filter : filters) {
      String field = filter.getProperty();
      Object value = filter.getValue();
      Operator operator = filter.getOperator();
      operator = Objects.isNull(operator) ? Operator.eq : operator;
      String path = filter.getPath();
      field = StringUtils.isNotEmpty(path) ? path + "." + field : field;
      switch (operator) {
        case eq -> query = query.must(QueryBuilders.matchPhraseQuery(field, value));
        case neq -> query = query.mustNot(QueryBuilders.matchPhraseQuery(field, value));
        case gt -> query = query.must(QueryBuilders.rangeQuery(field).gt(value));
        case lt -> query = query.must(QueryBuilders.rangeQuery(field).lt(value));
        case gte -> query = query.must(QueryBuilders.rangeQuery(field).gte(value));
        case lte -> query = query.must(QueryBuilders.rangeQuery(field).lte(value));
        case between -> {
          List<Object> objects = (List<Object>) value;
          query = query.must(QueryBuilders.rangeQuery(field).from(objects.get(0))
              .to(objects.get(objects.size() - 1)));
        }
        case or -> {
          List<Object> values = (List<Object>) value;
          for (Object val : values) {
            query = query.should(QueryBuilders.matchPhraseQuery(field, val));
          }
          query = query.minimumShouldMatch(1);
        }
        case nor -> {
          List<Object> values = (List<Object>) value;
          for (Object val : values) {
            query = query.mustNot(QueryBuilders.matchPhraseQuery(field, val));
          }
        }
        case contains ->
            query = query.must(QueryBuilders.wildcardQuery(field, "*" + value.toString() + "*"));
        case startsWith ->
            query = query.must(QueryBuilders.matchPhrasePrefixQuery(field, value.toString()));
        case endsWith -> query = query.must(QueryBuilders.wildcardQuery(field, "*" + value));
        case notContains -> query = query.mustNot(QueryBuilders.matchPhraseQuery(field, value));
        case notStartsWith ->
            query = query.mustNot(QueryBuilders.matchPhrasePrefixQuery(field, value.toString()));
        case notEndsWith -> query = query.mustNot(QueryBuilders.wildcardQuery(field, "*" + value));
        case queryString -> query = query.must(QueryBuilders.queryStringQuery(value.toString()));
        default -> query = query.must(QueryBuilders.matchQuery(field, value));
      }
    }
    return query;
  }
}

