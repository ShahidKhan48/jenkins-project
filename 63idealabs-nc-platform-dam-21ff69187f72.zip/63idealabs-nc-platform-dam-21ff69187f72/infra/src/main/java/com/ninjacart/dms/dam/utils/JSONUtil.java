/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.NullNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;

/**
 * Util class responsible for having all json and jsonld related methods.
 */
public final class JSONUtil {

  public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

  static {
    OBJECT_MAPPER.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    OBJECT_MAPPER.registerModule(new JavaTimeModule());
  }

  private final static String KEY_NULL_ERROR = "key cannot be null or empty";

  /**
   * Converts Object to Json String (JSON Stringify).
   *
   * @param object object to stringify.
   * @return JSON string of {@param object}
   * @throws JsonProcessingException
   */
  public static String convertObjectJsonString(Object object) throws JsonProcessingException {
    return OBJECT_MAPPER.writeValueAsString(object);
  }

  /**
   * Converts JSON string into {@link JsonNode}
   *
   * @param jsonStr string to be parsed.
   * @return converted {@link JsonNode}
   * @throws IOException
   */
  public static JsonNode convertStringJsonNode(String jsonStr) throws IOException {
    return OBJECT_MAPPER.readTree(jsonStr);
  }

  /**
   * Converts {@link JsonNode} into {@link Map<>}
   *
   * @param object {@link JsonNode} to be converted.
   * @return converted Map.
   */
  public static Map<String, Object> convertJsonNodeToMap(JsonNode object) {
    return OBJECT_MAPPER.convertValue(object, Map.class);
  }

  /**
   * Adding field(key, value) to Parent's hierarchy
   *
   * @param parent
   * @param childKey field key
   * @param child    field value
   */
  public static void addField(ObjectNode parent, String childKey, String child) {
    parent.fields().forEachRemaining(entry -> {
      JsonNode entryValue = entry.getValue();
      if (entryValue.isObject()) {
        addField((ObjectNode) entry.getValue(), childKey, child);
      }
      if (entryValue.isArray()) {
        for (int i = 0; i < entryValue.size(); i++) {
          if (entry.getValue().get(i).isObject()) {
            addField((ObjectNode) entry.getValue().get(i), childKey, child);
          }
        }
      }
    });
    if (StringUtils.isEmpty(childKey)) {
      throw new IllegalArgumentException(KEY_NULL_ERROR);
    }
    parent.put(childKey, child);

  }

  public static void addField(ObjectNode parent, String childKey, List<String> child) {
    parent.fields().forEachRemaining(entry -> {
      JsonNode entryValue = entry.getValue();
      if (entryValue.isObject()) {
        addField((ObjectNode) entry.getValue(), childKey, child);
      }
      if (entryValue.isArray()) {
        for (int i = 0; i < entryValue.size(); i++) {
          if (entry.getValue().get(i).isObject()) {
            addField((ObjectNode) entry.getValue().get(i), childKey, child);
          }
        }
      }
    });
    if (StringUtils.isEmpty(childKey)) {
      throw new IllegalArgumentException(KEY_NULL_ERROR);
    }
    ArrayNode arrayNode = JsonNodeFactory.instance.arrayNode();
    for (String node : child) {
      arrayNode.add(node);
    }
    parent.set(childKey, arrayNode);
  }


  /**
   * Recursively removes nulls from Objects and List from basic objects (maps) and lists
   *
   * @param input input
   * @return stripped output
   */
  public static JsonNode recursivelyRemoveEmpties(JsonNode input) {
    if (Objects.isNull(input)) {
      return null;
    }
    if (input instanceof ObjectNode) {
      Iterator<JsonNode> it = input.iterator();
      while (it.hasNext()) {
        JsonNode child = it.next();
        if (child.isNull()) {
          it.remove();
        } else {
          recursivelyRemoveEmpties(child);
        }
      }
      return input;
    } else if (input instanceof ArrayNode arrayNode) {
      Set<Integer> nullValueIndices = new HashSet<>();
      for (int i = 0; i < arrayNode.size(); i++) {
        JsonNode modifiedValue = (JsonNode) recursivelyRemoveEmpties(arrayNode.get(i));

        if (Objects.isNull(modifiedValue) || modifiedValue instanceof NullNode) {
          nullValueIndices.add(i);
        } else {
          ((ArrayNode) input).set(i, modifiedValue);
        }
      }
      nullValueIndices.forEach(arrayNode::remove);
      return arrayNode;
    } else {
      return input;
    }
  }
}

