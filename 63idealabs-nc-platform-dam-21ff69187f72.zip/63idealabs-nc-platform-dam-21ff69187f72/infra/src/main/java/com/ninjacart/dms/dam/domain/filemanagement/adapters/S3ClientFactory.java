/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.filemanagement.adapters;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;

/**
 * S3 Client Factory.
 */
@RequiredArgsConstructor
public class S3ClientFactory {

  private final String accessKey;
  private final String secretKey;

  private final Map<String, S3Client> s3ClientMap = new HashMap<>();
  private final Map<String, S3Presigner> s3PresignerMap = new HashMap<>();

  /**
   * Get S3 Client based on region
   *
   * @param region region
   * @return S3 client
   */
  public S3Client getClientByRegion(String region) {
    S3Client s3Client = s3ClientMap.get(region);
    if (Objects.isNull(s3Client)) {
      s3Client = createS3Client(region);
    }
    return s3Client;
  }

  public S3Presigner getPresignerByRegion(String region) {
    S3Presigner s3Presigner = s3PresignerMap.get(region);
    if (Objects.isNull(s3Presigner)) {
      AwsCredentials credentials = AwsBasicCredentials.create(accessKey, secretKey);

      s3Presigner = S3Presigner.builder().region(Region.of(region))
          .credentialsProvider(StaticCredentialsProvider.create(credentials)).build();
      s3PresignerMap.put(region, s3Presigner);
    }
    return s3Presigner;
  }

  // synchronized : thread safe preventing creation of multiple client for same region
  private synchronized S3Client createS3Client(String region) {
    S3Client s3Client = s3ClientMap.get(region);
    if (Objects.nonNull(s3Client)) {
      return s3Client;
    }
    String accessKey = this.accessKey;
    String secretKey = this.secretKey;

    AwsCredentials credentials = AwsBasicCredentials.create(accessKey, secretKey);
    s3Client = S3Client.builder().region(Region.of(region))
        .credentialsProvider(StaticCredentialsProvider.create(credentials)).build();
    s3ClientMap.put(region, s3Client);
    return s3Client;
  }
}