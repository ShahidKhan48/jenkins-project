/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.model;


import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Source System Details
 * <p>
 * Source Details
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SourceDetails {

  /**
   * Source Type
   * <p>
   * <p>
   * (Required)
   */
  @JsonProperty("sourceType")
  private String sourceType;
  @JsonIgnore
  private Map<String, String> additionalProperties = new HashMap<String, String>();

  /**
   * Source Type
   * <p>
   * <p>
   * (Required)
   */
  @JsonProperty("sourceType")
  public String getSourceType() {
    return sourceType;
  }

  /**
   * Source Type
   * <p>
   * <p>
   * (Required)
   */
  @JsonProperty("sourceType")
  public void setSourceType(String sourceType) {
    this.sourceType = sourceType;
  }

  @JsonAnyGetter
  public Map<String, String> getAdditionalProperties() {
    return this.additionalProperties;
  }

  @JsonAnySetter
  public void setAdditionalProperty(String name, String value) {
    this.additionalProperties.put(name, value);
  }

}
