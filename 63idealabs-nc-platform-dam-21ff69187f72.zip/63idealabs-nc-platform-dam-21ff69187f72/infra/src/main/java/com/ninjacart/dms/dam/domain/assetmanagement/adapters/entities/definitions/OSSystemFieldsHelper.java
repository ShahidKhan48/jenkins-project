package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions;

import com.fasterxml.jackson.databind.JsonNode;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models.OSSystemFields;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models.SchemaInfo;
import com.ninjacart.dms.dam.domain.assetmanagement.model.SessionContext;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class OSSystemFieldsHelper {

  /**
   * ensure the system fields(createdAt, createdBy) at time of adding a fresh record/node
   *
   * @param entityType     entity type
   * @param node           root node
   * @param sessionContext session context
   * @param schemaGroup    schema group
   * @param isCreate       create/update
   */
  public static void ensureAuditFields(String entityType, JsonNode node, SessionContext sessionContext,
      String schemaGroup, boolean isCreate) {
    SchemaInfo schemaInfo = new SchemaInfo();
    schemaInfo.setSchemaGroup(schemaGroup);
    schemaInfo.setEntityType(entityType);
    List<String> systemFields = getSystemFields();
    String timeStamp = Instant.now().toString();
    for (String field : systemFields) {
      addSystemProperty(entityType, field, node, sessionContext.getActionUserId(),
          sessionContext.getToolId(), timeStamp, isCreate);
    }
  }

  /**
   * adds a system property to given node
   *
   * @param entityType entity type
   * @param field      field
   * @param node       root node
   * @param userId     user id
   * @param toolId     tool id
   * @param timeStamp  time stamp
   * @param isCreate   create/update
   */
  public static void addSystemProperty(String entityType, String field, JsonNode node, String userId,
      String toolId, String timeStamp, boolean isCreate) {
    OSSystemFields systemField = OSSystemFields.getByValue(field);
    if (Objects.nonNull(systemField)) {
      switch (systemField) {
        case createdByTool -> {
          if (isCreate) {
            OSSystemFields.createdByTool.createdByTool(node, toolId, entityType);
          }
        }
        case updatedByTool -> OSSystemFields.updatedByTool.updatedByTool(node, toolId, entityType);
        case createdAt -> {
          if (isCreate) {
            OSSystemFields.createdAt.createdAt(node, timeStamp, entityType);
          }
        }
        case createdBy -> {
          if (isCreate && userId != null) {
            OSSystemFields.createdBy.createdBy(node, userId, entityType);
          }
        }
        case updatedAt -> OSSystemFields.updatedAt.updatedAt(node, timeStamp, entityType);
        case updatedBy -> {
          if (userId != null) {
            OSSystemFields.updatedBy.updatedBy(node, userId, entityType);
          }
        }
      }
    } else {
      log.warn("Audit field - {} not valid", field);
    }
  }

  private static List<String> getSystemFields() {
    return Arrays.stream(OSSystemFields.values()).map(OSSystemFields::toString).toList();
  }
}
