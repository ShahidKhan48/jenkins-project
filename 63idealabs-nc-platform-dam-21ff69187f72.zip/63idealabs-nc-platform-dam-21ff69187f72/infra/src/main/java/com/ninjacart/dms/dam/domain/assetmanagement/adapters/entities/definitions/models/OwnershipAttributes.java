/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

/**
 * Ownership Attributes.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OwnershipAttributes {

  String email;
  String mobile;
  String userId;

  /**
   * Is valid.
   *
   * @return is valid
   */
  public boolean isValid() {
    if (StringUtils.isEmpty(userId)) {
      return true;
    }
    return StringUtils.isEmpty(email) && StringUtils.isEmpty(mobile);
  }
}