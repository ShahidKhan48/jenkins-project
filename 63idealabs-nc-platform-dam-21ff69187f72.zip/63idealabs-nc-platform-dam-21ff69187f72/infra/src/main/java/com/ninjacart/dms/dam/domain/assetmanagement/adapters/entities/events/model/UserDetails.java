/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.model;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * User System Details
 * <p>
 * User Details
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserDetails {

  /**
   * User Id
   * <p>
   * <p>
   * (Required)
   */
  @JsonProperty("userId")
  private String userId;
  /**
   * User Name
   * <p>
   */
  @JsonProperty("userName")
  private String userName;
  /**
   * Realm Id
   * <p>
   */
  @JsonProperty("realmId")
  private String realmId;
  @JsonIgnore
  private Map<String, String> additionalProperties = new HashMap<String, String>();

  /**
   * User Id
   * <p>
   * <p>
   * (Required)
   */
  @JsonProperty("userId")
  public String getUserId() {
    return userId;
  }

  /**
   * User Id
   * <p>
   * <p>
   * (Required)
   */
  @JsonProperty("userId")
  public void setUserId(String userId) {
    this.userId = userId;
  }

  /**
   * User Name
   * <p>
   */
  @JsonProperty("userName")
  public String getUserName() {
    return userName;
  }

  /**
   * User Name
   * <p>
   */
  @JsonProperty("userName")
  public void setUserName(String userName) {
    this.userName = userName;
  }

  /**
   * Realm Id
   * <p>
   */
  @JsonProperty("realmId")
  public String getRealmId() {
    return realmId;
  }

  /**
   * Realm Id
   * <p>
   */
  @JsonProperty("realmId")
  public void setRealmId(String realmId) {
    this.realmId = realmId;
  }

  @JsonAnyGetter
  public Map<String, String> getAdditionalProperties() {
    return this.additionalProperties;
  }

  @JsonAnySetter
  public void setAdditionalProperty(String name, String value) {
    this.additionalProperties.put(name, value);
  }

}

