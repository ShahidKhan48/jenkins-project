/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.events.model;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * AdditionalDetail Schema
 * <p>
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AdditionalDetail {

  /**
   * Id
   * <p>
   */
  @JsonProperty("id")
  private String id;
  /**
   * Entity Id
   * <p>
   */
  @JsonProperty("entityId")
  private String entityId;
  /**
   * Reference Type
   * <p>
   */
  @JsonProperty("refType")
  private String refType;
  /**
   * Reference Value
   * <p>
   */
  @JsonProperty("refValue")
  private String refValue;
  /**
   * Audit Field informations
   * <p>
   * System Fields
   */
  @JsonProperty("systemFields")
  @JsonPropertyDescription("System Fields")
  private SystemFieldDetails systemFields;
  @JsonIgnore
  private Map<String, String> additionalProperties = new HashMap<String, String>();

  /**
   * Id
   * <p>
   */
  @JsonProperty("id")
  public String getId() {
    return id;
  }

  /**
   * Id
   * <p>
   */
  @JsonProperty("id")
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Entity Id
   * <p>
   */
  @JsonProperty("entityId")
  public String getEntityId() {
    return entityId;
  }

  /**
   * Entity Id
   * <p>
   */
  @JsonProperty("entityId")
  public void setEntityId(String entityId) {
    this.entityId = entityId;
  }

  /**
   * Reference Type
   * <p>
   */
  @JsonProperty("refType")
  public String getRefType() {
    return refType;
  }

  /**
   * Reference Type
   * <p>
   */
  @JsonProperty("refType")
  public void setRefType(String refType) {
    this.refType = refType;
  }

  /**
   * Reference Value
   * <p>
   */
  @JsonProperty("refValue")
  public String getRefValue() {
    return refValue;
  }

  /**
   * Reference Value
   * <p>
   */
  @JsonProperty("refValue")
  public void setRefValue(String refValue) {
    this.refValue = refValue;
  }

  /**
   * Audit Field informations
   * <p>
   * System Fields
   */
  @JsonProperty("systemFields")
  public SystemFieldDetails getSystemFields() {
    return systemFields;
  }

  /**
   * Audit Field informations
   * <p>
   * System Fields
   */
  @JsonProperty("systemFields")
  public void setSystemFields(SystemFieldDetails systemFields) {
    this.systemFields = systemFields;
  }

  @JsonAnyGetter
  public Map<String, String> getAdditionalProperties() {
    return this.additionalProperties;
  }

  @JsonAnySetter
  public void setAdditionalProperty(String name, String value) {
    this.additionalProperties.put(name, value);
  }

}

