/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.callback;

import com.ninjacart.dms.dam.domain.assetmanagement.model.CallbackPayload;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CallbackResponse;
import java.net.URI;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Callback Feign Client.
 */
@FeignClient(name = "callbackClient", url = "https://dummy")
public interface CallbackFeignClient {

  /**
   * Calls callback url with given payload.
   *
   * @param url     full callback url. This will override url set in @FeignClient annotation
   * @param payload callback payload
   * @return callback response
   */
  @RequestMapping(method = RequestMethod.POST)
  CallbackResponse executeCallback(URI url, @RequestBody CallbackPayload payload);
}
