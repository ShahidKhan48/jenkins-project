/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.persistence;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.entities.definitions.models.SchemaInfo;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;

/**
 * Persistence Provider.
 */
public interface IPersistenceProvider {

  /**
   * Saves document into ES(ElasticSearch)
   *
   * @param realmId     realm id
   * @param userId      user id
   * @param schemaInfo  - schema info, schemaInfo.getEntityType() is ElasticSearch Index
   * @param id          - document id
   * @param inputEntity - input json document for adding
   * @return
   */
  JsonNode addEntity(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity);

  /**
   * Reads document with respect to input osid from ES
   *
   * @param realmId    realm id
   * @param userId     user id
   * @param schemaInfo - schema info, schemaInfo.getEntityType() is ElasticSearch Index
   * @param id         - which maps to document
   * @return
   */
  JsonNode readEntity(String realmId, String userId, SchemaInfo schemaInfo, String id);

  /**
   * updates document with respect to input osid to ES
   *
   * @param realmId     realm id
   * @param userId      user id
   * @param schemaInfo  - schema info, schemaInfo.getEntityType() is ElasticSearch Index
   * @param inputEntity - input json document for updating
   * @param id          - which maps to document
   * @return
   */
  JsonNode updateEntity(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity);

  /**
   * deletes document with respect to input osid from ES
   *
   * @param realmId    realm id
   * @param userId     user id
   * @param schemaInfo - schema info, schemaInfo.getEntityType() is ElasticSearch Index
   * @param id         - which maps to document
   */
  void deleteEntity(String realmId, String userId, SchemaInfo schemaInfo, String id);

  /**
   * searches documents from ES based on query
   *
   * @param realmId     realm id
   * @param userId      user id
   * @param schemaInfo  - schema info, schemaInfo.getEntityType() is ElasticSearch Index
   * @param searchQuery - which contains details for search
   * @return
   */
  List<String> search(String realmId, String userId, SchemaInfo schemaInfo, Object searchQuery)
      throws IOException;

  /**
   * Method to return all entities of type
   *
   * @param realmId    realm id
   * @param userId     user id
   * @param schemaInfo - schema info, schemaInfo.getEntityType() is ElasticSearch Index
   * @return list of all entities of type
   */
  List<String> readAll(String realmId, String userId, SchemaInfo schemaInfo);

  /**
   * Method to add event
   *
   * @param realmId
   * @param userId
   * @param schemaInfo
   * @param id
   * @param inputEntity
   * @return
   */
  JsonNode addEvent(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity);

  /**
   * Method to fetch all events of entity.
   *
   * @param ids id
   * @return entities
   */
  JsonNode findAllByIdIn(SchemaInfo schemaInfo, List<String> ids);

  /**
   * Method to find last event of entity
   *
   * @param realmId
   * @param userId
   * @param schemaInfo
   * @param id
   * @return
   */
  Document findLastEventByEntityId(String realmId, String userId, SchemaInfo schemaInfo, String id);

  /**
   * Reads event with respect to input
   *
   * @param realmId    realm id
   * @param userId     user id
   * @param schemaInfo - schema info, schemaInfo.getEntityType() is ElasticSearch Index
   * @param id
   * @return
   */
  default Optional<ObjectNode> readLastEvent(String realmId, String userId, SchemaInfo schemaInfo,
      String id) throws IOException {
    return Optional.empty();
  }

  /**
   * Saves document into ES(ElasticSearch)
   *
   * @param realmId     realm id
   * @param userId      user id
   * @param schemaInfo  - schema info, schemaInfo.getEntityType() is ElasticSearch Index
   * @param id          - document id
   * @param inputEntity - input json document for adding
   * @return
   */
  JsonNode addEventEntity(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode inputEntity, Integer newVersion);

  /**
   * Search the realm object by unique fields
   *
   * @param realmId      realm
   * @param userId       user
   * @param schemaInfo   schema
   * @param inputJson    input
   * @param uniqueFields unique fields
   * @return
   */
  default Optional<ObjectNode> searchByUniqueFields(String realmId, String userId,
      SchemaInfo schemaInfo, JsonNode inputJson, List<String> uniqueFields) {
    return Optional.empty();
  }

  default String updateEventEntity(String realmId, String userId, SchemaInfo schemaInfo, String id,
      JsonNode input, int newVersion) {
    return StringUtils.EMPTY;
  }
}
