/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.config.events;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 * EventHub Cluster Configuration.
 */
@Configuration
public class EventHubClusterConfiguration {

  @Bean
  @Scope("singleton")
  @ConfigurationProperties(prefix = "event-hub")
  public EventHubConfiguration eventHubConfiguration() {
    return new EventHubConfiguration();
  }
}
