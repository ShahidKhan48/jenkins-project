/*
 * Copyright (c) 2023, Ninjacart and/or its affiliates.
 */

package com.ninjacart.dms.dam.domain.assetmanagement.adapters.daproxy;

import com.ninjacart.dms.dam.domain.assetmanagement.adapters.daproxy.mapper.ActionRequestMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.adapters.daproxy.mapper.DigitalAssetMapper;
import com.ninjacart.dms.dam.domain.assetmanagement.command.CollectionRequestCommand;
import com.ninjacart.dms.dam.domain.assetmanagement.command.DigitalAssetCommand;
import com.ninjacart.dms.dam.domain.assetmanagement.enums.AssetOperation;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequest;
import com.ninjacart.dms.dam.domain.assetmanagement.model.CollectionRequestResponse;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAsset;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDetails;
import com.ninjacart.dms.dam.domain.assetmanagement.model.DigitalAssetDetailsResponse;
import com.ninjacart.dms.dam.domain.assetmanagement.port.out.DaProxyClient;
import com.ninjacart.dms.daproxy.model.ActionRequest;
import com.ninjacart.dms.daproxy.model.FetchAssetResponse;
import lombok.RequiredArgsConstructor;

/**
 * DA-Proxy Client implementation.
 */
@RequiredArgsConstructor
public class DaProxyWebAdapter implements DaProxyClient {

  private final DaProxyFeignClient daProxyFeignClient;

  @Override
  public DigitalAssetDetailsResponse processDigitalAssets(String realmId, String userId,
      AssetOperation operation, DigitalAssetCommand digitalAssetCommand) {

    ActionRequest actionRequest = ActionRequestMapper.INSTANCE.fromDomain(digitalAssetCommand,
        realmId, userId);
    FetchAssetResponse fetchAssetResponse = daProxyFeignClient.process(
        digitalAssetCommand.getProvider(), operation.name(), actionRequest);
    DigitalAsset digitalAsset = DigitalAssetMapper.INSTANCE.toDigitalAsset(
        fetchAssetResponse.getData());
    DigitalAssetDetails digitalAssetDetails = DigitalAssetMapper.INSTANCE.toDigitalAssetDetails(
        fetchAssetResponse.getData());
    return DigitalAssetDetailsResponse.builder().data(digitalAssetDetails)
        .digitalAsset(digitalAsset)
        .providerReferenceId(fetchAssetResponse.getData().getProviderReferenceId())
        .redirectUrl(fetchAssetResponse.getData().getRedirectUrl()).build();
  }

  @Override
  public CollectionRequestResponse processCollectionRequest(String realmId, String userId,
      AssetOperation operation, CollectionRequestCommand collectionRequestCommand) {
    ActionRequest actionRequest = ActionRequestMapper.INSTANCE.fromDomain(collectionRequestCommand,
        realmId, userId);
    FetchAssetResponse fetchAssetResponse = daProxyFeignClient.process(
        collectionRequestCommand.getProvider(), operation.name(), actionRequest);
    CollectionRequest collectionRequest = DigitalAssetMapper.INSTANCE.toCollectionRequest(
        fetchAssetResponse.getData());
    return CollectionRequestResponse.builder().data(collectionRequest)
        .providerReferenceId(fetchAssetResponse.getData().getProviderReferenceId()).build();
  }
}
